﻿


' ✅✅✅ YEH POORA CODE NOTIFICATIONSERVICE.ASMX.VB MEIN PASTE KAREIN ✅✅✅

Imports System.Web.Services
Imports System.Web.Script.Services
Imports System.Collections.Generic
Imports System.Linq
Imports IndasTaskManagement1.DataAccess ' Apne DataAccess ko import karein


<WebService(Namespace:="http://tempuri.org/")>
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)>
<System.ComponentModel.ToolboxItem(False)>
<ScriptService()> ' Yeh line JavaScript se call karne ke liye zaroori hai
Public Class NotificationService
    Inherits System.Web.Services.WebService

    ' Yeh saare functions humne Site.Master.vb se yahan move kar diye hain

    <WebMethod(EnableSession:=True)>
    Public Function GetUserNotifications() As Object
        Try
            Dim userId As Integer = CInt(HttpContext.Current.Session("UserID"))
            Dim notifications = DataAccess.GetNotificationsForUser(userId)

            For Each n In notifications
                n.TimeAgo = GetTimeAgo(n.DateCreated)
            Next

            Dim unreadCount As Integer = 0
            For Each n In notifications
                If Not n.IsRead Then
                    unreadCount += 1
                End If
            Next

            Return New With {.success = True, .notifications = notifications, .unreadCount = unreadCount}
        Catch ex As Exception
            ' FIX: Ab error aane par bhi hum ek proper structure return karenge
            Return New With {.success = False, .notifications = New List(Of NotificationData)(), .unreadCount = 0, .message = ex.Message}
        End Try
    End Function


    <WebMethod(EnableSession:=True)>
    Public Function GetUnreadCount() As Integer
        Try
            Dim userId As Integer = CInt(HttpContext.Current.Session("UserID"))
            Return DataAccess.GetUnreadNotificationCount(userId)
        Catch ex As Exception
            Return 0
        End Try
    End Function

    <WebMethod(EnableSession:=True)>
    Public Function MarkAsRead(notificationId As Integer) As Boolean
        Dim userId As Integer = CInt(HttpContext.Current.Session("UserID"))
        Return DataAccess.MarkNotificationAsRead(notificationId, userId)
    End Function

    <WebMethod(EnableSession:=True)>
    Public Function DeleteNotification(notificationId As Integer) As Boolean
        Dim userId As Integer = CInt(HttpContext.Current.Session("UserID"))
        Return DataAccess.DeleteNotification(notificationId, userId)
    End Function

    <WebMethod(EnableSession:=True)>
    Public Function ClearAll() As Boolean
        Dim userId As Integer = CInt(HttpContext.Current.Session("UserID"))
        Return DataAccess.ClearAllNotifications(userId)
    End Function

    Private Function GetTimeAgo(theDate As DateTime) As String
        Const SECOND As Integer = 1
        Const MINUTE As Integer = 60 * SECOND
        Const HOUR As Integer = 60 * MINUTE
        Const DAY As Integer = 24 * HOUR
        Const MONTH As Integer = 30 * DAY

        Dim ts As New TimeSpan(DateTime.UtcNow.Ticks - theDate.ToUniversalTime().Ticks)
        Dim delta As Double = Math.Abs(ts.TotalSeconds)

        If delta < 1 * MINUTE Then Return If(ts.Seconds <= 1, "just now", ts.Seconds & " seconds ago")
        If delta < 2 * MINUTE Then Return "a minute ago"
        If delta < 45 * MINUTE Then Return ts.Minutes & " minutes ago"
        If delta < 90 * MINUTE Then Return "an hour ago"
        If delta < 24 * HOUR Then Return ts.Hours & " hours ago"
        If delta < 48 * HOUR Then Return "yesterday"
        If delta < 30 * DAY Then Return ts.Days & " days ago"
        If delta < 12 * MONTH Then
            Dim months As Integer = Convert.ToInt32(Math.Floor(CDbl(ts.Days) / 30))
            Return If(months <= 1, "one month ago", months & " months ago")
        Else
            Dim years As Integer = Convert.ToInt32(Math.Floor(CDbl(ts.Days) / 365))
            Return If(years <= 1, "one year ago", years & " years ago")
        End If
    End Function

End Class