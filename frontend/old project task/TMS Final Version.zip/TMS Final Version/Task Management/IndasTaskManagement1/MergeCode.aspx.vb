﻿Imports System.Web.Services
Imports IndasTaskManagement1.DataAccess

Public Class MergeCode
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Session("UserID") Is Nothing Then
            Response.Redirect("Landing.aspx")
        End If
    End Sub

    <WebMethod()>
    Public Shared Function GetMyMergeRequests() As List(Of PointData)
        Dim currentUserId As Integer = CInt(HttpContext.Current.Session("UserID"))
        ' Yeh naye logic waale function ko call karega
        Return DataAccess.GetPointsForMerge(currentUserId)
    End Function

    ' In MergeCode.aspx.vb
    ' Add these two new WebMethods inside the MergeCode class

    <WebMethod()>
    Public Shared Function VerifyAndSendToQc(pointId As Integer) As Boolean
        Try
            Dim success As Boolean = DataAccess.UpdatePointStatusAndDate(pointId, "PendingQC", "DateSentToQC", DateTime.Now)
            If success Then
                DataAccess.ResetTesterFieldsForNewQCCycle(pointId)

                ' --- NOTIFICATION LOGIC START ---
                ' Sabhi testers ko notification bhejein
                Dim adminName As String = HttpContext.Current.Session("FullName").ToString()
                Dim testers = DataAccess.GetUsersByRole("Tester")
                For Each tester In testers
                    Dim message As String = $"Point #{pointId} is ready for QC, approved by {adminName}."
                    Dim url As String = $"~/DashboardTester.aspx?pointId={pointId}"
                    DataAccess.CreateNotification(tester.UserID, message, url)
                Next
                ' --- NOTIFICATION LOGIC END ---
            End If
            Return success
        Catch ex As Exception
            Return False
        End Try
    End Function

    <WebMethod()>
    Public Shared Function ReopenPoint(pointId As Integer) As Boolean
        Try
            Dim success As Boolean = DataAccess.UpdatePointStatus(pointId, "ReOpened")

            If success Then
                ' --- NOTIFICATION LOGIC START ---
                ' Developer ko batayein ki merge request reject ho gayi hai
                Dim pointDetails = DataAccess.GetPointDetailsById(pointId)
                If pointDetails IsNot Nothing AndAlso pointDetails.AssignedToID.HasValue Then
                    Dim adminName As String = HttpContext.Current.Session("FullName").ToString()
                    Dim message As String = $"Merge request for Point #{pointId} was rejected by {adminName}. Please review."
                    Dim url As String = $"~/DashboardDeveloper.aspx?pointId={pointId}"
                    DataAccess.CreateNotification(pointDetails.AssignedToID.Value, message, url)
                End If
                ' --- NOTIFICATION LOGIC END ---
            End If

            Return success
        Catch ex As Exception
            Return False
        End Try
    End Function

End Class