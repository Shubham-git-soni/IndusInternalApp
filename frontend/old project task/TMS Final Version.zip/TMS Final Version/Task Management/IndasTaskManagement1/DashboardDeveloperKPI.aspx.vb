﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Web.Services
Imports System.Web.UI.WebControls

Public Class DashboardDeveloperKPI
    Inherits BasePage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
        Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches)

        ' YEH NAYI, BEHTAR VALIDATION ISTEMAL KAREIN
        If Session("UserID") Is Nothing Then
            Response.Redirect("Landing.aspx")
            Return ' Redirect ke baad code aage na chale
        End If

        ' Role ko safely check karein
        If Session("Role") Is Nothing OrElse Not Session("Role").ToString().Equals("Developer", StringComparison.OrdinalIgnoreCase) Then
            ' Agar developer nahi hai to uske main dashboard par bhej dein, ya login par
            Response.Redirect("DashboardDeveloper.aspx") ' Behtar anubhav ke liye
            Return
        End If

        If Not IsPostBack Then
            txtFromDate.Text = DateTime.Today.ToString("yyyy-MM-dd")
            txtToDate.Text = DateTime.Today.ToString("yyyy-MM-dd")
            LoadCustomers()
            Filter_Changed(Nothing, Nothing)
        End If
    End Sub


    Private Sub LoadDashboardStats(developerId As Integer,
               Optional fromDate As Nullable(Of DateTime) = Nothing,
               Optional toDate As Nullable(Of DateTime) = Nothing,
               Optional customerId As Integer = 0)

        Dim queryBuilder As New System.Text.StringBuilder()

        queryBuilder.Append("
SELECT
    COUNT(*) AS TotalPoints,
    
    -- ▼▼▼ YEH LINE BADLI GAYI HAI (SAHI LOGIC) ▼▼▼
    SUM(CASE WHEN Status IN ('Assigned', 'In Progress', 'ReOpened') THEN 1 ELSE 0 END) AS OpenTasks,
    -- ▲▲▲ UPAR WALI LINE BADLI GAYI HAI ▲▲▲

    SUM(CASE WHEN Status = 'Queue' THEN 1 ELSE 0 END) AS Pending,
    SUM(CASE WHEN Status = 'Assigned' THEN 1 ELSE 0 END) AS Assigned,
    SUM(CASE WHEN Status = 'In Progress' THEN 1 ELSE 0 END) AS InProgress,
    SUM(CASE WHEN Status = 'DevCompleted' THEN 1 ELSE 0 END) AS DevCompleted,
    SUM(CASE WHEN Status = 'In-Testing' THEN 1 ELSE 0 END) AS InTesting,
    SUM(CASE WHEN Status = 'PendingQC' THEN 1 ELSE 0 END) AS PendingQC,
    SUM(CASE WHEN Status = 'PendingSupport' THEN 1 ELSE 0 END) AS PendingSupport,
    SUM(CASE WHEN Status = 'SupportVerified' THEN 1 ELSE 0 END) AS SupportVerified,
    SUM(CASE WHEN Status = 'PendingMerge' THEN 1 ELSE 0 END) AS PendingMerge,
    SUM(CASE WHEN Status = 'Reopened' THEN 1 ELSE 0 END) AS Reopened,
    SUM(CASE WHEN Status = 'Testing-Completed' THEN 1 ELSE 0 END) AS TestingCompleted,
    SUM(CASE WHEN Status = 'Hold' THEN 1 ELSE 0 END) AS Hold,
    SUM(CASE WHEN Status = 'Reject' THEN 1 ELSE 0 END) AS Reject,
    SUM(CASE WHEN Status IN ('Completed', 'Closed') THEN 1 ELSE 0 END) AS Completed,
    SUM(CASE 
        WHEN TotalTimeSpent > ExpectedMinutes AND ExpectedMinutes IS NOT NULL AND ExpectedMinutes > 0
        THEN 1 
        ELSE 0 
    END) AS DelayedTasks
FROM Points
WHERE AssignedToID = @DeveloperID ")

        If fromDate.HasValue AndAlso toDate.HasValue Then
            queryBuilder.Append(" AND (CONVERT(DATE, DateCreated) BETWEEN @FromDate AND @ToDate)")
        End If
        If customerId > 0 Then queryBuilder.Append(" AND CustomerID = @CustomerID")

        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
            Using cmd As New SqlCommand(queryBuilder.ToString(), conn)
                cmd.CommandTimeout = 120
                cmd.Parameters.AddWithValue("@DeveloperID", developerId)

                If fromDate.HasValue AndAlso toDate.HasValue Then
                    cmd.Parameters.AddWithValue("@FromDate", fromDate.Value.Date)
                    cmd.Parameters.AddWithValue("@ToDate", toDate.Value.Date)
                End If
                If customerId > 0 Then cmd.Parameters.AddWithValue("@CustomerID", customerId)

                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    If reader.Read() Then
                        litTotalPoints.Text = If(reader.IsDBNull(reader.GetOrdinal("TotalPoints")), "0", reader("TotalPoints").ToString())
                        litOpenTasks.Text = If(reader.IsDBNull(reader.GetOrdinal("OpenTasks")), "0", reader("OpenTasks").ToString())
                        litAssigned.Text = If(reader.IsDBNull(reader.GetOrdinal("Assigned")), "0", reader("Assigned").ToString())
                        litInProcess.Text = If(reader.IsDBNull(reader.GetOrdinal("InProgress")), "0", reader("InProgress").ToString())
                        litDevCompleted.Text = If(reader.IsDBNull(reader.GetOrdinal("DevCompleted")), "0", reader("DevCompleted").ToString())
                        litInTesting.Text = If(reader.IsDBNull(reader.GetOrdinal("InTesting")), "0", reader("InTesting").ToString())
                        litPendingQC.Text = If(reader.IsDBNull(reader.GetOrdinal("PendingQC")), "0", reader("PendingQC").ToString())
                        litPendingSupport.Text = If(reader.IsDBNull(reader.GetOrdinal("PendingSupport")), "0", reader("PendingSupport").ToString())
                        litSupportVerified.Text = If(reader.IsDBNull(reader.GetOrdinal("SupportVerified")), "0", reader("SupportVerified").ToString())
                        litPendingMerge.Text = If(reader.IsDBNull(reader.GetOrdinal("PendingMerge")), "0", reader("PendingMerge").ToString())
                        litCompleted.Text = If(reader.IsDBNull(reader.GetOrdinal("Completed")), "0", reader("Completed").ToString())
                        litReopened.Text = If(reader.IsDBNull(reader.GetOrdinal("Reopened")), "0", reader("Reopened").ToString())
                        litTestingCompleted.Text = If(reader.IsDBNull(reader.GetOrdinal("TestingCompleted")), "0", reader("TestingCompleted").ToString())
                        LitHold.Text = If(reader.IsDBNull(reader.GetOrdinal("Hold")), "0", reader("Hold").ToString())
                        LitReject.Text = If(reader.IsDBNull(reader.GetOrdinal("Reject")), "0", reader("Reject").ToString())
                        litDelayed.Text = If(reader.IsDBNull(reader.GetOrdinal("DelayedTasks")), "0", reader("DelayedTasks").ToString())
                    End If
                End Using
            End Using
        End Using
    End Sub
    Private Sub LoadCustomers()
        Dim customers As List(Of Object) = DataAccess.GetCustomers()
        ddlCustomers.DataSource = customers
        ddlCustomers.DataTextField = "CustomerName"
        ddlCustomers.DataValueField = "CustomerID"
        ddlCustomers.DataBind()
        ddlCustomers.Items.Insert(0, New ListItem("-- All Customers --", "0"))
    End Sub

    Protected Sub Filter_Changed(sender As Object, e As EventArgs)
        Dim fromDate As Nullable(Of DateTime) = Nothing
        Dim toDate As Nullable(Of DateTime) = Nothing
        Dim developerId As Integer = CInt(Session("UserID")) ' Session se ID lein

        Dim tempFromDate As DateTime
        If DateTime.TryParse(txtFromDate.Text, tempFromDate) Then fromDate = tempFromDate

        Dim tempToDate As DateTime
        If DateTime.TryParse(txtToDate.Text, tempToDate) Then toDate = tempToDate

        Dim selectedCustomerId As Integer = Convert.ToInt32(ddlCustomers.SelectedValue)

        LoadDashboardStats(developerId, fromDate, toDate, selectedCustomerId)
    End Sub

    Protected Sub btnShowAll_Click(sender As Object, e As EventArgs)
        txtFromDate.Text = ""
        txtToDate.Text = ""
        ddlCustomers.SelectedIndex = 0
        Filter_Changed(sender, e)
    End Sub

    <WebMethod()>
    Public Shared Function GetKpiGridDataForDeveloper(status As String, fromDateString As String, toDateString As String, customerId As Integer) As List(Of PointData)
        Try
            Dim fromDate As Nullable(Of DateTime) = Nothing
            If Not String.IsNullOrEmpty(fromDateString) Then
                Dim tempDate As DateTime
                If DateTime.TryParse(fromDateString, tempDate) Then fromDate = tempDate
            End If

            Dim toDate As Nullable(Of DateTime) = Nothing
            If Not String.IsNullOrEmpty(toDateString) Then
                Dim tempDate As DateTime
                If DateTime.TryParse(toDateString, tempDate) Then toDate = tempDate
            End If

            ' Session se developer ki ID lein taaki koi aur developer ID na bhej sake
            Dim developerId As Integer = CInt(HttpContext.Current.Session("UserID"))

            ' Naye DataAccess function ko call karein
            Return DataAccess.GetFilteredPointsForGridForDeveloper(status, fromDate, toDate, developerId, customerId)

        Catch ex As Exception
            ' Error handling
            Dim errorList As New List(Of PointData)()
            Return errorList
        End Try
    End Function

End Class