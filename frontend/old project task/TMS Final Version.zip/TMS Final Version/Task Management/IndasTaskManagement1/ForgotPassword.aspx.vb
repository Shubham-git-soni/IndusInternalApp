﻿Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Net.Mail
Imports System.Net

Partial Class ForgotPassword
    Inherits System.Web.UI.Page

    Protected Sub btnSubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        Dim email As String = txtEmail.Text.Trim()

        If email = "" Then
            lblMessage.Text = "❌ Please enter your email."
            lblMessage.CssClass = "alert alert-danger"
            lblMessage.Visible = True
            Return
        End If

        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            Dim cmd As New SqlCommand("SELECT UserID FROM Users WHERE Email = @Email", conn)
            cmd.Parameters.AddWithValue("@Email", email)

            conn.Open()
            Dim userIdObj = cmd.ExecuteScalar()

            If userIdObj IsNot Nothing Then
                ' ✅ Generate token
                Dim token As String = Guid.NewGuid().ToString()

                ' ✅ Save token and expiry
                Dim updateCmd As New SqlCommand("UPDATE Users SET ResetToken = @Token, TokenExpiry = @Expiry WHERE Email = @Email", conn)
                updateCmd.Parameters.AddWithValue("@Token", token)
                updateCmd.Parameters.AddWithValue("@Expiry", DateTime.Now.AddHours(1))
                updateCmd.Parameters.AddWithValue("@Email", email)
                updateCmd.ExecuteNonQuery()

                ' ✅ Send Email
                SendResetEmail(email, token)

                lblMessage.Text = "✅ Reset link sent successfully to your email."
                lblMessage.CssClass = "alert alert-success"
                lblMessage.Visible = True
                txtEmail.Text = ""
            Else
                lblMessage.Text = "❌ Email not found. Please check and try again."
                lblMessage.CssClass = "alert alert-danger"
                lblMessage.Visible = True
            End If
        End Using
    End Sub

    Private Sub SendResetEmail(email As String, token As String)
        Dim resetUrl As String = "https://localhost:44365/ResetPassword.aspx?token=" & token
        Dim body As String = "Hi,<br/><br/>Click the link below to reset your password:<br/>" &
                             $"<a href='{resetUrl}'>Reset Your Password</a><br/><br/>This link will expire in 1 hour.<br/><br/>Thank you!"

        Dim smtp As New SmtpClient("smtp.gmail.com", 587)
        smtp.EnableSsl = True

        Dim senderEmail As String = ConfigurationManager.AppSettings("SenderEmail")
        Dim senderPassword As String = ConfigurationManager.AppSettings("SenderPassword")

        smtp.Credentials = New NetworkCredential(senderEmail, senderPassword)

        Dim message As New MailMessage()
        message.From = New MailAddress(senderEmail, "Indas Task Management")
        message.To.Add(email)
        message.Subject = "Reset Password - Indas Task"
        message.Body = body
        message.IsBodyHtml = True

        smtp.Send(message)
    End Sub
End Class
