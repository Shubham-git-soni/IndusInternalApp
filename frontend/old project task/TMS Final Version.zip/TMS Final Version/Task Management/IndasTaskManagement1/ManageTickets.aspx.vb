﻿Imports System.Collections.Generic
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization
Imports System.Web.Services
Imports IndasTaskManagement1.DataAccess

Partial Public Class ManageTickets
    Inherits BasePage
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            PopulateDataForClient()
        End If
    End Sub

    Private Sub PopulateDataForClient()
        Dim serializer As New JavaScriptSerializer()

        Dim customers = DataAccess.GetCustomers()
        hdnCustomersData.Value = serializer.Serialize(customers)

        Dim products = DataAccess.GetProducts()
        hdnProductsData.Value = serializer.Serialize(products)

        Dim reportedByUsers = DataAccess.GetUsers()
        hdnReportedByUsersData.Value = serializer.Serialize(reportedByUsers)

        Dim assignedToUsers = DataAccess.GetUsers("Developer")
        hdnAssignedToUsersData.Value = serializer.Serialize(assignedToUsers)
    End Sub

    <WebMethod()>
    Public Shared Function GetTicketsForGrid() As List(Of TicketData)
        Return DataAccess.GetTicketsForMainGrid()
    End Function

    <WebMethod()>
    Public Shared Function GetPointsForTicket(ByVal ticketId As Integer) As List(Of PointData)
        Return DataAccess.GetPointsByTicketId(ticketId)
    End Function

    <WebMethod()>
    Public Shared Function GetPointDetails(ByVal pointId As Integer) As PointData
        Return DataAccess.GetPointDetailsById(pointId)
    End Function

    Public Shared Function GetAttachmentsForHistoryCycle(ByVal pointId As Integer) As List(Of PointHistoryData)

        Return DataAccess.GetPointHistory(pointId)

    End Function

    <WebMethod()>
    Public Shared Function GetPointHistoryForGrid(ByVal pointId As Integer) As List(Of PointHistoryData)
        Return DataAccess.GetPointHistory(pointId)
    End Function



    <WebMethod()>
    Public Shared Function GetAttachments(pointId As Integer) As List(Of AttachmentData)

        Return DataAccess.GetAttachmentsForHistoryCycle(pointId)

    End Function

    <WebMethod()>
    Public Shared Sub UpdatePointOrder(orderedPointIds As List(Of Integer))
        DataAccess.UpdatePointOrder(orderedPointIds)
    End Sub

    <WebMethod()>
    Public Shared Function CloseTicket(pointId As Integer) As String
        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
            Dim query As String = "SELECT Status FROM Points WHERE PointID = @PointID"
            Using cmd As New SqlCommand(Query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                Dim currentStatus As String = Convert.ToString(cmd.ExecuteScalar())

                If currentStatus = "Closed" Then
                    Return "AlreadyClosed"
                Else
                    ' Close ticket
                    Dim success As Boolean = DataAccess.UpdatePointStatusAndDate(pointId, "Closed", "DateClosed", DateTime.Now)
                    If success Then
                        Return "Closed"
                    Else
                        Return "Failed"
                    End If
                End If
            End Using
        End Using
    End Function


    <WebMethod()>
    Public Shared Function ReassignTicket(pointId As Integer, newDeveloperId As Integer) As Boolean
        Try
            Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
                Dim query As String = "UPDATE Points SET AssignedToID = @DevId WHERE PointID = @PointID"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@DevId", newDeveloperId)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    Dim rows As Integer = cmd.ExecuteNonQuery()
                    Return rows > 0
                End Using
            End Using
        Catch ex As Exception
            ' log error
            Return False
        End Try
    End Function

    <WebMethod()>
    Public Shared Function ReassignPoint(pointId As Integer, newDeveloperId As Integer) As Boolean
        Try

            Return DataAccess.ReassignSinglePoint(pointId, newDeveloperId)
        Catch ex As Exception
            ' Log error
            Return False
        End Try
    End Function

    <WebMethod()>
    Public Shared Function SetTodayToDo(pointIds As List(Of Integer), toDoDate As DateTime) As Object
        Try
            If pointIds Is Nothing OrElse pointIds.Count = 0 Then
                Return New With {.success = False, .message = "No points selected."}
            End If

            Dim success As Boolean = DataAccess.SetToDoDateForPoints(pointIds, toDoDate)

            If success Then
                Return New With {.success = True, .message = $"{pointIds.Count} point(s) have been set for {toDoDate.ToShortDateString()}."}
            Else
                Return New With {.success = False, .message = "Failed to set To-Do date."}
            End If
        Catch ex As Exception
            Return New With {.success = False, .message = "An error occurred: " & ex.Message}
        End Try
    End Function


    ' ✅✅✅ YEH NAYA WEBMETHOD HAI WORKLOAD FETCH KARNE KE LIYE ✅✅✅
    <WebMethod()>
    Public Shared Function GetDeveloperWorkload(developerId As Integer) As Object
        Try
            Dim workloadData = DataAccess.GetWorkloadForDeveloper(developerId)
            Return New With {.success = True, .data = workloadData}
        Catch ex As Exception
            Return New With {.success = False, .message = ex.Message}
        End Try
    End Function
End Class
