﻿'Public Class Support
'    Inherits System.Web.UI.MasterPage

'    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
'        ' Validate session
'        If Session("UserID") Is Nothing OrElse Session("Role") Is Nothing OrElse Not Session("Role").ToString().Equals("Support", StringComparison.OrdinalIgnoreCase) Then
'            Response.Redirect("~/Login.aspx")
'        End If

'        If Not IsPostBack Then
'            If Session("FullName") IsNot Nothing Then
'                litUserName.Text = Session("FullName").ToString()
'            End If
'        End If
'    End Sub

'    Protected Sub lnkLogout_Click(ByVal sender As Object, ByVal e As EventArgs)
'        Session.Clear()
'        Session.Abandon()
'        Response.Redirect("~/Login.aspx")
'    End Sub
'End Class
