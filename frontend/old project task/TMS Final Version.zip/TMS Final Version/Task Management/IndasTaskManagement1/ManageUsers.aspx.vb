﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Script.Serialization
Imports System.Web.Services

Public Class ManageUsers
    Inherits BasePage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
    End Sub

    <WebMethod()>
    Public Shared Function GetUsers() As Object
        Dim dt As DataTable = UsersDAL.GetAllUsers()
        Dim users As New List(Of Dictionary(Of String, Object))()

        For Each row As DataRow In dt.Rows
            Dim user As New Dictionary(Of String, Object)()
            For Each col As DataColumn In dt.Columns
                If col.ColumnName = "DateCreated" Then
                    Dim rawDate As DateTime = Convert.ToDateTime(row("DateCreated"))
                    user.Add("DateCreated", rawDate.ToString("yyyy-MM-ddTHH:mm:ss"))
                Else
                    user.Add(col.ColumnName, row(col))
                End If
            Next

            users.Add(user)
        Next

        Return users
    End Function

    <WebMethod()>
    Public Shared Function UpdateUser(key As Integer, values As Object) As Object
        Try
            Dim serializer As New JavaScriptSerializer()
            Dim dict As Dictionary(Of String, Object) = serializer.ConvertToType(Of Dictionary(Of String, Object))(values)

            UsersDAL.UpdateUser(key, dict)
            Return New With {.success = True, .message = "✅ User updated successfully."}
        Catch ex As Exception
            ' Optional logging
            Return New With {.success = False, .message = "❌ Update failed: " & ex.Message}
        End Try
    End Function



    <WebMethod()>
    Public Shared Function DeleteUser(key As Integer) As Object
        Try
            UsersDAL.DeleteUser(key)
            Return True
        Catch ex As Exception
            ' Optional logging here
            Return False
        End Try
    End Function

    <WebMethod()>
    Public Shared Function AddUser(values As Dictionary(Of String, Object)) As Object
        Try
            Dim fullName As String = If(values.ContainsKey("FullName"), values("FullName").ToString(), "")
            Dim email As String = If(values.ContainsKey("Email"), values("Email").ToString(), "")
            Dim role As String = If(values.ContainsKey("Role"), values("Role").ToString(), "user")
            Dim isActive As Boolean = If(values.ContainsKey("IsActive"), Convert.ToBoolean(values("IsActive")), True)
            Dim password As String = If(values.ContainsKey("Password"), values("Password").ToString(), "")

            ' ❌ No default password
            If String.IsNullOrWhiteSpace(password) Then
                Return New With {.success = False, .message = "⚠️ Please enter a password"}
            End If

            ' ✅ Check if email already exists
            If UsersDAL.CheckEmailExists(email) Then
                Return New With {.success = False, .message = "❌ This email is already registered. Please try another one."}
            End If

            ' ✅ Insert new user
            UsersDAL.InsertUser(fullName, email, role, isActive, password)

            Return New With {.success = True, .message = "✅ User registered successfully!"}

        Catch ex As Exception
            Return New With {.success = False, .message = "⚠️ AddUser failed: " & ex.Message}
        End Try
    End Function


End Class
