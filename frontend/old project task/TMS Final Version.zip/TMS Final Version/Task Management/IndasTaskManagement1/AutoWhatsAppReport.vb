﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Net
Imports System.IO
Imports System.Text

Module AutoWhatsAppReport

    ' 🔹 1. Get statistics from DB
    Public Function GetPointStatistics(ByVal ticketId As Integer) As Dictionary(Of String, String)
        Dim stats As New Dictionary(Of String, String)()
        Dim query As String = "
        SELECT
            ISNULL(COUNT(*), 0) AS TotalPoints,
            ISNULL(SUM(CASE WHEN Status = 'Queue' THEN 1 ELSE 0 END), 0) AS Pending,
            ISNULL(SUM(CASE WHEN Status = 'Assigned' THEN 1 ELSE 0 END), 0) AS Assigned,
            ISNULL(SUM(CASE WHEN Status = 'In Progress' THEN 1 ELSE 0 END), 0) AS InProgress,
            ISNULL(SUM(CASE WHEN Status = 'In-Testing' THEN 1 ELSE 0 END), 0) AS InTesting,
            ISNULL(SUM(CASE WHEN Status = 'PendingQC' THEN 1 ELSE 0 END), 0) AS PendingQC,
            ISNULL(SUM(CASE WHEN Status = 'Reopened' THEN 1 ELSE 0 END), 0) AS Reopened,
            ISNULL(SUM(CASE WHEN Status = 'Testing-Completed' THEN 1 ELSE 0 END), 0) AS TestingCompleted,
            ISNULL(SUM(CASE WHEN Status IN ('Completed', 'Closed') THEN 1 ELSE 0 END), 0) AS Completed
        FROM Points
        WHERE CONVERT(DATE, DateCreated) = CONVERT(DATE, GETDATE())"

        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@TicketID", ticketId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    If reader.Read() Then
                        stats("TotalPoints") = reader("TotalPoints").ToString()
                        stats("Pending") = reader("Pending").ToString()
                        stats("Assigned") = reader("Assigned").ToString()
                        stats("InProgress") = reader("InProgress").ToString()
                        stats("InTesting") = reader("InTesting").ToString()
                        stats("PendingQC") = reader("PendingQC").ToString()
                        stats("Reopened") = reader("Reopened").ToString()
                        stats("TestingCompleted") = reader("TestingCompleted").ToString()
                        stats("Completed") = reader("Completed").ToString()
                    End If
                End Using
            End Using
        End Using
        Return stats
    End Function

    ' 🔹 2. Prepare report message
    Public Function GetStatusReport() As String
        Dim stats As Dictionary(Of String, String) = GetPointStatistics(0)
        Dim msg As String = ""

        If stats IsNot Nothing AndAlso stats.Count > 0 Then
            msg = "📊 *Daily Status Report* 📊" & vbCrLf & vbCrLf &
                  "🔹 Total Points: " & stats("TotalPoints") & vbCrLf &
                  "⏳ Pending: " & stats("Pending") & vbCrLf &
                  "👨‍💻 Assigned: " & stats("Assigned") & vbCrLf &
                  "⚡ In Progress: " & stats("InProgress") & vbCrLf &
                  "🧪 In-Testing: " & stats("InTesting") & vbCrLf &
                  "🔍 Pending QC: " & stats("PendingQC") & vbCrLf &
                  "♻️ Reopened: " & stats("Reopened") & vbCrLf &
                  "✅ Testing Completed: " & stats("TestingCompleted") & vbCrLf &
                  "🏁 Completed: " & stats("Completed") & vbCrLf & vbCrLf &
                  "📅 Report Generated At: " & DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt")
        End If

        Return msg
    End Function

    ' 🔹 3. Send WhatsApp Message (using Global.asax values)
    Public Function SendWhatsAppMessage(ByVal phone As String, ByVal message As String) As String
        Try
            Dim secret As String = Global_asax.WhatsFlySecret
            Dim account As String = Global_asax.WhatsFlyAccount
            Dim apiUrl As String = Global_asax.WhatsFlyApiUrl

            If String.IsNullOrEmpty(phone) Then Return "Failed: Phone number is empty."
            If Not phone.StartsWith("+") Then phone = "+91" & phone

            Dim payload As New System.Collections.Specialized.NameValueCollection()
            payload.Add("secret", secret)
            payload.Add("account", account)
            payload.Add("recipient", phone)
            payload.Add("message", message)
            payload.Add("type", "text")

            Using client As New WebClient()
                Dim responseBytes As Byte() = client.UploadValues(apiUrl, "POST", payload)
                Dim result As String = Encoding.UTF8.GetString(responseBytes)
                If result.ToLower().Contains("""success"":true") Then
                    Return "Success: " & result
                Else
                    Return "Failed: " & result
                End If
            End Using
        Catch ex As WebException
            If ex.Response IsNot Nothing Then
                Using reader As New StreamReader(ex.Response.GetResponseStream())
                    Dim errorResponse As String = reader.ReadToEnd()
                    Return "Error: " & ex.Message & " | Response: " & errorResponse
                End Using
            Else
                Return "Error: " & ex.Message
            End If
        Catch ex As Exception
            Return "Error: " & ex.Message
        End Try
    End Function

    ' 🔹 4. Run whole process (get stats → prepare msg → send)
    Public Sub RunDailyReport()
        Dim reportMessage As String = GetStatusReport()
        Dim result As String = SendWhatsAppMessage(Global_asax.ReportMobile, reportMessage)
        ' Optional: log result
    End Sub

End Module