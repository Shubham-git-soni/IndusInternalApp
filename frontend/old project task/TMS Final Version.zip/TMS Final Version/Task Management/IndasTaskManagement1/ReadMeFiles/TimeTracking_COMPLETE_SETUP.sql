-- ================================================================
-- TIME TRACKING FEATURE - COMPLETE DATABASE SETUP
-- ================================================================
-- This is the COMPLETE script with ALL database changes
-- Run this script on a FRESH database for your friend
-- ================================================================
--
-- CHANGES INCLUDED:
-- 1. Points table: ExpectedMinutes, TotalTimeSpent, PauseTimeMinutes, LastActionTime
-- 2. PointHistory table: TimeSpentMinutes, ExpectedMinutes, ExtraTimeMinutes
-- 3. PointTimeLog table: Complete action tracking
-- 4. sp_CalculatePointTotalTime: Stored procedure for time calculation
-- 5. trg_UpdateTotalTimeSpent: Trigger for auto-calculation
--
-- ================================================================

USE [YourDatabaseName]  -- ⚠️ CHANGE THIS to your actual database name
GO

PRINT '================================================================';
PRINT 'TIME TRACKING FEATURE - DATABASE SETUP';
PRINT '================================================================';
PRINT '';

-- ================================================================
-- STEP 1: Add columns to Points table
-- ================================================================
PRINT 'STEP 1: Adding columns to Points table...';
PRINT '';

-- ExpectedMinutes (admin sets this when creating point)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'ExpectedMinutes')
BEGIN
    ALTER TABLE Points ADD ExpectedMinutes INT NULL;
    PRINT '✅ Added ExpectedMinutes column to Points table';
END
ELSE
    PRINT '⚠️ ExpectedMinutes column already exists in Points table';

-- TotalTimeSpent (calculated actual work time)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'TotalTimeSpent')
BEGIN
    ALTER TABLE Points ADD TotalTimeSpent INT NULL;
    PRINT '✅ Added TotalTimeSpent column to Points table';
END
ELSE
    PRINT '⚠️ TotalTimeSpent column already exists in Points table';

-- PauseTimeMinutes (total pause duration in minutes)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'PauseTimeMinutes')
BEGIN
    ALTER TABLE Points ADD PauseTimeMinutes INT DEFAULT 0;
    PRINT '✅ Added PauseTimeMinutes column to Points table';
END
ELSE
    PRINT '⚠️ PauseTimeMinutes column already exists in Points table';

-- LastActionTime (timestamp of last action)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'LastActionTime')
BEGIN
    ALTER TABLE Points ADD LastActionTime DATETIME NULL;
    PRINT '✅ Added LastActionTime column to Points table';
END
ELSE
    PRINT '⚠️ LastActionTime column already exists in Points table';

PRINT '';

-- ================================================================
-- STEP 2: Create PointHistory table (if it doesn't exist)
-- ================================================================
PRINT 'STEP 2: Creating PointHistory table...';
PRINT '';

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PointHistory') AND type = 'U')
BEGIN
    CREATE TABLE PointHistory (
        HistoryID INT IDENTITY(1,1) PRIMARY KEY,
        PointID INT NOT NULL,
        DeveloperID INT NULL,
        TesterID INT NULL,

        -- Developer timeline
        StartDate DATETIME NULL,
        CompleteDate DATETIME NULL,
        DeveloperRemark NVARCHAR(MAX) NULL,

        -- Tester timeline
        TesterStartDate DATETIME NULL,
        TesterCompleteDate DATETIME NULL,
        TesterRemark NVARCHAR(MAX) NULL,

        -- Status tracking
        CycleStatus NVARCHAR(50) NULL, -- 'Completed', 'Reopened', 'Rejected', etc.
        CreatedDate DATETIME DEFAULT GETDATE(),

        FOREIGN KEY (PointID) REFERENCES Points(PointID) ON DELETE CASCADE,
        FOREIGN KEY (DeveloperID) REFERENCES Users(UserID),
        FOREIGN KEY (TesterID) REFERENCES Users(UserID)
    );
    PRINT '✅ Created PointHistory table';
END
ELSE
    PRINT '⚠️ PointHistory table already exists';

PRINT '';

-- ================================================================
-- STEP 3: Add time tracking columns to PointHistory table
-- ================================================================
PRINT 'STEP 3: Adding time tracking columns to PointHistory...';
PRINT '';

-- TimeSpentMinutes (actual time spent by developer)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'TimeSpentMinutes')
BEGIN
    ALTER TABLE PointHistory ADD TimeSpentMinutes INT NULL;
    PRINT '✅ Added TimeSpentMinutes column to PointHistory table';
END
ELSE
    PRINT '⚠️ TimeSpentMinutes column already exists in PointHistory table';

-- ExpectedMinutes (snapshot from Points at completion)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'ExpectedMinutes')
BEGIN
    ALTER TABLE PointHistory ADD ExpectedMinutes INT NULL;
    PRINT '✅ Added ExpectedMinutes column to PointHistory table';
END
ELSE
    PRINT '⚠️ ExpectedMinutes column already exists in PointHistory table';

-- ExtraTimeMinutes (calculated: TimeSpentMinutes - ExpectedMinutes)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'ExtraTimeMinutes')
BEGIN
    ALTER TABLE PointHistory ADD ExtraTimeMinutes INT NULL;
    PRINT '✅ Added ExtraTimeMinutes column to PointHistory table';
END
ELSE
    PRINT '⚠️ ExtraTimeMinutes column already exists in PointHistory table';

PRINT '';

-- ================================================================
-- STEP 4: Create PointTimeLog table for tracking pause/resume
-- ================================================================
PRINT 'STEP 4: Creating PointTimeLog table...';
PRINT '';

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PointTimeLog') AND type = 'U')
BEGIN
    CREATE TABLE PointTimeLog (
        LogID INT IDENTITY(1,1) PRIMARY KEY,
        PointID INT NOT NULL,
        Action NVARCHAR(50) NOT NULL, -- 'Start', 'Pause', 'Resume', 'Complete', 'Reopen'
        ActionTime DATETIME DEFAULT GETDATE(),
        PerformedByID INT NULL,
        Remarks NVARCHAR(500) NULL,

        FOREIGN KEY (PointID) REFERENCES Points(PointID) ON DELETE CASCADE,
        FOREIGN KEY (PerformedByID) REFERENCES Users(UserID)
    );

    CREATE INDEX IX_PointTimeLog_PointID ON PointTimeLog(PointID);
    CREATE INDEX IX_PointTimeLog_ActionTime ON PointTimeLog(ActionTime);

    PRINT '✅ Created PointTimeLog table with indexes';
END
ELSE
    PRINT '⚠️ PointTimeLog table already exists';

PRINT '';

-- ================================================================
-- STEP 5: Create stored procedure for calculating total time
-- ================================================================
PRINT 'STEP 5: Creating stored procedure sp_CalculatePointTotalTime...';
PRINT '';

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'sp_CalculatePointTotalTime') AND type = 'P')
BEGIN
    DROP PROCEDURE sp_CalculatePointTotalTime;
    PRINT '⚠️ Dropped existing sp_CalculatePointTotalTime procedure';
END

GO

CREATE PROCEDURE sp_CalculatePointTotalTime
    @PointID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @TotalMinutes INT = 0;
    DECLARE @PauseMinutes INT = 0;
    DECLARE @StartTime DATETIME;
    DECLARE @PauseStartTime DATETIME;
    DECLARE @LastAction NVARCHAR(50);
    DECLARE @CurrentTime DATETIME = GETDATE();

    -- Get all time logs for this point
    DECLARE time_cursor CURSOR FOR
        SELECT Action, ActionTime
        FROM PointTimeLog
        WHERE PointID = @PointID
        ORDER BY ActionTime;

    DECLARE @Action NVARCHAR(50), @ActionTime DATETIME;

    OPEN time_cursor;
    FETCH NEXT FROM time_cursor INTO @Action, @ActionTime;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @Action = 'Start' OR @Action = 'Resume'
        BEGIN
            SET @StartTime = @ActionTime;
            -- If resuming after pause, calculate pause duration
            IF @PauseStartTime IS NOT NULL
            BEGIN
                SET @PauseMinutes = @PauseMinutes + DATEDIFF(MINUTE, @PauseStartTime, @ActionTime);
                SET @PauseStartTime = NULL;
            END
        END
        ELSE IF @Action = 'Pause' AND @StartTime IS NOT NULL
        BEGIN
            SET @TotalMinutes = @TotalMinutes + DATEDIFF(MINUTE, @StartTime, @ActionTime);
            SET @PauseStartTime = @ActionTime;
            SET @StartTime = NULL;
        END
        ELSE IF @Action = 'Complete' AND @StartTime IS NOT NULL
        BEGIN
            SET @TotalMinutes = @TotalMinutes + DATEDIFF(MINUTE, @StartTime, @ActionTime);
            SET @StartTime = NULL;
        END

        FETCH NEXT FROM time_cursor INTO @Action, @ActionTime;
    END

    CLOSE time_cursor;
    DEALLOCATE time_cursor;

    -- If still in progress, add time until now
    IF @StartTime IS NOT NULL
    BEGIN
        SET @TotalMinutes = @TotalMinutes + DATEDIFF(MINUTE, @StartTime, @CurrentTime);
    END

    -- If currently paused, add pause time until now
    IF @PauseStartTime IS NOT NULL
    BEGIN
        SET @PauseMinutes = @PauseMinutes + DATEDIFF(MINUTE, @PauseStartTime, @CurrentTime);
    END

    -- Update the Points table
    UPDATE Points
    SET TotalTimeSpent = @TotalMinutes,
        PauseTimeMinutes = @PauseMinutes
    WHERE PointID = @PointID;

    SELECT @TotalMinutes AS TotalMinutes, @PauseMinutes AS PauseMinutes;
END
GO

PRINT '✅ Created sp_CalculatePointTotalTime stored procedure';
PRINT '';

-- ================================================================
-- STEP 6: Create trigger to auto-update TotalTimeSpent
-- ================================================================
PRINT 'STEP 6: Creating trigger trg_UpdateTotalTimeSpent...';
PRINT '';

IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_UpdateTotalTimeSpent')
BEGIN
    DROP TRIGGER trg_UpdateTotalTimeSpent;
    PRINT '⚠️ Dropped existing trg_UpdateTotalTimeSpent trigger';
END

GO

CREATE TRIGGER trg_UpdateTotalTimeSpent
ON PointTimeLog
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Update TotalTimeSpent for affected points
    DECLARE @PointID INT;
    SELECT @PointID = PointID FROM inserted;

    EXEC sp_CalculatePointTotalTime @PointID;
END
GO

PRINT '✅ Created trg_UpdateTotalTimeSpent trigger';
PRINT '';

-- ================================================================
-- STEP 7: Verification queries
-- ================================================================
PRINT '================================================================';
PRINT 'VERIFICATION - Checking all objects created successfully';
PRINT '================================================================';
PRINT '';

-- Check Points table columns
SELECT
    'Points Table Columns' AS TableInfo,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE,
    COLUMN_DEFAULT
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Points'
    AND COLUMN_NAME IN ('ExpectedMinutes', 'TotalTimeSpent', 'PauseTimeMinutes', 'LastActionTime')
ORDER BY COLUMN_NAME;

-- Check PointHistory table columns
SELECT
    'PointHistory Table Columns' AS TableInfo,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'PointHistory'
    AND COLUMN_NAME IN ('TimeSpentMinutes', 'ExpectedMinutes', 'ExtraTimeMinutes')
ORDER BY COLUMN_NAME;

-- Check PointTimeLog table
SELECT
    'PointTimeLog Table Structure' AS TableInfo,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'PointTimeLog'
ORDER BY ORDINAL_POSITION;

-- Check stored procedure
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'sp_CalculatePointTotalTime') AND type = 'P')
    PRINT '✅ Stored procedure sp_CalculatePointTotalTime exists';
ELSE
    PRINT '❌ Stored procedure sp_CalculatePointTotalTime NOT found';

-- Check trigger
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_UpdateTotalTimeSpent')
    PRINT '✅ Trigger trg_UpdateTotalTimeSpent exists';
ELSE
    PRINT '❌ Trigger trg_UpdateTotalTimeSpent NOT found';

PRINT '';
PRINT '================================================================';
PRINT '✅ DATABASE SETUP COMPLETED SUCCESSFULLY!';
PRINT '================================================================';
PRINT '';
PRINT 'DATABASE CHANGES SUMMARY:';
PRINT '------------------------';
PRINT '';
PRINT '1. Points Table - Added 4 columns:';
PRINT '   • ExpectedMinutes (INT NULL) - Admin sets expected time';
PRINT '   • TotalTimeSpent (INT NULL) - Calculated actual work time';
PRINT '   • PauseTimeMinutes (INT DEFAULT 0) - Total pause duration';
PRINT '   • LastActionTime (DATETIME NULL) - Last action timestamp';
PRINT '';
PRINT '2. PointHistory Table - Added 3 columns:';
PRINT '   • TimeSpentMinutes (INT NULL) - Actual time in this cycle';
PRINT '   • ExpectedMinutes (INT NULL) - Expected time snapshot';
PRINT '   • ExtraTimeMinutes (INT NULL) - Delay time (Actual - Expected)';
PRINT '';
PRINT '3. PointTimeLog Table - Created new table:';
PRINT '   • Tracks all Start/Pause/Resume/Complete actions';
PRINT '   • Used for accurate time calculation';
PRINT '';
PRINT '4. sp_CalculatePointTotalTime - Stored procedure:';
PRINT '   • Calculates total work time and pause time';
PRINT '   • Automatically updates Points table';
PRINT '';
PRINT '5. trg_UpdateTotalTimeSpent - Trigger:';
PRINT '   • Auto-executes on PointTimeLog changes';
PRINT '   • Keeps time data synchronized';
PRINT '';
PRINT '================================================================';
PRINT 'NEXT STEPS:';
PRINT '================================================================';
PRINT '1. Build your Visual Studio project (F6)';
PRINT '2. Test time tracking in Developer Dashboard:';
PRINT '   - Admin assigns point with expected time';
PRINT '   - Developer uses Start/Pause/Resume/Complete buttons';
PRINT '   - Grid shows Expected, Actual, Pause, Delay times';
PRINT '3. If you need to rollback, run TimeTracking_ROLLBACK.sql';
PRINT '================================================================';
