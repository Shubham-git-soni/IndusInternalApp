-- ================================================================
-- TIME TRACKING FEATURE - SQL SCHEMA CHANGES
-- ================================================================
-- This script adds time tracking functionality to the Points system
-- Run this script in SQL Server Management Studio
-- ================================================================

-- ================================================================
-- STEP 1: Add new columns to Points table
-- ================================================================

-- Add ExpectedMinutes column (time admin expects for completion)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'ExpectedMinutes')
BEGIN
    ALTER TABLE Points ADD ExpectedMinutes INT NULL;
    PRINT 'Added ExpectedMinutes column to Points table';
END
ELSE
    PRINT 'ExpectedMinutes column already exists in Points table';

-- Add TotalTimeSpent column (calculated total time in minutes)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'TotalTimeSpent')
BEGIN
    ALTER TABLE Points ADD TotalTimeSpent INT NULL;
    PRINT 'Added TotalTimeSpent column to Points table';
END
ELSE
    PRINT 'TotalTimeSpent column already exists in Points table';

-- Add PauseTimeMinutes column (track total pause time in minutes)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'PauseTimeMinutes')
BEGIN
    ALTER TABLE Points ADD PauseTimeMinutes INT DEFAULT 0;
    PRINT 'Added PauseTimeMinutes column to Points table';
END
ELSE
    PRINT 'PauseTimeMinutes column already exists in Points table';

-- Add LastActionTime column (track last action timestamp)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'LastActionTime')
BEGIN
    ALTER TABLE Points ADD LastActionTime DATETIME NULL;
    PRINT 'Added LastActionTime column to Points table';
END
ELSE
    PRINT 'LastActionTime column already exists in Points table';


-- ================================================================
-- STEP 2: Create PointHistory table (if it doesn't exist)
-- ================================================================

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PointHistory') AND type = 'U')
BEGIN
    CREATE TABLE PointHistory (
        HistoryID INT IDENTITY(1,1) PRIMARY KEY,
        PointID INT NOT NULL,
        DeveloperID INT NULL,
        TesterID INT NULL,

        -- Developer timeline
        StartDate DATETIME NULL,
        CompleteDate DATETIME NULL,
        DeveloperRemark NVARCHAR(MAX) NULL,

        -- Tester timeline
        TesterStartDate DATETIME NULL,
        TesterCompleteDate DATETIME NULL,
        TesterRemark NVARCHAR(MAX) NULL,

        -- Status tracking
        CycleStatus NVARCHAR(50) NULL, -- 'Completed', 'Reopened', 'Rejected', etc.
        CreatedDate DATETIME DEFAULT GETDATE(),

        FOREIGN KEY (PointID) REFERENCES Points(PointID) ON DELETE CASCADE,
        FOREIGN KEY (DeveloperID) REFERENCES Users(UserID),
        FOREIGN KEY (TesterID) REFERENCES Users(UserID)
    );
    PRINT 'Created PointHistory table';
END
ELSE
    PRINT 'PointHistory table already exists';


-- ================================================================
-- STEP 3: Add time tracking columns to PointHistory table
-- ================================================================

-- Add TimeSpentMinutes for developer
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'TimeSpentMinutes')
BEGIN
    ALTER TABLE PointHistory ADD TimeSpentMinutes INT NULL;
    PRINT 'Added TimeSpentMinutes column to PointHistory table';
END
ELSE
    PRINT 'TimeSpentMinutes column already exists in PointHistory table';

-- Add ExpectedMinutes (snapshot from Points at time of completion)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'ExpectedMinutes')
BEGIN
    ALTER TABLE PointHistory ADD ExpectedMinutes INT NULL;
    PRINT 'Added ExpectedMinutes column to PointHistory table';
END
ELSE
    PRINT 'ExpectedMinutes column already exists in PointHistory table';

-- Add ExtraTimeMinutes (calculated: TimeSpentMinutes - ExpectedMinutes)
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'ExtraTimeMinutes')
BEGIN
    ALTER TABLE PointHistory ADD ExtraTimeMinutes INT NULL;
    PRINT 'Added ExtraTimeMinutes column to PointHistory table';
END
ELSE
    PRINT 'ExtraTimeMinutes column already exists in PointHistory table';


-- ================================================================
-- STEP 4: Create PointTimeLog table for tracking pause/resume actions
-- ================================================================

IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PointTimeLog') AND type = 'U')
BEGIN
    CREATE TABLE PointTimeLog (
        LogID INT IDENTITY(1,1) PRIMARY KEY,
        PointID INT NOT NULL,
        Action NVARCHAR(50) NOT NULL, -- 'Start', 'Pause', 'Resume', 'Complete', 'Reopen'
        ActionTime DATETIME DEFAULT GETDATE(),
        PerformedByID INT NULL,
        Remarks NVARCHAR(500) NULL,

        FOREIGN KEY (PointID) REFERENCES Points(PointID) ON DELETE CASCADE,
        FOREIGN KEY (PerformedByID) REFERENCES Users(UserID)
    );

    CREATE INDEX IX_PointTimeLog_PointID ON PointTimeLog(PointID);
    CREATE INDEX IX_PointTimeLog_ActionTime ON PointTimeLog(ActionTime);

    PRINT 'Created PointTimeLog table';
END
ELSE
    PRINT 'PointTimeLog table already exists';


-- ================================================================
-- STEP 5: Create stored procedure for calculating total time
-- ================================================================

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'sp_CalculatePointTotalTime') AND type = 'P')
    DROP PROCEDURE sp_CalculatePointTotalTime;
GO

CREATE PROCEDURE sp_CalculatePointTotalTime
    @PointID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @TotalMinutes INT = 0;
    DECLARE @PauseMinutes INT = 0;
    DECLARE @StartTime DATETIME;
    DECLARE @PauseStartTime DATETIME;
    DECLARE @LastAction NVARCHAR(50);
    DECLARE @CurrentTime DATETIME = GETDATE();

    -- Get all time logs for this point
    DECLARE time_cursor CURSOR FOR
        SELECT Action, ActionTime
        FROM PointTimeLog
        WHERE PointID = @PointID
        ORDER BY ActionTime;

    DECLARE @Action NVARCHAR(50), @ActionTime DATETIME;

    OPEN time_cursor;
    FETCH NEXT FROM time_cursor INTO @Action, @ActionTime;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @Action = 'Start' OR @Action = 'Resume'
        BEGIN
            SET @StartTime = @ActionTime;
            -- If resuming after pause, calculate pause duration
            IF @PauseStartTime IS NOT NULL
            BEGIN
                SET @PauseMinutes = @PauseMinutes + DATEDIFF(MINUTE, @PauseStartTime, @ActionTime);
                SET @PauseStartTime = NULL;
            END
        END
        ELSE IF @Action = 'Pause' AND @StartTime IS NOT NULL
        BEGIN
            SET @TotalMinutes = @TotalMinutes + DATEDIFF(MINUTE, @StartTime, @ActionTime);
            SET @PauseStartTime = @ActionTime;
            SET @StartTime = NULL;
        END
        ELSE IF @Action = 'Complete' AND @StartTime IS NOT NULL
        BEGIN
            SET @TotalMinutes = @TotalMinutes + DATEDIFF(MINUTE, @StartTime, @ActionTime);
            SET @StartTime = NULL;
        END

        FETCH NEXT FROM time_cursor INTO @Action, @ActionTime;
    END

    CLOSE time_cursor;
    DEALLOCATE time_cursor;

    -- If still in progress, add time until now
    IF @StartTime IS NOT NULL
    BEGIN
        SET @TotalMinutes = @TotalMinutes + DATEDIFF(MINUTE, @StartTime, @CurrentTime);
    END

    -- If currently paused, add pause time until now
    IF @PauseStartTime IS NOT NULL
    BEGIN
        SET @PauseMinutes = @PauseMinutes + DATEDIFF(MINUTE, @PauseStartTime, @CurrentTime);
    END

    -- Update the Points table
    UPDATE Points
    SET TotalTimeSpent = @TotalMinutes,
        PauseTimeMinutes = @PauseMinutes
    WHERE PointID = @PointID;

    SELECT @TotalMinutes AS TotalMinutes, @PauseMinutes AS PauseMinutes;
END
GO

PRINT 'Created sp_CalculatePointTotalTime stored procedure';


-- ================================================================
-- STEP 6: Create trigger to auto-update TotalTimeSpent
-- ================================================================

IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_UpdateTotalTimeSpent')
    DROP TRIGGER trg_UpdateTotalTimeSpent;
GO

CREATE TRIGGER trg_UpdateTotalTimeSpent
ON PointTimeLog
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Update TotalTimeSpent for affected points
    DECLARE @PointID INT;
    SELECT @PointID = PointID FROM inserted;

    EXEC sp_CalculatePointTotalTime @PointID;
END
GO

PRINT 'Created trg_UpdateTotalTimeSpent trigger';


-- ================================================================
-- STEP 7: Verification queries
-- ================================================================

PRINT '';
PRINT '================================================================';
PRINT 'VERIFICATION - Check if all columns were added successfully';
PRINT '================================================================';

-- Check Points table columns
SELECT
    'Points Table Columns' AS TableInfo,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'Points'
    AND COLUMN_NAME IN ('ExpectedMinutes', 'TotalTimeSpent', 'PauseTimeMinutes', 'LastActionTime')
ORDER BY COLUMN_NAME;

-- Check PointHistory table columns
SELECT
    'PointHistory Table Columns' AS TableInfo,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'PointHistory'
    AND COLUMN_NAME IN ('TimeSpentMinutes', 'ExpectedMinutes', 'ExtraTimeMinutes')
ORDER BY COLUMN_NAME;

-- Check PointTimeLog table
SELECT
    'PointTimeLog Table' AS TableInfo,
    COLUMN_NAME,
    DATA_TYPE,
    IS_NULLABLE
FROM INFORMATION_SCHEMA.COLUMNS
WHERE TABLE_NAME = 'PointTimeLog'
ORDER BY ORDINAL_POSITION;

PRINT '';
PRINT '================================================================';
PRINT 'SQL SCHEMA CHANGES COMPLETED SUCCESSFULLY!';
PRINT '================================================================';
PRINT 'Next Steps:';
PRINT '1. Update VB.NET PointData class to include new properties';
PRINT '2. Update UI to show time tracking controls';
PRINT '3. Implement backend logic for Start/Pause/Resume/Complete';
PRINT '================================================================';
