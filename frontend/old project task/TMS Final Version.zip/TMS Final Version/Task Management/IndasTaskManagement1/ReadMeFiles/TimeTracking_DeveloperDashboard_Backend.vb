' ================================================================
' TIME TRACKING FEATURE - DEVELOPER DASHBOARD BACKEND CODE
' ================================================================
' Add these WebMethods to DashboardDeveloper.aspx.vb
' ================================================================

    ' ================================================================
    ' PAUSE POINT TIMER
    ' ================================================================
    <WebMethod()>
    Public Shared Function PausePointTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "Ticket is closed"}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            Return DataAccess.PausePointTimer(pointId, userId)

        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' ================================================================
    ' RESUME POINT TIMER
    ' ================================================================
    <WebMethod()>
    Public Shared Function ResumePointTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "Ticket is closed"}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            Return DataAccess.ResumePointTimer(pointId, userId)

        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' ================================================================
    ' COMPLETE POINT TIMER (UPDATE THE EXISTING ONE)
    ' ================================================================
    ' REPLACE your existing CompletePointTimer function with this:

    <WebMethod()>
    Public Shared Function CompletePointTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "Ticket is closed"}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            Return DataAccess.CompletePointTimer(pointId, userId)

        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' ================================================================
    ' GET TIME LOGS FOR A POINT
    ' ================================================================
    <WebMethod()>
    Public Shared Function GetTimeLogsForPoint(pointId As Integer) As List(Of PointTimeLogData)
        Try
            Return DataAccess.GetTimeLogsForPoint(pointId)
        Catch ex As Exception
            Return New List(Of PointTimeLogData)()
        End Try
    End Function

    ' ================================================================
    ' GET POINT TIME SUMMARY
    ' ================================================================
    <WebMethod()>
    Public Shared Function GetPointTimeSummary(pointId As Integer) As Object
        Try
            Return DataAccess.GetPointTimeSummary(pointId)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function


' ================================================================
' NOTES FOR EXISTING METHODS
' ================================================================
'
' 1. UPDATE StartPointTimer:
'    Replace the current implementation to use the new DataAccess method:
'
'    <WebMethod()>
'    Public Shared Function StartPointTimer(pointId As Integer) As Boolean
'        Try
'            If DataAccess.IsTicketClosed(pointId) Then
'                Return False
'            End If
'
'            Dim userId As Integer = HttpContext.Current.Session("UserID")
'            Dim result = DataAccess.StartPointTimer(pointId, userId)
'            Return result.success
'        Catch ex As Exception
'            Return False
'        End Try
'    End Function
'
' 2. The existing SendPointToQC method should call
'    DataAccess.SaveCurrentCycleToHistory before resetting
