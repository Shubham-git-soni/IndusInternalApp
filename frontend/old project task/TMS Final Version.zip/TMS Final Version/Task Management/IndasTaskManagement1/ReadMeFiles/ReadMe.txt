﻿Project Name: IndasTaskManagement1

Overview:
This is a task and point management web application tailored for the IT industry.
Built using ASP.NET Web Forms with Visual Basic (VB.NET), it handles user authentication,
task tracking with a role-based dashboard system.

Technologies Used:
- ASP.NET Web Forms (VB.NET)
- Microsoft SQL Server (Local DB)
- DevExtreme CDN (for Grid and UI)
- jQuery, JavaScript, Bootstrap
- SHA256 for password hashing
- Responsive design using custom CSS

Database Tables:
- Users
- Customers
- Products
- Points
- PointHistory
- PointAttachments
- Tickets

Completed Modules:
- ✅ Login & Register with SHA256 Encryption
- ✅ Role-based Redirection (Admin, Developer, Tester,Support)
- ✅ Responsive  Dashboards
- ✅ Manage Customers ,User,Points and Tickets (CRUD with DevExtreme Grid)
- ✅ Responsive Popups and Navigation

Setup Instructions:
1. Open the solution in Visual Studio.
2. Update `Web.config` with your SQL Server connection string (name: MyConn).
3. Restore the SQL database using `.bak` file or `.sql` script.
4. Run the app using IIS Express (press F5).  
 

 DATA FLow : -
 DB -> DataAccess.vb -> BLL (CodeBehind) -> UI (aspx pages) 

Project Documentation: Indas Task Management System 

Date:[25/07/2025] 
1. Introduction & Project Goal 

Indas Task Management System is a custom-built web application designed to replace an old, manual Google Sheet-based tracking system. Its main purpose is 
to manage tasks, issues, and improvement requests from within the company and from customers on a centralized platform. 
This system tracks every stage of the development lifecycle—from creation of a task ("Point"), to assignment of a developer, then testing (QC), and finally 
closing. This brings transparency, accountability, and efficiency to the entire process. 

2.Core Features Implemented 

Role-Based Access Control (RBAC): There are four different user roles in the system, whose tasks and access permissions are different: 
Admin/Manager: Complete system control, user management, and task assignment. 
Developer: Just work on the tasks assigned to them, track time, and send them for testing. 
Tester (QC): To verify the tasks sent by the developers, to take them forward or send them back. 
Support: Adding new customer issues or internal tasks to the system as "points". 
Secure User Registration & Email Verification: 
New users can register, but their account remains inactive until they click on the verification link sent to their email. 
This ensures that only users with valid emails are active in the system. 
Automated Email Notifications: 
Task Assignment: When a manager assigns a point/ticket to a developer, an automated email notification is sent to that developer. 
Send for QC: When a Developer sends a Point for QC, an automated email notification is sent to the concerned Tester. 
This feature improves real-time communication and ensures that no task goes unnoticed. 
Centralized Task Repository: All tasks ("points") are stored in one place, making them easy to find, filter, and check their progress. 
Ticketing System: The manager can put multiple tasks (points) into a logical group ("Ticket") and assign them to a developer. 
Dedicated Dashboards: Developers and testers have separate, clean dashboards according to their work that show them only the necessary information. 
Complete Point History (Audit Trail): 
The complete lifecycle of every point is recorded. 
For each "reopen" cycle (Dev -> QC -> Reopen -> Dev) the time, remarks, and attachments are recorded separately. 
With this, the entire journey of every task can be traced. 
File Attachment Management: 
Users can attach multiple files (PDFs, images, documents, etc.) while creating a task or during development/testing. 
There is also an option to preview (view) and delete every file. 
In history, attachments of every cycle remain linked with that cycle. 
Dynamic Priority Reordering: Manager can change the priority (order of working) of points within a ticket by drag-and-dropping on the Manage Tickets page. 
This new order gets automatically updated on the developer's dashboard. 
Modern & User-Friendly UI: 
A fast, responsive, and easy UI has been created by using DevExtreme framework. 
Grids have color-coded badges for status and priority, which makes it easier to understand the data at a glance. 

3.Project Structure 

This project is based on a simplified 3-Tier Architecture: 
Presentation Layer (UI - User Interface): 
Files: .aspx (HTML, JavaScript, DevExtreme Widgets) 
Work: Taking input from the user (forms, buttons) and displaying data (grids, popups). All client-side logic (like validation, AJAX calls) happens here. 
Business Logic Layer (BLL – Code-Behind): 
Files: .aspx.vb 
Work: Handling requests coming from the UI. It works like a bridge—taking data from the UI and sending it forward to the Data Access Layer, or taking data 
from DAL and sending it back to the UI. All functions with [WebMethod] attributes are part of this layer. Logic like sending email is also handled here. 
Data Access Layer (DAL): 
Files: App_Code/DataAccess.vb 
Work: It has only one work—to communicate with the database. All SQL queries (SELECT, INSERT, UPDATE, DELETE) are written in the functions inside this file. 

4. System Workflow (User Journey with Email Integration) 

This is the whole journey of a simple task: 
User Registration: 
User: A new team member goes to Register.aspx and fills in his details. 
System: User's account is created but the EmailVerified flag is false. The system sends an email with a verification link to his email address. 
User: Goes to his email and clicks on the link. 
System: As soon as the link is clicked, the EmailVerified flag becomes true and the user can now login. 
Point Creation: 
User: A Support team member or Admin visits the AddPoint.aspx page. 
Action: He fills the details like customer, product, title, description and files in the form. 
System: Point gets saved with Status = 'Queue'. 
Ticket Creation & Assignment: 
User: A Manager or Admin goes to the CreateTicket.aspx page. 
Action: He selects multiple Points present in the 'Queue', groups them into a new "Ticket" and assigns it to a Developer. 
System: Status of Points becomes 'Assigned'. System immediately sends a notification to Developer's email that "A new ticket [TicketNo] has been assigned to 
you." 
Development Cycle: 
User: Developer (after receiving email) login to his DashboardDeveloper.aspx. 
Action: Use sees your assigned points. He completes the task, attaches the necessary files, writes a comment, and clicks "Send for QC". 
Backend: The status of the Point becomes 'PendingQC'. Its remarks and attachments are saved in the PointHistory. The system immediately sends a notification to the 
concerned tester's email that "Point [PointID] is ready for QC." 
Testing (QC) Cycle: 
User: Tester (after receiving email) login to his DashboardTester.aspx. 
Action: Woh tests the point. 
Decision: 
Verify: Status of the Point becomes 'Closed'. 
Reopen: The status of the point changes to 'Reopened'. In this case, the system may send an email notification back to the developer that "Point [PointID] has been 
reopened by the tester." (This is an optional, but nice feature). 
Monitoring & Reporting: 
User: Manager or Admin can monitor all the tickets and their history by going to ManageTickets.aspx. 
This entire flow creates an end-to-end, automated, and professional system that reduces communication gaps and increases productivity. 
Indas Task Management System: Technical Architecture & Flow 1.  
Project Directory Structure 
This project follows a standard ASP.NET Web Forms structure in which logic, data, and UI are kept separate. 

Generated code 
/IndasTaskManagement1/ 
, 
|-- Web.config // Application's main configuration file (Connection String, Upload Size Limit, etc.) | 
|-- App_Code/ // Core application logic, which is accessible in the entire project. 
, |-- DataAccess.vb // All functions that communicate with the database (SQL Queries). , |-- DataModels.vb // Basic 
common data classes (POCOs) like PointData, AttachmentData, etc. , 
|-- CSS/ // All the CSS files that style the UI. | |-- AddPoint.css 
, |-- common.css (Common styles like Badge colors are here) | |-- 
ManagePoints.css | |-- ... (etc.) | 
|-- JS/ // (Optional) For common JavaScript functions. , 
|-- Uploads // All uploaded files are physically saved in this folder. | 
|-- Login.aspx / .vb // User login and authentication. 
|-- Register.aspx / .vb // New users registration and email verification trigger. |-- Landing.aspx / .vb // 
Project's main landing page. 
, 
|-- Default Master Page (Layout) for Site.Master / .vb // Admin/Manager. 
|-- Support.Master / .vb // Special Master Page (Layout with Sidebar) only for "Support" role. , 
|-- AddPoint.aspx / .vb // Form to create a new point. 
|-- ManagePoint.aspx / .vb // Grid for Admin/Manager to view and edit all the points. 
|-- ManageTickets.aspx / .vb // Grid for Admin/Manager to view tickets and change order of points. | 
|-- DashboardDeveloper.aspx / .vb // Developer's personal dashboard. |-- DashboardTester.aspx / .vb // 
Tester's personal dashboard. 
2. Database Architecture & Data Flow 
2.1. Table Relationships (Architecture) 
This diagram tells how which table is connected: 
Generated code 
[Users] 
|---(1-to-Many)---> [Points] (as AssignedTo) |---(1-toMany)---> [Points] 
(as ReportedBy) |---(1-to-Many)--->  
[PointAttachments] (as UploadedBy) 
[Customers] ---(1-to-Many)---> [Points] 
[Products] ---(1-to-Many)---> [Points] 
[Tickets] ---(1-to-Many)---> [Points] 
[Points] (Primary Table) |---(1-to-Many)--->  
[PointHistory] |---(1-to-Many)--->  
[PointAttachments] 
[PointHistory] ---(1-to-Many)---> [PointAttachments] 
Central Hub: Points table is the heart of the system. Every task is a row. 
Foreign Keys: The Points table is linked to Users, Customers, Products, and Tickets through their IDs. 
Lifecycle Tracking: PointHistory table records every development/testing cycle of every point. 
Attachments: The PointAttachments table stores each file. The PointID links it to a point, and the HistoryID links it to a specific cycle. 
2.2. Data Flow (Journey of a Point) 
This is the data flow for the lifecycle of an Aam Point: 

Step 1: Point Creation 
Action: Support user creates a new Point with 2 files from AddPoint.aspx. 
Data Flow: 
A new row is created in the Points table (PointID = 123, Status = 'Queue'). 
2 new rows are created in the PointAttachments table. Both have PointID = 123, but HistoryID is still NULL. 

Step 2: Development Cycle 
Action: Manager assigns a developer to Point 123. Developer begins work, attaches a new file, and clicks "Send for QC". 
Data Flow: 
Points table is updated (Status = 'PendingQC'). 
A new row is created in the PointHistory table (assuming HistoryID = 101). It saves the developer's StartDate, CompleteDate, and remark. 
The CreatePointHistoryCycle function updates the PointAttachments table: 
Only the History ID of that one new file which the developer added gets set to 101. 
The HistoryID of the 2 old files at the time of Add Point is still NULL. 

Step 3: Testing Cycle (Reopen Case) 
Action: Tester tests Point 123, attaches 1 new file, and clicks "Reopen for Developer". 
Data Flow: 
Points table is updated (Status = 'Reopened'). Developer's StartDate/CompleteDate becomes NULL. 
The UpdatePointHistoryCycle function updates the current row (HistoryID = 101) of the PointHistory table. It saves the tester's TesterStartDate, 
TesterCompleteDate, remark, and CycleStatus = 'Reopened'. 
This function updates the PointAttachments table: 
Only the History ID of that one new file added by the tester gets set to 101. 

Step 4: Second Development Cycle 
Action: Developer works at point 123 again, this time does not attach any new file, and clicks on "Send for QC". 
Data Flow: 
Points table is updated (Status = 'PendingQC'). 
Another new row is created in the PointHistory table (assuming HistoryID = 102). In this the developer's new StartDate/CompleteDate is saved. 
This time there is no change in the PointAttachments table due to there being no new "un-stamped" file. 

Step 5: Final Verification 
Action: Tester tests Point 123 and clicks on "Verify". 
Data Flow: 
Points table is updated (Status = 'Closed'). 
The UpdatePointHistoryCycle function updates the last row of the PointHistory (HistoryID = 102) and sets CycleStatus = 'Verified'. 
With this entire flow, every action and every file gets connected with its correct cycle and user, such that everything appears clearly separate in the history grid of the 
ManageTickets page. 




