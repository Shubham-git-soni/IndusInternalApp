' ================================================================
' TIME TRACKING FEATURE - DATA ACCESS METHODS
' ================================================================
' Add these methods to the DataAccess class in App_Data\DataAccess.vb
' These methods handle all time tracking operations
' ================================================================

#Region "Time Tracking Methods"

    ' ================================================================
    ' Insert Time Log Entry
    ' ================================================================
    Public Shared Function InsertTimeLog(pointId As Integer, action As String, performedById As Integer, Optional remarks As String = Nothing) As Boolean
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "INSERT INTO PointTimeLog (PointID, Action, ActionTime, PerformedByID, Remarks) " &
                                      "VALUES (@PointID, @Action, GETDATE(), @PerformedByID, @Remarks)"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    cmd.Parameters.AddWithValue("@Action", action)
                    cmd.Parameters.AddWithValue("@PerformedByID", performedById)
                    cmd.Parameters.AddWithValue("@Remarks", If(String.IsNullOrEmpty(remarks), DBNull.Value, remarks))

                    conn.Open()
                    Return cmd.ExecuteNonQuery() > 0
                End Using
            End Using
        Catch ex As Exception
            ' Log error
            Return False
        End Try
    End Function

    ' ================================================================
    ' Get Time Logs for a Point
    ' ================================================================
    Public Shared Function GetTimeLogsForPoint(pointId As Integer) As List(Of PointTimeLogData)
        Dim logs As New List(Of PointTimeLogData)()
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "SELECT LogID, PointID, Action, ActionTime, PerformedByID, Remarks " &
                                      "FROM PointTimeLog WHERE PointID = @PointID ORDER BY ActionTime"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            logs.Add(New PointTimeLogData With {
                                .LogID = CInt(reader("LogID")),
                                .PointID = CInt(reader("PointID")),
                                .Action = reader("Action").ToString(),
                                .ActionTime = CDate(reader("ActionTime")),
                                .PerformedByID = If(IsDBNull(reader("PerformedByID")), Nothing, CInt(reader("PerformedByID"))),
                                .Remarks = If(IsDBNull(reader("Remarks")), Nothing, reader("Remarks").ToString())
                            })
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
            ' Log error
        End Try
        Return logs
    End Function

    ' ================================================================
    ' Start Point Timer
    ' ================================================================
    Public Shared Function StartPointTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' Check if already started
                Dim checkQuery As String = "SELECT Status, StartDate FROM Points WHERE PointID = @PointID"
                Using checkCmd As New SqlCommand(checkQuery, conn)
                    checkCmd.Parameters.AddWithValue("@PointID", pointId)
                    Using reader As SqlDataReader = checkCmd.ExecuteReader()
                        If reader.Read() Then
                            If Not IsDBNull(reader("StartDate")) Then
                                Return New With {.success = False, .message = "Timer already started"}
                            End If
                        End If
                    End Using
                End Using

                ' Update point
                Dim updateQuery As String = "UPDATE Points SET StartDate = GETDATE(), Status = 'InProgress', LastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                ' Log action
                InsertTimeLog(pointId, "Start", userId, "Timer started")

                Return New With {.success = True, .message = "Timer started successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' ================================================================
    ' Pause Point Timer
    ' ================================================================
    Public Shared Function PausePointTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' Update point
                Dim updateQuery As String = "UPDATE Points SET Status = 'Paused', PauseCount = ISNULL(PauseCount, 0) + 1, LastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                ' Log action
                InsertTimeLog(pointId, "Pause", userId, "Timer paused")

                ' Calculate current time
                CalculateAndUpdateTotalTime(pointId)

                Return New With {.success = True, .message = "Timer paused successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' ================================================================
    ' Resume Point Timer
    ' ================================================================
    Public Shared Function ResumePointTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' Update point
                Dim updateQuery As String = "UPDATE Points SET Status = 'InProgress', LastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                ' Log action
                InsertTimeLog(pointId, "Resume", userId, "Timer resumed")

                Return New With {.success = True, .message = "Timer resumed successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' ================================================================
    ' Complete Point Timer
    ' ================================================================
    Public Shared Function CompletePointTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' Get expected minutes
                Dim expectedMinutes As Integer = 0
                Dim getExpectedQuery As String = "SELECT ExpectedMinutes FROM Points WHERE PointID = @PointID"
                Using getCmd As New SqlCommand(getExpectedQuery, conn)
                    getCmd.Parameters.AddWithValue("@PointID", pointId)
                    Dim result = getCmd.ExecuteScalar()
                    If result IsNot Nothing AndAlso Not IsDBNull(result) Then
                        expectedMinutes = Convert.ToInt32(result)
                    End If
                End Using

                ' Update point
                Dim updateQuery As String = "UPDATE Points SET DateCompleted = GETDATE(), Status = 'Completed', LastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                ' Log action
                InsertTimeLog(pointId, "Complete", userId, "Timer completed")

                ' Calculate total time
                Dim totalMinutes As Integer = CalculateAndUpdateTotalTime(pointId)

                ' Check if extra time was taken
                Dim extraTime As Integer = 0
                If expectedMinutes > 0 AndAlso totalMinutes > expectedMinutes Then
                    extraTime = totalMinutes - expectedMinutes
                    InsertTimeLog(pointId, "ExtraTime", userId, $"Extra time taken: {extraTime} minutes")
                End If

                Return New With {
                    .success = True,
                    .message = "Timer completed successfully",
                    .totalMinutes = totalMinutes,
                    .expectedMinutes = expectedMinutes,
                    .extraMinutes = extraTime
                }
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' ================================================================
    ' Calculate and Update Total Time
    ' ================================================================
    Public Shared Function CalculateAndUpdateTotalTime(pointId As Integer) As Integer
        Dim totalMinutes As Integer = 0
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' Use stored procedure
                Using cmd As New SqlCommand("sp_CalculatePointTotalTime", conn)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@PointID", pointId)

                    Dim result = cmd.ExecuteScalar()
                    If result IsNot Nothing AndAlso Not IsDBNull(result) Then
                        totalMinutes = Convert.ToInt32(result)
                    End If
                End Using
            End Using
        Catch ex As Exception
            ' Log error
        End Try
        Return totalMinutes
    End Function

    ' ================================================================
    ' Get Point Time Summary
    ' ================================================================
    Public Shared Function GetPointTimeSummary(pointId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "SELECT ExpectedMinutes, TotalTimeSpent, PauseCount, Status, StartDate, DateCompleted, LastActionTime " &
                                      "FROM Points WHERE PointID = @PointID"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            Dim expectedMins As Integer = If(IsDBNull(reader("ExpectedMinutes")), 0, CInt(reader("ExpectedMinutes")))
                            Dim totalMins As Integer = If(IsDBNull(reader("TotalTimeSpent")), 0, CInt(reader("TotalTimeSpent")))
                            Dim extraMins As Integer = If(totalMins > expectedMins, totalMins - expectedMins, 0)

                            Return New With {
                                .expectedMinutes = expectedMins,
                                .totalTimeSpent = totalMins,
                                .extraTime = extraMins,
                                .pauseCount = If(IsDBNull(reader("PauseCount")), 0, CInt(reader("PauseCount"))),
                                .status = reader("Status").ToString(),
                                .startDate = If(IsDBNull(reader("StartDate")), Nothing, CDate(reader("StartDate"))),
                                .dateCompleted = If(IsDBNull(reader("DateCompleted")), Nothing, CDate(reader("DateCompleted"))),
                                .lastActionTime = If(IsDBNull(reader("LastActionTime")), Nothing, CDate(reader("LastActionTime")))
                            }
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Return Nothing
        End Try
        Return Nothing
    End Function

    ' ================================================================
    ' Reset Point Timer (when reopened from QC)
    ' ================================================================
    Public Shared Function ResetPointTimerForReopen(pointId As Integer, userId As Integer) As Boolean
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' Save current cycle to history before resetting
                SaveCurrentCycleToHistory(pointId, "Reopened")

                ' Reset point timer fields
                Dim updateQuery As String = "UPDATE Points SET StartDate = NULL, DateCompleted = NULL, " &
                                           "Status = 'Reopened', LastActionTime = GETDATE(), PauseCount = 0 WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                ' Log action
                InsertTimeLog(pointId, "Reopen", userId, "Point reopened from QC")

                Return True
            End Using
        Catch ex As Exception
            Return False
        End Try
    End Function

    ' ================================================================
    ' Save Current Cycle to History
    ' ================================================================
    Public Shared Function SaveCurrentCycleToHistory(pointId As Integer, cycleStatus As String) As Boolean
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' Get current point data
                Dim query As String = "SELECT StartDate, DateCompleted, ExpectedMinutes, TotalTimeSpent, " &
                                     "AssignedToID, DeveloperRemark FROM Points WHERE PointID = @PointID"

                Dim startDate As DateTime? = Nothing
                Dim completeDate As DateTime? = Nothing
                Dim expectedMins As Integer? = Nothing
                Dim totalMins As Integer? = Nothing
                Dim devId As Integer? = Nothing
                Dim devRemark As String = Nothing

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            startDate = If(IsDBNull(reader("StartDate")), Nothing, CDate(reader("StartDate")))
                            completeDate = If(IsDBNull(reader("DateCompleted")), Nothing, CDate(reader("DateCompleted")))
                            expectedMins = If(IsDBNull(reader("ExpectedMinutes")), Nothing, CInt(reader("ExpectedMinutes")))
                            totalMins = If(IsDBNull(reader("TotalTimeSpent")), Nothing, CInt(reader("TotalTimeSpent")))
                            devId = If(IsDBNull(reader("AssignedToID")), Nothing, CInt(reader("AssignedToID")))
                            devRemark = If(IsDBNull(reader("DeveloperRemark")), Nothing, reader("DeveloperRemark").ToString())
                        End If
                    End Using
                End Using

                ' Calculate extra time
                Dim extraMins As Integer? = Nothing
                If expectedMins.HasValue AndAlso totalMins.HasValue AndAlso totalMins.Value > expectedMins.Value Then
                    extraMins = totalMins.Value - expectedMins.Value
                End If

                ' Insert into history (check if HistoryID column is identity or not)
                Dim insertQuery As String = "INSERT INTO PointHistory (PointID, DeveloperID, StartDate, CompleteDate, " &
                                           "DeveloperRemark, CycleStatus, TimeSpentMinutes, ExpectedMinutes, ExtraTimeMinutes, CreatedDate) " &
                                           "VALUES (@PointID, @DeveloperID, @StartDate, @CompleteDate, @DeveloperRemark, " &
                                           "@CycleStatus, @TimeSpentMinutes, @ExpectedMinutes, @ExtraTimeMinutes, GETDATE())"

                Using insertCmd As New SqlCommand(insertQuery, conn)
                    insertCmd.Parameters.AddWithValue("@PointID", pointId)
                    insertCmd.Parameters.AddWithValue("@DeveloperID", If(devId.HasValue, devId.Value, DBNull.Value))
                    insertCmd.Parameters.AddWithValue("@StartDate", If(startDate.HasValue, startDate.Value, DBNull.Value))
                    insertCmd.Parameters.AddWithValue("@CompleteDate", If(completeDate.HasValue, completeDate.Value, DBNull.Value))
                    insertCmd.Parameters.AddWithValue("@DeveloperRemark", If(String.IsNullOrEmpty(devRemark), DBNull.Value, devRemark))
                    insertCmd.Parameters.AddWithValue("@CycleStatus", cycleStatus)
                    insertCmd.Parameters.AddWithValue("@TimeSpentMinutes", If(totalMins.HasValue, totalMins.Value, DBNull.Value))
                    insertCmd.Parameters.AddWithValue("@ExpectedMinutes", If(expectedMins.HasValue, expectedMins.Value, DBNull.Value))
                    insertCmd.Parameters.AddWithValue("@ExtraTimeMinutes", If(extraMins.HasValue, extraMins.Value, DBNull.Value))

                    insertCmd.ExecuteNonQuery()
                End Using

                Return True
            End Using
        Catch ex As Exception
            ' Log error
            Return False
        End Try
    End Function

    ' ================================================================
    ' Update Expected Minutes
    ' ================================================================
    Public Shared Function UpdateExpectedMinutes(pointId As Integer, expectedMinutes As Integer) As Boolean
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "UPDATE Points SET ExpectedMinutes = @ExpectedMinutes WHERE PointID = @PointID"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@ExpectedMinutes", expectedMinutes)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    Return cmd.ExecuteNonQuery() > 0
                End Using
            End Using
        Catch ex As Exception
            Return False
        End Try
    End Function

#End Region
