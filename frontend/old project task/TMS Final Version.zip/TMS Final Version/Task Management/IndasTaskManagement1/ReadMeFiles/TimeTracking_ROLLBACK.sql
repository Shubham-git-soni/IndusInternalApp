-- ================================================================
-- TIME TRACKING FEATURE - ROLLBACK SCRIPT
-- ================================================================
-- Use this script to UNDO all time tracking changes
-- Run this if you want to remove the time tracking feature
-- ================================================================

-- ⚠️ WARNING: This will delete all time tracking data!
-- Make sure you have a backup before running this script.

PRINT '================================================================';
PRINT 'STARTING ROLLBACK OF TIME TRACKING FEATURE';
PRINT '================================================================';
PRINT '';

-- ================================================================
-- STEP 1: Drop Trigger
-- ================================================================
IF EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_UpdateTotalTimeSpent')
BEGIN
    DROP TRIGGER trg_UpdateTotalTimeSpent;
    PRINT '✅ Dropped trigger: trg_UpdateTotalTimeSpent';
END
ELSE
    PRINT '⚠️ Trigger trg_UpdateTotalTimeSpent does not exist';

PRINT '';

-- ================================================================
-- STEP 2: Drop Stored Procedure
-- ================================================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'sp_CalculatePointTotalTime') AND type = 'P')
BEGIN
    DROP PROCEDURE sp_CalculatePointTotalTime;
    PRINT '✅ Dropped stored procedure: sp_CalculatePointTotalTime';
END
ELSE
    PRINT '⚠️ Stored procedure sp_CalculatePointTotalTime does not exist';

PRINT '';

-- ================================================================
-- STEP 3: Drop PointTimeLog Table
-- ================================================================
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PointTimeLog') AND type = 'U')
BEGIN
    DROP TABLE PointTimeLog;
    PRINT '✅ Dropped table: PointTimeLog';
END
ELSE
    PRINT '⚠️ Table PointTimeLog does not exist';

PRINT '';

-- ================================================================
-- STEP 4: Remove Columns from PointHistory Table
-- ================================================================
PRINT 'Removing columns from PointHistory table...';

-- ExtraTimeMinutes
IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'ExtraTimeMinutes')
BEGIN
    ALTER TABLE PointHistory DROP COLUMN ExtraTimeMinutes;
    PRINT '✅ Removed column: ExtraTimeMinutes from PointHistory';
END
ELSE
    PRINT '⚠️ Column ExtraTimeMinutes does not exist in PointHistory';

-- ExpectedMinutes
IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'ExpectedMinutes')
BEGIN
    ALTER TABLE PointHistory DROP COLUMN ExpectedMinutes;
    PRINT '✅ Removed column: ExpectedMinutes from PointHistory';
END
ELSE
    PRINT '⚠️ Column ExpectedMinutes does not exist in PointHistory';

-- TimeSpentMinutes
IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'TimeSpentMinutes')
BEGIN
    ALTER TABLE PointHistory DROP COLUMN TimeSpentMinutes;
    PRINT '✅ Removed column: TimeSpentMinutes from PointHistory';
END
ELSE
    PRINT '⚠️ Column TimeSpentMinutes does not exist in PointHistory';

PRINT '';

-- ================================================================
-- STEP 5: Remove Columns from Points Table
-- ================================================================
PRINT 'Removing columns from Points table...';

-- LastActionTime
IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'LastActionTime')
BEGIN
    ALTER TABLE Points DROP COLUMN LastActionTime;
    PRINT '✅ Removed column: LastActionTime from Points';
END
ELSE
    PRINT '⚠️ Column LastActionTime does not exist in Points';

-- PauseTimeMinutes
IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'PauseTimeMinutes')
BEGIN
    -- Drop default constraint first (if exists)
    DECLARE @ConstraintName NVARCHAR(200);
    SELECT @ConstraintName = dc.name
    FROM sys.default_constraints dc
    INNER JOIN sys.columns c ON dc.parent_column_id = c.column_id AND dc.parent_object_id = c.object_id
    WHERE c.object_id = OBJECT_ID(N'Points') AND c.name = 'PauseTimeMinutes';

    IF @ConstraintName IS NOT NULL
    BEGIN
        DECLARE @SQL NVARCHAR(500) = 'ALTER TABLE Points DROP CONSTRAINT ' + @ConstraintName;
        EXEC sp_executesql @SQL;
    END

    ALTER TABLE Points DROP COLUMN PauseTimeMinutes;
    PRINT '✅ Removed column: PauseTimeMinutes from Points';
END
ELSE
    PRINT '⚠️ Column PauseTimeMinutes does not exist in Points';

-- TotalTimeSpent
IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'TotalTimeSpent')
BEGIN
    ALTER TABLE Points DROP COLUMN TotalTimeSpent;
    PRINT '✅ Removed column: TotalTimeSpent from Points';
END
ELSE
    PRINT '⚠️ Column TotalTimeSpent does not exist in Points';

-- ExpectedMinutes
IF EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'ExpectedMinutes')
BEGIN
    ALTER TABLE Points DROP COLUMN ExpectedMinutes;
    PRINT '✅ Removed column: ExpectedMinutes from Points';
END
ELSE
    PRINT '⚠️ Column ExpectedMinutes does not exist in Points';

PRINT '';

-- ================================================================
-- STEP 6: Verification
-- ================================================================
PRINT '================================================================';
PRINT 'VERIFICATION - Checking if all objects were removed';
PRINT '================================================================';

-- Check Points table
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'ExpectedMinutes')
    AND NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'TotalTimeSpent')
    AND NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'PauseTimeMinutes')
    AND NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'Points') AND name = 'LastActionTime')
BEGIN
    PRINT '✅ All columns removed from Points table';
END
ELSE
    PRINT '⚠️ Some columns still exist in Points table';

-- Check PointHistory table
IF NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'TimeSpentMinutes')
    AND NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'ExpectedMinutes')
    AND NOT EXISTS (SELECT * FROM sys.columns WHERE object_id = OBJECT_ID(N'PointHistory') AND name = 'ExtraTimeMinutes')
BEGIN
    PRINT '✅ All columns removed from PointHistory table';
END
ELSE
    PRINT '⚠️ Some columns still exist in PointHistory table';

-- Check PointTimeLog table
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'PointTimeLog') AND type = 'U')
    PRINT '✅ PointTimeLog table removed';
ELSE
    PRINT '⚠️ PointTimeLog table still exists';

-- Check stored procedure
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'sp_CalculatePointTotalTime') AND type = 'P')
    PRINT '✅ Stored procedure removed';
ELSE
    PRINT '⚠️ Stored procedure still exists';

-- Check trigger
IF NOT EXISTS (SELECT * FROM sys.triggers WHERE name = 'trg_UpdateTotalTimeSpent')
    PRINT '✅ Trigger removed';
ELSE
    PRINT '⚠️ Trigger still exists';

PRINT '';
PRINT '================================================================';
PRINT 'ROLLBACK COMPLETED!';
PRINT '================================================================';
PRINT '';
PRINT 'What to do next:';
PRINT '1. Rebuild your Visual Studio solution';
PRINT '2. The VB code changes will remain but won''t cause errors';
PRINT '3. To fully revert code, restore from your backup';
PRINT '================================================================';
