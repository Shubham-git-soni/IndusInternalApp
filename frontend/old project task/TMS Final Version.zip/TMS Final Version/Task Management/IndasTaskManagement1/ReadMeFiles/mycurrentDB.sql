USE [master]
GO
/****** Object:  Database [IndasTaskManagementDB]    Script Date: 10/7/2025 10:27:39 AM ******/
CREATE DATABASE [IndasTaskManagementDB]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'IndasTaskManagementDB', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS01\MSSQL\DATA\IndasTaskManagementDB.mdf' , SIZE = 73728KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'IndasTaskManagementDB_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL16.SQLEXPRESS01\MSSQL\DATA\IndasTaskManagementDB_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [IndasTaskManagementDB] SET COMPATIBILITY_LEVEL = 160
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [IndasTaskManagementDB].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [IndasTaskManagementDB] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET ARITHABORT OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [IndasTaskManagementDB] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [IndasTaskManagementDB] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [IndasTaskManagementDB] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET  DISABLE_BROKER 
GO
ALTER DATABASE [IndasTaskManagementDB] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [IndasTaskManagementDB] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [IndasTaskManagementDB] SET  MULTI_USER 
GO
ALTER DATABASE [IndasTaskManagementDB] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [IndasTaskManagementDB] SET DB_CHAINING OFF 
GO
ALTER DATABASE [IndasTaskManagementDB] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [IndasTaskManagementDB] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [IndasTaskManagementDB] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [IndasTaskManagementDB] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [IndasTaskManagementDB] SET QUERY_STORE = ON
GO
ALTER DATABASE [IndasTaskManagementDB] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [IndasTaskManagementDB]
GO
/****** Object:  Table [dbo].[Customers]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Customers](
	[CustomerID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerName] [nvarchar](150) NOT NULL,
	[CompanyName] [nvarchar](150) NOT NULL,
	[ContactPerson] [nvarchar](100) NULL,
	[ContactEmail] [nvarchar](100) NULL,
	[ContactPhone] [nvarchar](20) NULL,
	[IsActive] [bit] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[CustomerID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Modules]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Modules](
	[ModuleName] [nvarchar](128) NULL
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PointAttachments]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PointAttachments](
	[AttachmentID] [int] IDENTITY(1,1) NOT NULL,
	[PointID] [int] NOT NULL,
	[FileName] [nvarchar](255) NOT NULL,
	[FilePath] [nvarchar](500) NOT NULL,
	[UploadedByID] [int] NOT NULL,
	[UploadTimestamp] [datetime] NOT NULL,
	[HistoryID] [int] NULL,
	[OriginalFileName] [nvarchar](255) NULL,
PRIMARY KEY CLUSTERED 
(
	[AttachmentID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PointHistory]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PointHistory](
	[HistoryID] [int] IDENTITY(1,1) NOT NULL,
	[PointID] [int] NOT NULL,
	[DeveloperID] [int] NULL,
	[TesterID] [int] NULL,
	[StartDate] [datetime] NULL,
	[CompleteDate] [datetime] NULL,
	[SentToQCDate] [datetime] NULL,
	[TesterStartDate] [datetime] NULL,
	[FinalStatusDate] [datetime] NULL,
	[DeveloperRemark] [nvarchar](max) NULL,
	[TesterRemark] [nvarchar](max) NULL,
	[CycleStatus] [nvarchar](50) NOT NULL,
	[TesterCompleteDate] [datetime] NULL,
	[TimeSpentMinutes] [int] NULL,
	[ExpectedMinutes] [int] NULL,
	[ExtraTimeMinutes] [int] NULL,
	[SupportID] [int] NULL,
	[SupportStartDate] [datetime] NULL,
	[SupportCompleteDate] [datetime] NULL,
	[SupportTimeSpentMinutes] [int] NULL,
	[SupportRemark] [nvarchar](max) NULL,
	[SupportSentToQCDate] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[HistoryID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Points]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Points](
	[PointID] [int] IDENTITY(1,1) NOT NULL,
	[Title] [nvarchar](250) NOT NULL,
	[Summary] [nvarchar](500) NULL,
	[Description] [nvarchar](max) NOT NULL,
	[CustomerID] [int] NOT NULL,
	[ProductID] [int] NOT NULL,
	[ReportedByID] [int] NOT NULL,
	[AssignedToID] [int] NULL,
	[DateCreated] [datetime] NOT NULL,
	[StartDate] [datetime] NULL,
	[DateCompleted] [datetime] NULL,
	[DateClosed] [datetime] NULL,
	[Status] [nvarchar](50) NOT NULL,
	[Priority] [nvarchar](50) NOT NULL,
	[Category] [nvarchar](50) NOT NULL,
	[Complexity] [nvarchar](50) NULL,
	[TicketID] [int] NULL,
	[ExpectedDate] [datetime] NULL,
	[DateSentToQC] [datetime] NULL,
	[TesterStartDate] [datetime] NULL,
	[DeveloperRemark] [nvarchar](max) NULL,
	[TesterRemark] [nvarchar](max) NULL,
	[TesterCompleteDate] [datetime] NULL,
	[SortOrder] [int] NULL,
	[IsVerified] [bit] NOT NULL,
	[IsDeadlineNotified] [bit] NOT NULL,
	[ExpectedMinutes] [int] NULL,
	[TotalTimeSpent] [int] NULL,
	[LastActionTime] [datetime] NULL,
	[PauseTimeMinutes] [int] NULL,
	[SupportStartDate] [datetime] NULL,
	[SupportCompleteDate] [datetime] NULL,
	[SupportTimeSpent] [int] NULL,
	[SupportPauseTime] [int] NULL,
	[SupportLastActionTime] [datetime] NULL,
	[IsSupportPaused] [bit] NULL,
	[SupportRemark] [nvarchar](max) NULL,
PRIMARY KEY CLUSTERED 
(
	[PointID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[PointTimeLog]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[PointTimeLog](
	[LogID] [int] IDENTITY(1,1) NOT NULL,
	[PointID] [int] NOT NULL,
	[Action] [nvarchar](50) NOT NULL,
	[ActionTime] [datetime] NULL,
	[PerformedByID] [int] NULL,
	[Remarks] [nvarchar](500) NULL,
PRIMARY KEY CLUSTERED 
(
	[LogID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Products]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Products](
	[ProductID] [int] IDENTITY(1,1) NOT NULL,
	[ProductName] [nvarchar](100) NOT NULL,
	[ProductVersion] [nvarchar](50) NULL,
	[IsActive] [bit] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ProductID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[ProductName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Tickets]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Tickets](
	[TicketID] [int] IDENTITY(1,1) NOT NULL,
	[TicketNo] [nvarchar](50) NULL,
	[AssignedToID] [int] NULL,
	[CreatedByID] [int] NULL,
	[Department] [nvarchar](100) NULL,
	[DateCreated] [datetime] NULL,
	[Status] [nvarchar](50) NULL,
	[Summary] [nvarchar](500) NULL,
	[Description] [nvarchar](max) NULL,
	[ExpectedCompletionDate] [datetime] NULL,
 CONSTRAINT [PK__Tickets__712CC627D9B35A7A] PRIMARY KEY CLUSTERED 
(
	[TicketID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ__Tickets__712CCE65D9F7847D] UNIQUE NONCLUSTERED 
(
	[TicketNo] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[UserPagePermissions]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[UserPagePermissions](
	[PermissionID] [int] IDENTITY(1,1) NOT NULL,
	[UserID] [int] NOT NULL,
	[PageName] [varchar](100) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[PermissionID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Users]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[UserID] [int] IDENTITY(1,1) NOT NULL,
	[FullName] [nvarchar](100) NOT NULL,
	[Email] [nvarchar](100) NOT NULL,
	[PasswordHash] [nvarchar](256) NOT NULL,
	[Role] [nvarchar](50) NOT NULL,
	[IsActive] [bit] NOT NULL,
	[DateCreated] [datetime] NOT NULL,
	[EmailVerified] [bit] NULL,
	[EmailToken] [nvarchar](255) NULL,
	[WhatsAppNumber] [nvarchar](20) NULL,
PRIMARY KEY CLUSTERED 
(
	[UserID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Email] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Index [IX_PointTimeLog_ActionTime]    Script Date: 10/7/2025 10:27:39 AM ******/
CREATE NONCLUSTERED INDEX [IX_PointTimeLog_ActionTime] ON [dbo].[PointTimeLog]
(
	[ActionTime] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_PointTimeLog_PointID]    Script Date: 10/7/2025 10:27:39 AM ******/
CREATE NONCLUSTERED INDEX [IX_PointTimeLog_PointID] ON [dbo].[PointTimeLog]
(
	[PointID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[Customers] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Customers] ADD  DEFAULT (getdate()) FOR [DateCreated]
GO
ALTER TABLE [dbo].[PointAttachments] ADD  DEFAULT (getdate()) FOR [UploadTimestamp]
GO
ALTER TABLE [dbo].[Points] ADD  DEFAULT (getdate()) FOR [DateCreated]
GO
ALTER TABLE [dbo].[Points] ADD  DEFAULT ('Queue') FOR [Status]
GO
ALTER TABLE [dbo].[Points] ADD  CONSTRAINT [DF_Points_IsVerified]  DEFAULT ((0)) FOR [IsVerified]
GO
ALTER TABLE [dbo].[Points] ADD  DEFAULT ((0)) FOR [IsDeadlineNotified]
GO
ALTER TABLE [dbo].[Points] ADD  DEFAULT ((0)) FOR [PauseTimeMinutes]
GO
ALTER TABLE [dbo].[Points] ADD  DEFAULT ((0)) FOR [IsSupportPaused]
GO
ALTER TABLE [dbo].[PointTimeLog] ADD  DEFAULT (getdate()) FOR [ActionTime]
GO
ALTER TABLE [dbo].[Products] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Tickets] ADD  CONSTRAINT [DF__Tickets__DateCre__5DCAEF64]  DEFAULT (getdate()) FOR [DateCreated]
GO
ALTER TABLE [dbo].[Tickets] ADD  CONSTRAINT [DF__Tickets__Status__5EBF139D]  DEFAULT ('Open') FOR [Status]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT (getdate()) FOR [DateCreated]
GO
ALTER TABLE [dbo].[Users] ADD  DEFAULT ((0)) FOR [EmailVerified]
GO
ALTER TABLE [dbo].[PointAttachments]  WITH CHECK ADD  CONSTRAINT [FK_PointAttachments_HistoryID] FOREIGN KEY([HistoryID])
REFERENCES [dbo].[PointHistory] ([HistoryID])
GO
ALTER TABLE [dbo].[PointAttachments] CHECK CONSTRAINT [FK_PointAttachments_HistoryID]
GO
ALTER TABLE [dbo].[PointAttachments]  WITH NOCHECK ADD  CONSTRAINT [FK_PointAttachments_Points] FOREIGN KEY([PointID])
REFERENCES [dbo].[Points] ([PointID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PointAttachments] NOCHECK CONSTRAINT [FK_PointAttachments_Points]
GO
ALTER TABLE [dbo].[PointAttachments]  WITH NOCHECK ADD  CONSTRAINT [FK_PointAttachments_Users] FOREIGN KEY([UploadedByID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[PointAttachments] NOCHECK CONSTRAINT [FK_PointAttachments_Users]
GO
ALTER TABLE [dbo].[PointHistory]  WITH CHECK ADD  CONSTRAINT [FK_PointHistory_DeveloperID] FOREIGN KEY([DeveloperID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[PointHistory] CHECK CONSTRAINT [FK_PointHistory_DeveloperID]
GO
ALTER TABLE [dbo].[PointHistory]  WITH CHECK ADD  CONSTRAINT [FK_PointHistory_PointID] FOREIGN KEY([PointID])
REFERENCES [dbo].[Points] ([PointID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[PointHistory] CHECK CONSTRAINT [FK_PointHistory_PointID]
GO
ALTER TABLE [dbo].[PointHistory]  WITH CHECK ADD  CONSTRAINT [FK_PointHistory_TesterID] FOREIGN KEY([TesterID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[PointHistory] CHECK CONSTRAINT [FK_PointHistory_TesterID]
GO
ALTER TABLE [dbo].[Points]  WITH NOCHECK ADD  CONSTRAINT [FK_Points_AssignedTo] FOREIGN KEY([AssignedToID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[Points] NOCHECK CONSTRAINT [FK_Points_AssignedTo]
GO
ALTER TABLE [dbo].[Points]  WITH NOCHECK ADD  CONSTRAINT [FK_Points_Customers] FOREIGN KEY([CustomerID])
REFERENCES [dbo].[Customers] ([CustomerID])
GO
ALTER TABLE [dbo].[Points] NOCHECK CONSTRAINT [FK_Points_Customers]
GO
ALTER TABLE [dbo].[Points]  WITH NOCHECK ADD  CONSTRAINT [FK_Points_Products] FOREIGN KEY([ProductID])
REFERENCES [dbo].[Products] ([ProductID])
GO
ALTER TABLE [dbo].[Points] NOCHECK CONSTRAINT [FK_Points_Products]
GO
ALTER TABLE [dbo].[Points]  WITH NOCHECK ADD  CONSTRAINT [FK_Points_ReportedBy] FOREIGN KEY([ReportedByID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[Points] NOCHECK CONSTRAINT [FK_Points_ReportedBy]
GO
ALTER TABLE [dbo].[Points]  WITH NOCHECK ADD  CONSTRAINT [FK_Points_Tickets] FOREIGN KEY([TicketID])
REFERENCES [dbo].[Tickets] ([TicketID])
GO
ALTER TABLE [dbo].[Points] NOCHECK CONSTRAINT [FK_Points_Tickets]
GO
ALTER TABLE [dbo].[PointTimeLog]  WITH CHECK ADD FOREIGN KEY([PerformedByID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[PointTimeLog]  WITH CHECK ADD FOREIGN KEY([PointID])
REFERENCES [dbo].[Points] ([PointID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[Tickets]  WITH CHECK ADD  CONSTRAINT [FK_Tickets_AssignedTo] FOREIGN KEY([AssignedToID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[Tickets] CHECK CONSTRAINT [FK_Tickets_AssignedTo]
GO
ALTER TABLE [dbo].[Tickets]  WITH CHECK ADD  CONSTRAINT [FK_Tickets_CreatedBy] FOREIGN KEY([CreatedByID])
REFERENCES [dbo].[Users] ([UserID])
GO
ALTER TABLE [dbo].[Tickets] CHECK CONSTRAINT [FK_Tickets_CreatedBy]
GO
ALTER TABLE [dbo].[UserPagePermissions]  WITH CHECK ADD  CONSTRAINT [FK_UserPagePermissions_Users] FOREIGN KEY([UserID])
REFERENCES [dbo].[Users] ([UserID])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[UserPagePermissions] CHECK CONSTRAINT [FK_UserPagePermissions_Users]
GO
/****** Object:  StoredProcedure [dbo].[sp_CalculatePointTotalTime]    Script Date: 10/7/2025 10:27:39 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_CalculatePointTotalTime]
    @PointID INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @TotalMinutes INT = 0;
    DECLARE @PauseMinutes INT = 0;
    DECLARE @StartTime DATETIME;
    DECLARE @PauseStartTime DATETIME;
    DECLARE @LastAction NVARCHAR(50);
    DECLARE @CurrentTime DATETIME = GETDATE();

    -- Get all time logs for this point
    DECLARE time_cursor CURSOR FOR
        SELECT Action, ActionTime
        FROM PointTimeLog
        WHERE PointID = @PointID
        ORDER BY ActionTime;

    DECLARE @Action NVARCHAR(50), @ActionTime DATETIME;

    OPEN time_cursor;
    FETCH NEXT FROM time_cursor INTO @Action, @ActionTime;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        IF @Action = 'Start' OR @Action = 'Resume'
        BEGIN
            SET @StartTime = @ActionTime;
            -- If resuming after pause, calculate pause duration
            IF @PauseStartTime IS NOT NULL
            BEGIN
                SET @PauseMinutes = @PauseMinutes + DATEDIFF(MINUTE, @PauseStartTime, @ActionTime);
                SET @PauseStartTime = NULL;
            END
        END
        ELSE IF @Action = 'Pause' AND @StartTime IS NOT NULL
        BEGIN
            SET @TotalMinutes = @TotalMinutes + DATEDIFF(MINUTE, @StartTime, @ActionTime);
            SET @PauseStartTime = @ActionTime;
            SET @StartTime = NULL;
        END
        ELSE IF @Action = 'Complete' AND @StartTime IS NOT NULL
        BEGIN
            SET @TotalMinutes = @TotalMinutes + DATEDIFF(MINUTE, @StartTime, @ActionTime);
            SET @StartTime = NULL;
        END

        FETCH NEXT FROM time_cursor INTO @Action, @ActionTime;
    END

    CLOSE time_cursor;
    DEALLOCATE time_cursor;

    -- If still in progress, add time until now
    IF @StartTime IS NOT NULL
    BEGIN
        SET @TotalMinutes = @TotalMinutes + DATEDIFF(MINUTE, @StartTime, @CurrentTime);
    END

    -- If currently paused, add pause time until now
    IF @PauseStartTime IS NOT NULL
    BEGIN
        SET @PauseMinutes = @PauseMinutes + DATEDIFF(MINUTE, @PauseStartTime, @CurrentTime);
    END

    -- Update the Points table
    UPDATE Points
    SET TotalTimeSpent = @TotalMinutes,
        PauseTimeMinutes = @PauseMinutes
    WHERE PointID = @PointID;

    SELECT @TotalMinutes AS TotalMinutes, @PauseMinutes AS PauseMinutes;
END
GO
USE [master]
GO
ALTER DATABASE [IndasTaskManagementDB] SET  READ_WRITE 
GO
