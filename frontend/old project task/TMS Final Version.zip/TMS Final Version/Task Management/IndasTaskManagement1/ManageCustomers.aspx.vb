﻿Imports System.Web.Services
Imports System.Web.Script.Serialization
Imports System.Data

Public Class ManageCustomers
    Inherits BasePage

    <WebMethod()>
    Public Shared Function GetCustomers() As Object
        Dim dt As DataTable = CustomersDAL.GetAllCustomers()
        Dim customers As New List(Of Dictionary(Of String, Object))()

        For Each row As DataRow In dt.Rows
            Dim customer As New Dictionary(Of String, Object)()
            For Each col As DataColumn In dt.Columns
                customer.Add(col.ColumnName, row(col))
            Next
            customers.Add(customer)
        Next

        Return customers
    End Function

    <WebMethod()>
    Public Shared Function AddCustomer(customer As Dictionary(Of String, Object)) As Boolean
        Try
            CustomersDAL.InsertCustomer(customer)
            Return True
        Catch ex As Exception
            ' Optional: log the error
            Return False
        End Try
    End Function

    <WebMethod()>
    Public Shared Function UpdateCustomer(key As Integer, values As Object) As Boolean
        Try
            Dim serializer As New JavaScriptSerializer()
            Dim dict As Dictionary(Of String, Object) = serializer.ConvertToType(Of Dictionary(Of String, Object))(values)
            CustomersDAL.UpdateCustomer(key, dict)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

    <WebMethod()>
    Public Shared Function DeleteCustomer(key As Integer) As Boolean
        Try
            CustomersDAL.DeleteCustomer(key)
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

End Class
