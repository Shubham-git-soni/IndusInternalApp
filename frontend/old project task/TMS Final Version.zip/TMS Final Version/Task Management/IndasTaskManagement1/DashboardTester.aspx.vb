﻿Imports System.Web.Services
Imports System.Collections.Generic
Imports IndasTaskManagement1.DataAccess

Public Class DashboardTester
    Inherits BasePage

    Public Class TesterPointActionData
        Public Property PointID As Integer
        Public Property Title As String
        Public Property Summary As String
        Public Property Description As String
        Public Property ProductName As String
        Public Property Category As String
        Public Property TesterStartDate As Nullable(Of DateTime)
        Public Property DateClosed As Nullable(Of DateTime)
        Public Property Status As String
    End Class

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Prevent caching so browser can't go back after logout
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
        Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches)

        ' Session validation
        If Session("UserID") Is Nothing Then
            Response.Redirect("Landing.aspx")
        End If
    End Sub

    ' 🔥 Logout method to clear session
    <WebMethod()>
    Public Shared Sub Logout()
        HttpContext.Current.Session.Clear()
        HttpContext.Current.Session.Abandon()
    End Sub

    <WebMethod()>
    Public Shared Function GetTesterQueue() As List(Of PointData)
        Return DataAccess.GetPointsForTesterDashboard()
    End Function

    <WebMethod()>
    Public Shared Function GetPointForActionCenter(ByVal pointId As Integer) As Object
        Try
            ' We use the master function which fetches everything
            Dim pointDetails = DataAccess.GetPointDetailsById(pointId)
            If pointDetails Is Nothing Then Return Nothing

            ' We will return the full PointData object to JavaScript
            ' This simplifies things and ensures all data is available.
            Return pointDetails

        Catch ex As Exception
            ' It's good practice to log the error
            System.Diagnostics.Trace.WriteLine("ERROR GetPointForActionCenter: " & ex.Message)
            Return Nothing
        End Try
    End Function

    <WebMethod()>
    Public Shared Function StartTesterTimer(ByVal pointId As Integer) As Object
        If DataAccess.IsTicketClosed(pointId) Then
            Return New With {.success = False, .message = "This ticket is already closed. You cannot start testing."}
        End If
        Dim now As DateTime = DateTime.Now
        Dim success As Boolean = DataAccess.UpdatePointStatusAndDate(pointId, "In-Testing", "TesterStartDate", now)

        Return New With {
            .success = success,
            .startTime = If(success, now, CType(Nothing, DateTime?)),
            .status = If(success, "In-Testing", Nothing),
            .message = If(success, "Testing started", "Could not start testing timer.")
        }
    End Function

    ' In DashboardTester.aspx.vb, replace the existing functions
    <WebMethod()>
    Public Shared Function VerifyAndClose(pointId As Integer, testerRemark As String) As Object
        Try
            Dim currentStatus As String = DataAccess.GetPointStatus(pointId)
            If currentStatus = "Closed" Then
                Return New With {.success = False, .message = "This point is already closed."}
            End If
            If currentStatus <> "Testing-Completed" Then
                Return New With {.success = False, .message = "You can only close after 'Testing Completed'."}
            End If

            Dim testerId As Integer = CInt(HttpContext.Current.Session("UserID"))

            ' 1. History mein entry karein (ab yeh timings + remark sab save karega)
            DataAccess.UpdatePointHistoryCycle(pointId, testerId, testerRemark, "Verified")

            ' 2. Points table ko final status 'Closed' se update karein
            Dim success As Boolean = DataAccess.UpdatePointStatusAndDate(pointId, "Closed", "DateClosed", DateTime.Now)

            If success Then
                Return New With {.success = True, .message = "Verified and Closed successfully."}
            Else
                Return New With {.success = False, .message = "Failed to close ticket. Please try again."}
            End If

        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    <WebMethod()>
    Public Shared Function ReopenForDeveloper(ByVal pointId As Integer, ByVal testerRemark As String) As Object
        Try
            ' Step 1: Check karein ki ticket closed to nahi hai
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "This ticket is already closed. You cannot reopen it."}
            End If

            Dim currentStatus As String = DataAccess.GetPointStatus(pointId)
            If currentStatus = "ReOpened" Then
                Return New With {.success = False, .message = "This ticket is already reopened."}
            End If

            Dim testerId As Integer = CInt(HttpContext.Current.Session("UserID"))

            ' Step 2: History table mein tester ka saara data (dates, remark) save karein
            ' Hum status "ReOpened" bhej rahe hain
            DataAccess.UpdatePointHistoryCycle(pointId, testerId, testerRemark, "ReOpened")

            ' Step 3: Developer ke liye point ko reset karein (iska history se koi lena-dena nahi)
            DataAccess.ResetPointForReopening(pointId)

            ' --- NOTIFICATION LOGIC START ---
            Dim pointDetails = DataAccess.GetPointDetailsById(pointId)
            If pointDetails IsNot Nothing AndAlso pointDetails.AssignedToID.HasValue Then
                Dim testerName As String = HttpContext.Current.Session("FullName").ToString()
                Dim message As String = $"Point #{pointId} has been REOPENED by QC ({testerName}). Please review."
                Dim url As String = $"~/DashboardDeveloper.aspx?pointId={pointId}"
                DataAccess.CreateNotification(pointDetails.AssignedToID.Value, message, url)
            End If
            ' --- NOTIFICATION LOGIC END ---

            Return New With {.success = True, .message = "Ticket successfully reopened for developer."}

        Catch ex As Exception
            Return New With {.success = False, .message = "An error occurred: " & ex.Message}
        End Try
    End Function
    <WebMethod()>
    Public Shared Function SaveTesterRemark(pointId As Integer, remark As String) As Boolean
        Return DataAccess.UpdateTesterRemark(pointId, remark)
    End Function

    <WebMethod()>
    Public Shared Function CompleteTesting(ByVal pointId As Integer) As Object
        If DataAccess.IsTicketClosed(pointId) Then
            Return New With {.success = False, .message = "This ticket is already closed. You cannot complete testing."}
        End If
        Try
            ' Call the new, dedicated function. No more complex logic.
            Dim success As Boolean = DataAccess.MarkTestingAsComplete(pointId)

            Return New With {
            .success = success,
            .completeTime = If(success, DateTime.Now, CType(Nothing, DateTime?)),
            .message = If(success, "Success", "Failed to update in DB")
        }
        Catch ex As Exception
            Return New With {.success = False, .message = ex.Message}
        End Try
    End Function
    <WebMethod()>
    Public Shared Function GetPointHistoryForGrid(ByVal pointId As Integer) As List(Of PointHistoryData)
        Return DataAccess.GetPointHistory(pointId)
    End Function

    <WebMethod()>
    Public Shared Function GetAttachments(pointId As Integer) As List(Of AttachmentData)

        '  function 'GetAllAttachmentsForPoint' 
        Return DataAccess.GetAllAttachmentsForPoint(pointId)

    End Function

    <WebMethod()>
    Public Shared Function DeleteExistingAttachment(attachmentId As Integer) As Boolean

        Return DataAccess.DeleteAttachmentById(attachmentId)

    End Function

    ' 2. WebMethod to add a NEW attachment to an EXISTING point

    <WebMethod()>
    Public Shared Function AddAttachmentToPoint(pointId As Integer, attachment As AttachmentInfo) As Object

        Try

            Dim uploadedById As Integer = HttpContext.Current.Session("UserID")

            DataAccess.InsertAttachment(pointId, attachment.fileName, attachment.filePath, uploadedById)

            Return New With {.success = True, .message = "Attachment added."}

        Catch ex As Exception

            Return New With {.success = False, .message = "Failed to add attachment."}

        End Try

    End Function

    <WebMethod()>
    Public Shared Function IsTicketClosed(pointId As Integer) As Boolean
        Return DataAccess.IsTicketClosed(pointId) ' 👈 ye function pehle banaya tha DataAccess me
    End Function


End Class
