﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Net
Imports System.IO
'Imports System.Text
'Imports Newtonsoft.Json

Public Module WhatsAppNotifier

    Private IsRunning As Boolean = False

    Public Sub RunDeadlineCheck()
        If IsRunning Then Return
        IsRunning = True

        Try
            Dim tasksToNotify As New List(Of Object)
            Dim connString As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

            ' 🔹 Step 1: deadline check (5 min before / after)
            Using conn As New SqlConnection(connString)
                Dim query As String = "
                    SELECT P.PointID, P.Title, U.WhatsAppNumber, P.ExpectedDate
                    FROM Points AS P 
                    JOIN Users AS U ON P.AssignedToID = U.UserID
                    WHERE P.Status IN ('Assigned', 'In Progress')
                      AND P.ExpectedDate BETWEEN DATEADD(MINUTE, -20, GETDATE()) AND DATEADD(MINUTE, 20, GETDATE())
                      AND P.IsDeadlineNotified = 0
                      AND U.WhatsAppNumber IS NOT NULL AND U.WhatsAppNumber <> '';"

                Dim cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        tasksToNotify.Add(New With {
                            .PointID = Convert.ToInt32(reader("PointID")),
                            .Title = reader("Title").ToString(),
                            .WhatsAppNumber = reader("WhatsAppNumber").ToString(),
                            .ExpectedDate = Convert.ToDateTime(reader("ExpectedDate"))
                        })
                    End While
                End Using
            End Using

            System.Diagnostics.Debug.WriteLine("🔎 Found Tasks: " & tasksToNotify.Count)

            ' 🔹 Step 2: Send WhatsApp message
            For Each task In tasksToNotify
                Dim deadline As DateTime = task.ExpectedDate

                Dim message As String = String.Format(
    "*⏰ Reminder!*" & vbCrLf &
    "Task: *{0}* (ID: {1})" & vbCrLf &
    "Deadline: {2}" & vbCrLf &
    "⚠ Due in 20 minutes!",
    task.Title,
    task.PointID,
    deadline.ToString("dd-MMM-yyyy hh:mm tt")
)


                Dim result As String = SendWhatsAppMessage(task.WhatsAppNumber, message)
                System.Diagnostics.Debug.WriteLine("➡ " & task.WhatsAppNumber & " | ⬅ Response: " & result)

                ' 🔹 success flag update
                If result.ToLower().Contains("""success"":true") Then
                    UpdateNotificationFlag(connString, task.PointID)
                End If
            Next

        Catch ex As Exception
            System.Diagnostics.Debug.WriteLine("❌ ERROR in WhatsAppNotifier.RunDeadlineCheck: " & ex.Message)
        Finally
            IsRunning = False
        End Try
    End Sub

    Private Sub UpdateNotificationFlag(connString As String, pointId As Integer)
        Using conn As New SqlConnection(connString)
            Dim query As String = "UPDATE Points SET IsDeadlineNotified = 1 WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub

    ' 🔹 Whatsify API call (same as DailyReport)
    Public Function SendWhatsAppMessage(ByVal phone As String, ByVal message As String) As String
        Try
            Dim secret As String = Global_asax.WhatsFlySecret
            Dim account As String = Global_asax.WhatsFlyAccount
            Dim apiUrl As String = Global_asax.WhatsFlyApiUrl

            If String.IsNullOrEmpty(phone) Then Return "Failed: Phone number is empty."
            If Not phone.StartsWith("+") Then phone = "+91" & phone

            Dim payload As New System.Collections.Specialized.NameValueCollection()
            payload.Add("secret", secret)
            payload.Add("account", account)
            payload.Add("recipient", phone)
            payload.Add("message", message)
            payload.Add("type", "text")

            Using client As New WebClient()
                Dim responseBytes As Byte() = client.UploadValues(apiUrl, "POST", payload)
                Dim result As String = Encoding.UTF8.GetString(responseBytes)
                Return result
            End Using
        Catch ex As WebException
            If ex.Response IsNot Nothing Then
                Using reader As New StreamReader(ex.Response.GetResponseStream())
                    Dim errorResponse As String = reader.ReadToEnd()
                    Return "Error: " & ex.Message & " | Response: " & errorResponse
                End Using
            Else
                Return "Error: " & ex.Message
            End If
        Catch ex As Exception
            Return "Error: " & ex.Message
        End Try
    End Function

End Module
