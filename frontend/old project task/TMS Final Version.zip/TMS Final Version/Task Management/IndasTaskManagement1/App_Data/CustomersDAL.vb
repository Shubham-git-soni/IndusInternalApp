﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class CustomersDAL

    Public Shared Function GetAllCustomers() As DataTable
        Dim dt As New DataTable()
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            Dim cmd As New SqlCommand("SELECT * FROM Customers", conn)
            conn.Open()
            dt.Load(cmd.ExecuteReader())
        End Using

        Return dt
    End Function

    Public Shared Sub InsertCustomer(customer As Dictionary(Of String, Object))
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            Dim query As String = "INSERT INTO Customers (CustomerName, CompanyName, ContactPerson, ContactEmail, ContactPhone, IsActive, DateCreated) " &
                                  "VALUES (@CustomerName, @CompanyName, @ContactPerson, @ContactEmail, @ContactPhone, @IsActive, GETDATE())"

            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@CustomerName", customer("CustomerName"))
            cmd.Parameters.AddWithValue("@CompanyName", If(customer.ContainsKey("CompanyName"), customer("CompanyName"), DBNull.Value))
            cmd.Parameters.AddWithValue("@ContactPerson", If(customer.ContainsKey("ContactPerson"), customer("ContactPerson"), DBNull.Value))
            cmd.Parameters.AddWithValue("@ContactEmail", If(customer.ContainsKey("ContactEmail"), customer("ContactEmail"), DBNull.Value))
            cmd.Parameters.AddWithValue("@ContactPhone", If(customer.ContainsKey("ContactPhone"), customer("ContactPhone"), DBNull.Value))
            cmd.Parameters.AddWithValue("@IsActive", If(customer.ContainsKey("IsActive") AndAlso customer("IsActive") = True, 1, 0))

            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Public Shared Sub UpdateCustomer(customerId As Integer, values As Dictionary(Of String, Object))
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            Dim query As String = "UPDATE Customers SET " &
                                  "CustomerName = ISNULL(@CustomerName, CustomerName), " &
                                  "CompanyName = ISNULL(@CompanyName, CompanyName), " &
                                  "ContactPerson = ISNULL(@ContactPerson, ContactPerson), " &
                                  "ContactEmail = ISNULL(@ContactEmail, ContactEmail), " &
                                  "ContactPhone = ISNULL(@ContactPhone, ContactPhone), " &
                                  "IsActive = ISNULL(@IsActive, IsActive) " &
                                  "WHERE CustomerID = @CustomerID"

            Dim cmd As New SqlCommand(query, conn)
            cmd.Parameters.AddWithValue("@CustomerName", If(values.ContainsKey("CustomerName"), values("CustomerName"), DBNull.Value))
            cmd.Parameters.AddWithValue("@CompanyName", If(values.ContainsKey("CompanyName"), values("CompanyName"), DBNull.Value))
            cmd.Parameters.AddWithValue("@ContactPerson", If(values.ContainsKey("ContactPerson"), values("ContactPerson"), DBNull.Value))
            cmd.Parameters.AddWithValue("@ContactEmail", If(values.ContainsKey("ContactEmail"), values("ContactEmail"), DBNull.Value))
            cmd.Parameters.AddWithValue("@ContactPhone", If(values.ContainsKey("ContactPhone"), values("ContactPhone"), DBNull.Value))
            cmd.Parameters.AddWithValue("@IsActive", If(values.ContainsKey("IsActive") AndAlso values("IsActive") = True, 1, 0))
            cmd.Parameters.AddWithValue("@CustomerID", customerId)

            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Public Shared Sub DeleteCustomer(customerId As Integer)
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            Dim cmd As New SqlCommand("DELETE FROM Customers WHERE CustomerID = @CustomerID", conn)
            cmd.Parameters.AddWithValue("@CustomerID", customerId)
            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

End Class
