﻿' DataAccess.vb
Imports System.Collections.Generic
Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Drawing
Imports System.IO
Imports System.Web.Script.Serialization

Public Class UserData
    Public Property UserID As Integer
    Public Property FullName As String
    Public Property Role As String ' ✅ Ensure this is present 
    Public Property Email As String
End Class

Public Class AttachmentData

    Public Property AttachmentID As Integer

    Public Property FileName As String

    Public Property FilePath As String

    Public Property UploadedByID As Integer

End Class

' Nayi TicketData class
Public Class TicketData
    Public Property TicketID As Integer
    Public Property TicketNo As String
    Public Property Department As String
    Public Property DateCreated As DateTime
    Public Property Status As String
    Public Property AssignedToID As Integer
    Public Property AssignedToFullName As String
    Public Property CreatedByID As Integer
    Public Property CreatedByFullName As String
    Public Property Summary As String
    Public Property Description As String
    Public Property ExpectedCompletionDate As Nullable(Of DateTime)
    Public Property TotalPoints As Integer
    ' ✅ New flattened properties from first Point
    Public Property PointTitle As String
    Public Property CustomerName As String
    Public Property Category As String
    Public Property ProductName As String
    Public Property PointSummary As String
    Public Property PointDescription As String
    Public Property Priority As String
    Public Property PointID As Nullable(Of Integer)
    Public Property PointStatus As String
    Public Property SortOrder As Nullable(Of Integer) ' ✅ Ye naya property add karein
    Public Property ExpectedDate As Nullable(Of DateTime)
    Public Property AudioFilePath As String
    Public Property ReportedByID As Nullable(Of Integer)
    Public Property ReportedByFullName As String

    Public Property ToDoDate As Nullable(Of DateTime)


    ' ✅ Time Tracking Properties
    Public Property ExpectedMinutes As Nullable(Of Integer)
    Public Property TotalTimeSpent As Nullable(Of Integer)
    Public Property PauseTimeMinutes As Nullable(Of Integer)
    Public Property LastActionTime As Nullable(Of DateTime)
    Public Property StartDate As Nullable(Of DateTime)
    Public Property DateCompleted As Nullable(Of DateTime)
    Public Property TotalElapsedMinutes As Nullable(Of Integer)

End Class

' PointData class mein naya TicketID aur ExpectedDate property add kiya
Public Class PointData
    Public Property PointID As Nullable(Of Integer)
    Public Property TicketID As Nullable(Of Integer)
    Public Property Title As String
    Public Property Summary As String
    Public Property Description As String
    Public Property CustomerID As Nullable(Of Integer)
    Public Property CustomerName As String
    Public Property ProductID As Nullable(Of Integer)
    Public Property ProductName As String
    Public Property ReportedByID As Nullable(Of Integer)
    Public Property ReportedByFullName As String
    Public Property AssignedToID As Nullable(Of Integer)
    Public Property AssignedToFullName As String
    Public Property AssignedByFullName As String
    Public Property DateCreated As Nullable(Of DateTime)
    Public Property StartDate As Nullable(Of DateTime)
    Public Property DateCompleted As Nullable(Of DateTime)
    Public Property DateClosed As Nullable(Of DateTime)
    Public Property Status As String
    Public Property Priority As String
    Public Property Category As String
    Public Property Complexity As String
    Public Property ExpectedDate As Nullable(Of DateTime)
    Public Property DateSentToQC As Nullable(Of DateTime)
    Public Property TesterStartDate As Nullable(Of DateTime)
    Public Property TesterCompleteDate As Nullable(Of DateTime)
    Public Property DeveloperStatus As String
    Public Property TesterStatus As String
    Public Property DeveloperRemark As String
    Public Property TesterRemark As String
    Public Property AudioFilePath As String
    Public Property DelayDuration As String
    Public Property DateSentToMerge As Nullable(Of DateTime)



    ' ✅ NEW: Time Tracking Properties
    Public Property ExpectedMinutes As Nullable(Of Integer)
    Public Property TotalTimeSpent As Nullable(Of Integer)
    Public Property PauseTimeMinutes As Nullable(Of Integer)
    Public Property LastActionTime As Nullable(Of DateTime)

    ' ✅ NEW: Support-specific Properties
    Public Property SupportStartDate As Nullable(Of DateTime)
    Public Property SupportCompleteDate As Nullable(Of DateTime)
    Public Property SupportRemark As String
    Public Property SupportTimeSpent As Nullable(Of Integer)
    Public Property SupportPauseTime As Nullable(Of Integer)
    Public Property SupportLastActionTime As Nullable(Of DateTime)
    Public Property IsSupportPaused As Nullable(Of Boolean)
    Public Property IsDeveloperPaused As Boolean

End Class

Public Class PointHistoryData
    Public Property HistoryID As Integer
    Public Property DeveloperID As Nullable(Of Integer)
    Public Property TesterID As Nullable(Of Integer)
    Public Property SupportID As Nullable(Of Integer)
    Public Property StartDate As Nullable(Of DateTime)
    Public Property CompleteDate As Nullable(Of DateTime)
    Public Property TesterStartDate As Nullable(Of DateTime)
    Public Property TesterCompleteDate As Nullable(Of DateTime)
    Public Property SupportStartDate As Nullable(Of DateTime)
    Public Property SupportCompleteDate As Nullable(Of DateTime)
    Public Property DeveloperRemark As String
    Public Property TesterRemark As String
    Public Property SupportRemark As String
    Public Property CycleStatus As String
    Public Property DeveloperAttachments As List(Of AttachmentData)
    Public Property TesterAttachments As List(Of AttachmentData)
    Public Property SupportAttachments As List(Of AttachmentData)

    ' ✅ NEW: Time Tracking Properties
    Public Property TimeSpentMinutes As Nullable(Of Integer)
    Public Property ExpectedMinutes As Nullable(Of Integer)
    Public Property ExtraTimeMinutes As Nullable(Of Integer)
    Public Property SupportTimeSpentMinutes As Nullable(Of Integer)
    Public Property DeveloperPauseMinutes As Nullable(Of Integer)
    Public Property SupportPauseMinutes As Nullable(Of Integer)
End Class

Public Class AttachmentInfo

    Public Property fileName As String

    Public Property filePath As String

End Class

' ✅ NEW: Time Log Data Class
Public Class PointTimeLogData
    Public Property LogID As Integer
    Public Property PointID As Integer
    Public Property Action As String
    Public Property ActionTime As DateTime
    Public Property PerformedByID As Nullable(Of Integer)
    Public Property Remarks As String
End Class

Public Class PointWithDate
    Public Property PointID As Integer
    Public Property ExpectedDate As Nullable(Of DateTime)
    Public Property ExpectedMinutes As Nullable(Of Integer)
End Class


' 👇 ADD THIS NEW CLASS TO YOUR DATAACCESS.VB FILE 👇
' 👇 REPLACE THIS CLASS IN YOUR DATAACCESS.VB FILE 👇
' 👇 REPLACE THIS CLASS IN YOUR DATAACCESS.VB FILE 👇
Public Class TimeReportData
    Public Property PointID As Integer
    Public Property Title As String
    Public Property ModuleName As String
    Public Property CustomerName As String
    Public Property Status As String
    Public Property ProductName As String
    Public Property Description As String
    Public Property ReportedBy As String
    Public Property AssignedTo As String
    Public Property AssignedBy As String
    Public Property CreatedDate As Nullable(Of DateTime)
    Public Property ExpectedDate As Nullable(Of DateTime)
    Public Property DateSentToMerge As Nullable(Of DateTime)
    Public Property ExpectedMinutes As Nullable(Of Integer)
    Public Property AssignedDate As Nullable(Of DateTime)
    Public Property DeveloperStartDate As Nullable(Of DateTime)
    Public Property DeveloperCompleteDate As Nullable(Of DateTime)
    Public Property DateSupportVerified As Nullable(Of DateTime)
    Public Property DateTicketVerified As Nullable(Of DateTime)

    ' ✅ UPDATED: Ab yeh "Total Elapsed Time" ko represent karega
    Public Property DeveloperTotalTime As Nullable(Of Integer)

    ' ✅ NEW: Yeh actual work time ko represent karega
    Public Property DeveloperActualTime As Nullable(Of Integer)

    Public Property DeveloperPauseTime As Nullable(Of Integer)
    Public Property DeveloperDelayTime As Nullable(Of Integer)
    Public Property SendToSupportDate As Nullable(Of DateTime)
    Public Property SupportTotalTime As Nullable(Of Integer)
    Public Property SupportPauseTime As Nullable(Of Integer)
    Public Property SupportActualTime As Nullable(Of Integer)
    Public Property ForwardToTesterDate As Nullable(Of DateTime)
    Public Property TesterStartDate As Nullable(Of DateTime)
    Public Property TesterCompleteDate As Nullable(Of DateTime)
    Public Property DateClosed As Nullable(Of DateTime)
End Class

Public Class WorkloadPoint
    Public Property Status As String
    Public Property ExpectedMinutes As Integer
    Public Property ToDoDate As Nullable(Of DateTime)

End Class

Public Class NotificationData
    Public Property NotificationID As Integer
    Public Property UserID_To As Integer
    Public Property MessageText As String
    Public Property NavigateURL As String
    Public Property IsRead As Boolean
    Public Property DateCreated As DateTime
    Public Property TimeAgo As String ' For UI
End Class

Public Class DataAccess

    Private Shared ReadOnly ConnectionString As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

    Public Shared Function GetUsers(Optional roleFilter As String = Nothing) As List(Of UserData)
        Dim users As New List(Of UserData)()
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT UserID, FullName, Role FROM Users"
            If Not String.IsNullOrEmpty(roleFilter) Then
                query &= " WHERE Role = @Role"
            End If
            query &= " ORDER BY FullName"

            Using cmd As New SqlCommand(query, conn)
                If Not String.IsNullOrEmpty(roleFilter) Then
                    cmd.Parameters.AddWithValue("@Role", roleFilter)
                End If

                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        users.Add(New UserData With {
                        .UserID = CInt(reader("UserID")),
                        .FullName = reader("FullName").ToString(),
                        .Role = reader("Role").ToString()
                    })
                    End While
                End Using
            End Using
        End Using
        Return users
    End Function

    Public Shared Function GetCustomers() As List(Of Object)
        Dim customers As New List(Of Object)()
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT CustomerID, CustomerName, CompanyName FROM Customers WHERE IsActive = 1 ORDER BY CustomerName"
            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        customers.Add(New With {
                            .CustomerID = reader("CustomerID"),
                            .CustomerName = reader("CustomerName"),
                            .CompanyName = reader("CompanyName")
                        })
                    End While
                End Using
            End Using
        End Using
        Return customers
    End Function

    Public Shared Function GetProducts() As List(Of Object)
        Dim products As New List(Of Object)()
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT ProductID, ProductName FROM Products WHERE IsActive = 1 ORDER BY ProductName"
            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        products.Add(New With {
                            .ProductID = reader("ProductID"),
                            .ProductName = reader("ProductName")
                        })
                    End While
                End Using
            End Using
        End Using
        Return products
    End Function

    ' INSERT Method (now can take TicketID)
    ' In App_Code/DataAccess.vb
    ' Replace your existing InsertPoint function with this one.

    Public Shared Function InsertPoint(data As PointData) As Integer
        Dim newPointId As Integer = -1
        Using conn As New SqlConnection(ConnectionString)
            ' Add ExpectedDate to the query
            Dim query As String = "INSERT INTO Points (Title, Summary, Description, CustomerID, ProductID, ReportedByID, AssignedToID, Status, Priority, Category, Complexity, TicketID, ExpectedDate,DateCreated) " &
                            "VALUES (@Title, @Summary, @Description, @CustomerID, @ProductID, @ReportedByID, @AssignedToID, @Status, @Priority, @Category, @Complexity, @TicketID, @ExpectedDate,GETUTCDATE()); SELECT SCOPE_IDENTITY();"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@Title", data.Title)
                cmd.Parameters.AddWithValue("@Summary", If(String.IsNullOrEmpty(data.Summary), DBNull.Value, data.Summary))
                cmd.Parameters.AddWithValue("@Description", data.Description)
                cmd.Parameters.AddWithValue("@CustomerID", data.CustomerID.Value)
                cmd.Parameters.AddWithValue("@ProductID", data.ProductID.Value)
                cmd.Parameters.AddWithValue("@ReportedByID", data.ReportedByID.Value)
                cmd.Parameters.AddWithValue("@Status", data.Status)
                cmd.Parameters.AddWithValue("@Priority", data.Priority)
                cmd.Parameters.AddWithValue("@Category", data.Category)
                cmd.Parameters.AddWithValue("@Complexity", If(String.IsNullOrEmpty(data.Complexity), DBNull.Value, data.Complexity))

                ' Add handling for NULLABLE fields
                If data.AssignedToID.HasValue Then
                    cmd.Parameters.AddWithValue("@AssignedToID", data.AssignedToID.Value)
                Else
                    cmd.Parameters.AddWithValue("@AssignedToID", DBNull.Value)
                End If

                If data.TicketID.HasValue Then
                    cmd.Parameters.AddWithValue("@TicketID", data.TicketID.Value)
                Else
                    cmd.Parameters.AddWithValue("@TicketID", DBNull.Value)
                End If

                ' *** NEW CHANGE FOR ExpectedDate ***
                If data.ExpectedDate.HasValue Then
                    cmd.Parameters.AddWithValue("@ExpectedDate", data.ExpectedDate.Value)
                Else
                    cmd.Parameters.AddWithValue("@ExpectedDate", DBNull.Value)
                End If

                conn.Open()
                newPointId = Convert.ToInt32(cmd.ExecuteScalar())
            End Using
        End Using
        Return newPointId
    End Function
    ' GET ALL POINTS FOR GRID Method (for Manage Points page)
    Public Shared Function GetAllPointsForGrid() As List(Of PointData)
        Dim points As New List(Of PointData)()
        Using conn As New SqlConnection(ConnectionString)
            ' ✅ FIX: Yahan se Convert(nvarchar...) hata diya gaya hai.
            ' Ab hum original datetime object select kar rahe hain.
            Dim query As String = "
 SELECT p.PointID, p.Title, p.DateCreated, 
        p.Status, p.Summary, p.Description, p.CustomerID, p.ProductID, 
        p.ReportedByID, p.AssignedToID, p.TicketID, p.StartDate, 
        p.DateCompleted, p.DateClosed, p.Priority, p.Category, 
        p.Complexity, p.ExpectedDate,
        c.CustomerName, prod.ProductName, 
        ru.FullName AS ReportedByFullName, 
        au.FullName AS AssignedToFullName,
        (
            SELECT TOP 1 FilePath 
            FROM PointAttachments pa 
            WHERE pa.PointID = p.PointID 
              AND pa.FileName LIKE '%.webm'
            ORDER BY pa.AttachmentID DESC
        ) AS AudioFilePath
 FROM Points p
 JOIN Customers c ON p.CustomerID = c.CustomerID
 JOIN Products prod ON p.ProductID = prod.ProductID
 JOIN Users ru ON p.ReportedByID = ru.UserID
 LEFT JOIN Users au ON p.AssignedToID = au.UserID
 ORDER BY p.DateCreated DESC"

            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        ' --- TIMEZONE CONVERSION LOGIC ---
                        Dim finalDateCreated As Nullable(Of DateTime) = Nothing
                        Dim dateCreatedUtcAsObject = reader("DateCreated")

                        ' Pehle check karein ki database se date NULL toh nahi aa rahi
                        If Not IsDBNull(dateCreatedUtcAsObject) Then
                            ' 1. Database se UTC date nikalein
                            Dim dateCreatedUtc As DateTime = CDate(dateCreatedUtcAsObject)

                            ' 2. Use Indian Standard Time (IST) mein convert karein
                            Dim indianZone As TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time")
                            finalDateCreated = TimeZoneInfo.ConvertTimeFromUtc(dateCreatedUtc, indianZone)
                        End If
                        ' --- CONVERSION LOGIC KHATAM HUA ---

                        points.Add(New PointData With {
                     .PointID = CInt(reader("PointID")),
                     .Title = reader("Title").ToString(),
                     .DateCreated = finalDateCreated,
                     .Status = reader("Status").ToString(),
                     .Summary = If(reader("Summary") Is DBNull.Value, Nothing, reader("Summary").ToString()),
                     .Description = If(reader("Description") Is DBNull.Value, Nothing, reader("Description").ToString()),
                     .CustomerID = CInt(reader("CustomerID")),
                     .ProductID = CInt(reader("ProductID")),
                     .ReportedByID = CInt(reader("ReportedByID")),
                     .AssignedToID = If(reader("AssignedToID") Is DBNull.Value, Nothing, CInt(reader("AssignedToID"))),
                     .TicketID = If(reader("TicketID") Is DBNull.Value, Nothing, CInt(reader("TicketID"))),
                     .StartDate = If(reader("StartDate") Is DBNull.Value, Nothing, CDate(reader("StartDate"))),
                     .DateCompleted = If(reader("DateCompleted") Is DBNull.Value, Nothing, CDate(reader("DateCompleted"))),
                     .DateClosed = If(reader("DateClosed") Is DBNull.Value, Nothing, CDate(reader("DateClosed"))),
                     .Priority = If(reader("Priority") Is DBNull.Value, Nothing, reader("Priority").ToString()),
                     .Category = If(reader("Category") Is DBNull.Value, Nothing, reader("Category").ToString()),
                     .Complexity = If(reader("Complexity") Is DBNull.Value, Nothing, reader("Complexity").ToString()),
                     .ExpectedDate = If(reader("ExpectedDate") Is DBNull.Value, Nothing, CDate(reader("ExpectedDate"))),
                     .CustomerName = reader("CustomerName").ToString(),
                     .ProductName = reader("ProductName").ToString(),
                     .ReportedByFullName = reader("ReportedByFullName").ToString(),
                     .AssignedToFullName = If(reader("AssignedToFullName") Is DBNull.Value, Nothing, reader("AssignedToFullName").ToString()),
                     .AudioFilePath = If(reader("AudioFilePath") Is DBNull.Value, Nothing, reader("AudioFilePath").ToString())
                 })
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function

    ' GET SINGLE POINT DETAILS BY ID Method (for View/Edit popup)

    ' In DataAccess.vb
    Public Shared Function GetPointDetailsById(ByVal pointId As Integer) As PointData
        Dim point As PointData = Nothing
        Using conn As New SqlConnection(ConnectionString)
            ' Query mein p.* se IsDeveloperPaused field aa jayega
            Dim query As String = "
      SELECT p.*, 
       c.CustomerName, pr.ProductName, 
       ru.FullName AS ReportedByFullName, 
       au.FullName AS AssignedToFullName,
       (
           SELECT TOP 1 FilePath 
           FROM PointAttachments pa 
           WHERE pa.PointID = p.PointID 
             AND pa.FileName LIKE '%.webm'
           ORDER BY pa.AttachmentID DESC
       ) AS AudioFilePath
    FROM Points p
    LEFT JOIN Customers c ON p.CustomerID = c.CustomerID
    LEFT JOIN Products pr ON p.ProductID = pr.ProductID
    LEFT JOIN Users ru ON p.ReportedByID = ru.UserID
    LEFT JOIN Users au ON p.AssignedToID = au.UserID
    WHERE p.PointID = @PointID"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    If reader.Read() Then
                        point = New PointData With {
                        .PointID = CInt(reader("PointID")),
                        .TicketID = If(IsDBNull(reader("TicketID")), CType(Nothing, Integer?), CInt(reader("TicketID"))),
                        .Title = reader("Title").ToString(),
                        .Summary = reader("Summary").ToString(),
                        .Description = reader("Description").ToString(),
                        .CustomerID = If(IsDBNull(reader("CustomerID")), CType(Nothing, Integer?), CInt(reader("CustomerID"))),
                        .CustomerName = reader("CustomerName").ToString(),
                        .ProductID = If(IsDBNull(reader("ProductID")), CType(Nothing, Integer?), CInt(reader("ProductID"))),
                        .ProductName = reader("ProductName").ToString(),
                        .ReportedByID = If(IsDBNull(reader("ReportedByID")), CType(Nothing, Integer?), CInt(reader("ReportedByID"))),
                        .ReportedByFullName = reader("ReportedByFullName").ToString(),
                        .AssignedToID = If(IsDBNull(reader("AssignedToID")), CType(Nothing, Integer?), CInt(reader("AssignedToID"))),
                        .AssignedToFullName = reader("AssignedToFullName").ToString(),
                        .DateCreated = If(IsDBNull(reader("DateCreated")), CType(Nothing, DateTime?), CDate(reader("DateCreated"))),
                        .StartDate = If(IsDBNull(reader("StartDate")), CType(Nothing, DateTime?), CDate(reader("StartDate"))),
                        .DateCompleted = If(IsDBNull(reader("DateCompleted")), CType(Nothing, DateTime?), CDate(reader("DateCompleted"))),
                        .DateClosed = If(IsDBNull(reader("DateClosed")), CType(Nothing, DateTime?), CDate(reader("DateClosed"))),
                        .Status = reader("Status").ToString(),
                        .Priority = reader("Priority").ToString(),
                        .Category = reader("Category").ToString(),
                        .Complexity = reader("Complexity").ToString(),
                        .ExpectedDate = If(IsDBNull(reader("ExpectedDate")), CType(Nothing, DateTime?), CDate(reader("ExpectedDate"))),
                        .TesterStartDate = If(IsDBNull(reader("TesterStartDate")), CType(Nothing, DateTime?), CDate(reader("TesterStartDate"))),
                        .TesterCompleteDate = If(IsDBNull(reader("TesterCompleteDate")), CType(Nothing, DateTime?), CDate(reader("TesterCompleteDate"))),
                        .DateSentToQC = If(IsDBNull(reader("DateSentToQC")), CType(Nothing, DateTime?), CDate(reader("DateSentToQC"))),
                        .DeveloperRemark = reader("DeveloperRemark").ToString(),
                        .TesterRemark = reader("TesterRemark").ToString(),
                        .AudioFilePath = If(IsDBNull(reader("AudioFilePath")), Nothing, reader("AudioFilePath").ToString()),
                        .SupportStartDate = If(IsDBNull(reader("SupportStartDate")), CType(Nothing, DateTime?), CDate(reader("SupportStartDate"))),
                        .SupportCompleteDate = If(IsDBNull(reader("SupportCompleteDate")), CType(Nothing, DateTime?), CDate(reader("SupportCompleteDate"))),
                        .SupportRemark = If(IsDBNull(reader("SupportRemark")), String.Empty, reader("SupportRemark").ToString()),
                        .SupportTimeSpent = If(IsDBNull(reader("SupportTimeSpent")), CType(Nothing, Integer?), CInt(reader("SupportTimeSpent"))),
                        .SupportPauseTime = If(IsDBNull(reader("SupportPauseTime")), CType(Nothing, Integer?), CInt(reader("SupportPauseTime"))),
                        .SupportLastActionTime = If(IsDBNull(reader("SupportLastActionTime")), CType(Nothing, DateTime?), CDate(reader("SupportLastActionTime"))),
                        .IsSupportPaused = If(IsDBNull(reader("IsSupportPaused")), CType(Nothing, Boolean?), CBool(reader("IsSupportPaused"))),
                        .IsDeveloperPaused = CBool(reader("IsDeveloperPaused"))
                    }
                    End If
                End Using
            End Using
        End Using
        Return point
    End Function
    ' UPDATE Method
    ' In DataAccess.vb

    Public Shared Function UpdatePoint(data As PointData) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "UPDATE Points SET " &
                              "Title = @Title, Summary = @Summary, Description = @Description, CustomerID = @CustomerID, ProductID = @ProductID, ReportedByID = @ReportedByID, " &
                              "AssignedToID = @AssignedToID, Status = @Status, Priority = @Priority, Category = @Category, Complexity = @Complexity, TicketID = @TicketID, ExpectedDate = @ExpectedDate " &
                              "WHERE PointID = @PointID"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", data.PointID.Value)
                cmd.Parameters.AddWithValue("@Title", data.Title)
                cmd.Parameters.AddWithValue("@Summary", If(String.IsNullOrEmpty(data.Summary), DBNull.Value, data.Summary))
                cmd.Parameters.AddWithValue("@Description", data.Description)
                cmd.Parameters.AddWithValue("@CustomerID", data.CustomerID.Value)
                cmd.Parameters.AddWithValue("@ProductID", data.ProductID.Value)
                cmd.Parameters.AddWithValue("@ReportedByID", data.ReportedByID.Value)

                ' AssignedToID (Nullable)
                If data.AssignedToID.HasValue AndAlso data.AssignedToID.Value > 0 Then
                    cmd.Parameters.AddWithValue("@AssignedToID", data.AssignedToID.Value)
                Else
                    cmd.Parameters.AddWithValue("@AssignedToID", DBNull.Value)
                End If

                cmd.Parameters.AddWithValue("@Status", data.Status)
                cmd.Parameters.AddWithValue("@Priority", data.Priority)
                cmd.Parameters.AddWithValue("@Category", data.Category)
                cmd.Parameters.AddWithValue("@Complexity", If(String.IsNullOrEmpty(data.Complexity), DBNull.Value, data.Complexity))

                ' TicketID (Nullable)
                If data.TicketID.HasValue AndAlso data.TicketID.Value > 0 Then
                    cmd.Parameters.AddWithValue("@TicketID", data.TicketID.Value)
                Else
                    cmd.Parameters.AddWithValue("@TicketID", DBNull.Value)
                End If

                ' ✅ Fix for ExpectedDate (Nullable DateTime)
                If data.ExpectedDate.HasValue AndAlso data.ExpectedDate.Value > DateTime.MinValue Then
                    cmd.Parameters.AddWithValue("@ExpectedDate", data.ExpectedDate.Value)
                Else
                    cmd.Parameters.AddWithValue("@ExpectedDate", DBNull.Value)
                End If

                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    ' DELETE Method
    Public Shared Function DeletePoint(ByVal pointId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            conn.Open()

            ' Step 1: Get TicketID from the point before deleting
            Dim ticketId As Integer = 0
            Using getTicketCmd As New SqlCommand("SELECT TicketID FROM Points WHERE PointID = @PointID", conn)
                getTicketCmd.Parameters.AddWithValue("@PointID", pointId)
                Dim obj = getTicketCmd.ExecuteScalar()
                If obj IsNot Nothing AndAlso Not IsDBNull(obj) Then
                    ticketId = Convert.ToInt32(obj)
                End If
            End Using

            ' Step 2: Delete the point
            Using deletePointCmd As New SqlCommand("DELETE FROM Points WHERE PointID = @PointID", conn)
                deletePointCmd.Parameters.AddWithValue("@PointID", pointId)
                deletePointCmd.ExecuteNonQuery()
            End Using

            ' Step 3: Check remaining points for that TicketID
            Dim remainingCount As Integer = 0
            Using checkCmd As New SqlCommand("SELECT COUNT(*) FROM Points WHERE TicketID = @TicketID", conn)
                checkCmd.Parameters.AddWithValue("@TicketID", ticketId)
                remainingCount = Convert.ToInt32(checkCmd.ExecuteScalar())
            End Using

            ' Step 4: If no points remain, delete the ticket
            If remainingCount = 0 Then
                Using deleteTicketCmd As New SqlCommand("DELETE FROM Tickets WHERE TicketID = @TicketID", conn)
                    deleteTicketCmd.Parameters.AddWithValue("@TicketID", ticketId)
                    deleteTicketCmd.ExecuteNonQuery()
                End Using
            End If

            Return True
        End Using
    End Function

    ' GET QUEUE POINTS FOR GRID Method (for Create Ticket page)
    ' ✅✅✅ PURAANE GetQueuePointsForGrid FUNCTION KO IS NAYE, CORRECTED VERSION SE REPLACE KAREIN ✅✅✅

    Public Shared Function GetQueuePointsForGrid() As List(Of PointData)
        Dim points As New List(Of PointData)()
        Using conn As New SqlConnection(ConnectionString)
            conn.Open()
            ' SQL Query mein koi change nahi karna hai, woh pehle se hi p.DateCreated fetch kar rahi hai
            Dim query As String = "
        SELECT 
            p.PointID, p.Title, p.CustomerID, p.ProductID, p.DateCreated, 
            p.Priority, p.Category, p.Complexity, p.Description, p.Summary,
            p.ReportedByID, ru.FullName AS ReportedByFullName,
            c.CustomerName, pr.ProductName, pa.AudioFilePath, p.ExpectedDate 
        FROM Points p
        JOIN Customers c ON p.CustomerID = c.CustomerID
        JOIN Products pr ON p.ProductID = pr.ProductID
        JOIN Users ru ON p.ReportedByID = ru.UserID
        OUTER APPLY (
            SELECT TOP 1 pa.FilePath AS AudioFilePath
            FROM PointAttachments pa
            WHERE pa.PointID = p.PointID 
              AND pa.FileName LIKE '%.webm'
            ORDER BY pa.AttachmentID DESC
        ) pa
        WHERE p.Status = 'Queue' 
           AND p.IsVerified = 1 
          AND p.TicketID IS NULL;"

            Using cmd As New SqlCommand(query, conn)
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        ' Step 1: Yahan par Timezone Conversion ka logic add karein
                        Dim finalDateCreated As Nullable(Of DateTime) = Nothing
                        Dim dateCreatedUtcAsObject = reader("DateCreated")

                        If Not IsDBNull(dateCreatedUtcAsObject) Then
                            Dim dateCreatedUtc As DateTime = CDate(dateCreatedUtcAsObject)
                            Dim indianZone As TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time")
                            finalDateCreated = TimeZoneInfo.ConvertTimeFromUtc(dateCreatedUtc, indianZone)
                        End If
                        ' --- CONVERSION LOGIC KHATAM HUA ---

                        Dim point As New PointData()
                        point.PointID = Convert.ToInt32(reader("PointID"))
                        point.Title = reader("Title").ToString()
                        point.CustomerName = reader("CustomerName").ToString()
                        point.ProductName = reader("ProductName").ToString()
                        point.Summary = reader("Summary").ToString()
                        point.Description = reader("Description").ToString()

                        ' Step 2: Naye 'finalDateCreated' variable ko use karein
                        point.DateCreated = finalDateCreated ' ✅ Yahan change hua hai

                        point.ExpectedDate = If(reader.IsDBNull(reader.GetOrdinal("ExpectedDate")), Nothing, CType(reader("ExpectedDate"), DateTime?))
                        point.Priority = reader("Priority").ToString()
                        point.Category = reader("Category").ToString()
                        point.Complexity = reader("Complexity").ToString()
                        point.ReportedByID = CInt(reader("ReportedByID"))
                        point.ReportedByFullName = reader("ReportedByFullName").ToString()
                        point.AudioFilePath = If(IsDBNull(reader("AudioFilePath")), Nothing, reader("AudioFilePath").ToString())
                        points.Add(point)
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function

    ' ==== DataAccess.vb mein yeh NAYA function add karein ====
    Public Shared Function UpdatePointExpectedDate(pointId As Integer, newExpectedDate As DateTime) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "UPDATE Points SET ExpectedDate = @ExpectedDate WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@ExpectedDate", newExpectedDate)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    ' --- NEW METHODS FOR TICKETS TABLE ---

    ' New Method: Create a new Ticket and assign points to it


    ' REPLACE your old CreateTicketAndAssignPoints function with this new one

    Public Shared Function CreateTicketAndAssignPoints(pointsWithDates As List(Of PointWithDate),
                                              assignedToID As Integer,
                                              createdByID As Integer,
                                              department As String,
                                              newPointStatus As String) As (success As Boolean, message As String, ticketNo As String)

        Dim ticketID As Integer = 0
        Dim ticketNo As String = Now.ToString("yyyyMMddHHmmss")

        Using con As New SqlConnection(ConnectionString)
            con.Open()
            Dim tran As SqlTransaction = con.BeginTransaction()
            Try
                ' Step 1: Ticket (Assignment) banayein (Ismein koi change nahi)
                Dim insertTicketQuery As String = "INSERT INTO Tickets (TicketNo, AssignedToID, CreatedByID, Department, DateCreated, Status) OUTPUT INSERTED.TicketID VALUES (@TicketNo, @AssignedToID, @CreatedByID, @Department, GETDATE(), 'Open')"
                Using cmd As New SqlCommand(insertTicketQuery, con, tran)
                    cmd.Parameters.AddWithValue("@TicketNo", ticketNo)
                    cmd.Parameters.AddWithValue("@AssignedToID", assignedToID)
                    cmd.Parameters.AddWithValue("@CreatedByID", createdByID)
                    cmd.Parameters.AddWithValue("@Department", department)
                    ticketID = Convert.ToInt32(cmd.ExecuteScalar())
                End Using

                If ticketID <= 0 Then Throw New Exception("Ticket insert failed.")

                ' Step 2: Har Point ko uski nayi Expected Date aur Expected Minutes ke saath update karein
                For Each point As PointWithDate In pointsWithDates
                    Dim updatePointQuery As String = "UPDATE Points SET AssignedToID = @AssignedToID, TicketID = @TicketID, Status = @Status, ExpectedDate = @ExpectedDate, ExpectedMinutes = @ExpectedMinutes WHERE PointID = @PointID"
                    Using cmd As New SqlCommand(updatePointQuery, con, tran)
                        cmd.Parameters.AddWithValue("@AssignedToID", assignedToID)
                        cmd.Parameters.AddWithValue("@TicketID", ticketID)
                        cmd.Parameters.AddWithValue("@Status", newPointStatus)
                        cmd.Parameters.AddWithValue("@PointID", point.PointID)
                        ' Nayi date ko parameter mein add karein
                        If point.ExpectedDate.HasValue Then
                            cmd.Parameters.AddWithValue("@ExpectedDate", point.ExpectedDate.Value)
                        Else
                            cmd.Parameters.AddWithValue("@ExpectedDate", DBNull.Value)
                        End If
                        ' Expected Minutes ko parameter mein add karein
                        If point.ExpectedMinutes.HasValue Then
                            cmd.Parameters.AddWithValue("@ExpectedMinutes", point.ExpectedMinutes.Value)
                        Else
                            cmd.Parameters.AddWithValue("@ExpectedMinutes", DBNull.Value)
                        End If
                        cmd.ExecuteNonQuery()
                    End Using
                Next

                tran.Commit()
                Return (True, "Ticket created and points assigned successfully.", ticketNo)

            Catch ex As Exception
                tran.Rollback()
                Return (False, "DB Error: " & ex.Message, "")
            End Try
        End Using
    End Function


    ' Naya Method: Main Tickets Grid ke liye data fetch karna
    ' Naya Method: Main Tickets Grid ke liye data fetch karna
    Public Shared Function GetTicketsForMainGrid() As List(Of TicketData)
        Dim tickets As New List(Of TicketData)()
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "
        SELECT
            t.TicketID, t.TicketNo, t.Department, t.DateCreated,
            t.Summary AS TicketSummary, t.Description AS TicketDescription,
            t.ExpectedCompletionDate,

            pu.FullName AS AssignedToFullName,       -- ✅ AssignedTo from Points
            p.AssignedToID,                          -- ✅ AssignedToID from Points

            cu.FullName AS CreatedByFullName,
            t.CreatedByID,

            p.PointID, p.Title AS PointTitle, p.Summary AS PointSummary,
            p.Description AS PointDescription, p.Priority,
            p.Status AS PointStatus,
            p.ReportedByID,
            ru.FullName AS ReportedByFullName,  
            pa.FilePath AS AudioFilePath,  
            c.CustomerName, pr.ProductName,
            p.SortOrder,
            p.ToDoDate
        FROM Tickets t
        LEFT JOIN Points p ON p.TicketID = t.TicketID
        LEFT JOIN Customers c ON c.CustomerID = p.CustomerID
        LEFT JOIN Products pr ON pr.ProductID = p.ProductID
        LEFT JOIN PointAttachments pa ON pa.PointID = p.PointID AND pa.FilePath LIKE '%.webm'
        JOIN Users cu ON t.CreatedByID = cu.UserID
        JOIN Users ru ON p.ReportedByID = ru.UserID
        LEFT JOIN Users pu ON p.AssignedToID = pu.UserID   -- ✅ FIXED
        WHERE p.PointID IS NOT NULL
        ORDER BY p.SortOrder ASC
        "

            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        tickets.Add(New TicketData With {
                        .TicketID = CInt(reader("TicketID")),
                        .TicketNo = reader("TicketNo").ToString(),
                        .Department = If(reader("Department") Is DBNull.Value, Nothing, reader("Department").ToString()),
                        .AssignedToID = If(reader("AssignedToID") Is DBNull.Value, Nothing, CInt(reader("AssignedToID"))),
                        .AssignedToFullName = If(reader("AssignedToFullName") Is DBNull.Value, Nothing, reader("AssignedToFullName").ToString()),
                        .CreatedByID = CInt(reader("CreatedByID")),
                        .CreatedByFullName = reader("CreatedByFullName").ToString(),
                        .DateCreated = CDate(reader("DateCreated")),
                        .ReportedByID = CInt(reader("ReportedByID")),
                        .ReportedByFullName = reader("ReportedByFullName").ToString(),
                        .Status = "Open",  ' Status is now static or derived differently if needed
                        .Summary = If(reader("TicketSummary") Is DBNull.Value, Nothing, reader("TicketSummary").ToString()),
                        .Description = If(reader("TicketDescription") Is DBNull.Value, Nothing, reader("TicketDescription").ToString()),
                        .ExpectedCompletionDate = If(reader("ExpectedCompletionDate") Is DBNull.Value, Nothing, CDate(reader("ExpectedCompletionDate"))),
                        .PointID = If(reader("PointID") Is DBNull.Value, Nothing, CInt(reader("PointID"))),
                        .PointTitle = If(reader("PointTitle") Is DBNull.Value, Nothing, reader("PointTitle").ToString()),
                        .PointSummary = If(reader("PointSummary") Is DBNull.Value, Nothing, reader("PointSummary").ToString()),
                        .PointDescription = If(reader("PointDescription") Is DBNull.Value, Nothing, reader("PointDescription").ToString()),
                        .Priority = If(reader("Priority") Is DBNull.Value, Nothing, reader("Priority").ToString()),
                        .CustomerName = If(reader("CustomerName") Is DBNull.Value, Nothing, reader("CustomerName").ToString()),
                        .ProductName = If(reader("ProductName") Is DBNull.Value, Nothing, reader("ProductName").ToString()),
                        .PointStatus = If(reader("PointStatus") Is DBNull.Value, Nothing, reader("PointStatus").ToString()),
                        .SortOrder = If(reader("SortOrder") Is DBNull.Value, Nothing, CInt(reader("SortOrder"))),
                        .AudioFilePath = If(reader("AudioFilePath") Is DBNull.Value, Nothing, reader("AudioFilePath").ToString()),
                        .ToDoDate = If(reader("ToDoDate") Is DBNull.Value, Nothing, CDate(reader("ToDoDate")))
                    })
                    End While
                End Using
            End Using
        End Using
        Return tickets
    End Function


    ' Naya Method: Ek particular Ticket ID ke points ko fetch karna (sub-grid ke liye)

    Public Shared Function GetPointsByTicketId(ticketId As Integer) As List(Of PointData)
        Dim points As New List(Of PointData)()
        Using conn As New SqlConnection(ConnectionString)

            Dim query As String = "SELECT p.PointID, p.Title, p.DateCreated, p.Status, p.Summary, p.Description, p.CustomerID, p.ProductID, " &
                          "p.ReportedByID, p.AssignedToID, p.TicketID, p.StartDate, p.DateCompleted, p.DateClosed, " &
                          "p.Priority, p.Category, p.Complexity, p.ExpectedDate, " &
                          "c.CustomerName, prod.ProductName, ru.FullName AS ReportedByFullName, au.FullName AS AssignedToFullName " &
                          "FROM Points p " &
                          "JOIN Customers c ON p.CustomerID = c.CustomerID " &
                          "JOIN Products prod ON p.ProductID = prod.ProductID " &
                          "JOIN Users ru ON p.ReportedByID = ru.UserID " &
                          "LEFT JOIN Users au ON p.AssignedToID = au.UserID " &
                          "WHERE p.TicketID = @TicketID " &
                          "ORDER BY p.SortOrder ASC, p.DateCreated ASC"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@TicketID", ticketId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()

                        points.Add(New PointData With {
                        .PointID = CInt(reader("PointID")),
                        .Title = reader("Title").ToString(),
                        .DateCreated = CDate(reader("DateCreated")),
                        .Status = reader("Status").ToString(),
                        .Summary = If(reader("Summary") Is DBNull.Value, Nothing, reader("Summary").ToString()),
                        .Description = If(reader("Description") Is DBNull.Value, Nothing, reader("Description").ToString()),
                        .CustomerID = CInt(reader("CustomerID")),
                        .ProductID = CInt(reader("ProductID")),
                        .ReportedByID = CInt(reader("ReportedByID")),
                        .AssignedToID = If(reader("AssignedToID") Is DBNull.Value, Nothing, CType(reader("AssignedToID"), Integer?)),
                        .TicketID = If(reader("TicketID") Is DBNull.Value, Nothing, CType(reader("TicketID"), Integer?)),
                        .StartDate = If(reader("StartDate") Is DBNull.Value, Nothing, CType(reader("StartDate"), DateTime?)),
                        .DateCompleted = If(reader("DateCompleted") Is DBNull.Value, Nothing, CType(reader("DateCompleted"), DateTime?)),
                        .DateClosed = If(reader("DateClosed") Is DBNull.Value, Nothing, CType(reader("DateClosed"), DateTime?)),
                        .Priority = If(reader("Priority") Is DBNull.Value, Nothing, reader("Priority").ToString()),
                        .Category = If(reader("Category") Is DBNull.Value, Nothing, reader("Category").ToString()),
                        .Complexity = If(reader("Complexity") Is DBNull.Value, Nothing, reader("Complexity").ToString()),
                        .ExpectedDate = If(reader("ExpectedDate") Is DBNull.Value, Nothing, CType(reader("ExpectedDate"), DateTime?)),
                        .CustomerName = reader("CustomerName").ToString(),
                        .ProductName = reader("ProductName").ToString(),
                        .ReportedByFullName = reader("ReportedByFullName").ToString(),
                        .AssignedToFullName = If(reader("AssignedToFullName") Is DBNull.Value, Nothing, reader("AssignedToFullName").ToString())
                    })
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function



    ' ✅✅✅ IS POORE FUNCTION KO NAYE, FINAL CORRECTED VERSION SE REPLACE KAREIN ✅✅✅

    Public Shared Function GetTicketsWithPointsByDeveloper(devId As Integer) As List(Of TicketData)
        Dim results As New List(Of TicketData)()
        Using conn As New SqlConnection(ConnectionString)
            ' ▼▼▼ START OF MODIFIED QUERY ▼▼▼
            ' This query now fetches all points for the developer, regardless of their status.
            Dim query As String = "
SELECT
t.TicketID,
t.TicketNo,
t.CreatedByID,
t.Department,
p.DateCreated,
t.ExpectedCompletionDate,
t.Status AS TicketStatus,
p.AssignedToID,
au.FullName AS AssignedToFullName,
t.CreatedByID,
cu.FullName AS CreatedByFullName,
p.PointID,
p.Title AS PointTitle,
p.Summary AS PointSummary,
p.Description AS PointDescription,
p.CustomerID,
c.CustomerName,
p.Category,
p.ReportedByID,
ru.FullName AS ReportedByFullName,
p.ProductID,
pr.ProductName,
p.Priority,
p.Status AS PointStatus,
p.ExpectedDate,
p.SortOrder,
p.ToDoDate,
p.ExpectedMinutes,
p.TotalTimeSpent,
p.PauseTimeMinutes,
p.LastActionTime,
p.StartDate,
p.DateCompleted,
(
    ISNULL((
        SELECT SUM(DATEDIFF(MINUTE, StartDate, CompleteDate))
        FROM PointHistory
        WHERE PointID = p.PointID
        AND StartDate IS NOT NULL
        AND CompleteDate IS NOT NULL
    ), 0)
    +
    ISNULL((
        CASE
            WHEN p.StartDate IS NOT NULL AND p.DateCompleted IS NOT NULL
            THEN DATEDIFF(MINUTE, p.StartDate, p.DateCompleted)
            ELSE 0
        END
    ), 0)
) AS TotalElapsedMinutes,

-- Audio file (if exists)
pa.FilePath AS AudioFilePath
FROM Tickets t
INNER JOIN Users cu ON cu.UserID = t.CreatedByID
INNER JOIN Points p ON p.TicketID = t.TicketID
LEFT JOIN Users au ON au.UserID = p.AssignedToID
LEFT JOIN Customers c ON c.CustomerID = p.CustomerID
LEFT JOIN Products pr ON pr.ProductID = p.ProductID
LEFT JOIN Users ru ON ru.UserID = p.ReportedByID
LEFT JOIN PointAttachments pa
ON pa.PointID = p.PointID
AND pa.FilePath LIKE '%.webm'
WHERE
p.AssignedToID = @DevId -- STATUS FILTER REMOVED TO SHOW ALL POINTS
ORDER BY
CASE
WHEN p.Status = 'SupportVerified' THEN 0
WHEN p.Status = 'PendingMerge' THEN 1
ELSE 2
END,
p.SortOrder ASC;
"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@DevId", devId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        results.Add(New TicketData With {
            .TicketID = CInt(reader("TicketID")),
            .TicketNo = reader("TicketNo").ToString(),
            .Department = reader("Department").ToString(),
            .DateCreated = FormatDateToUtcIsoString((reader("DateCreated"))),
            .ExpectedCompletionDate = If(reader("ExpectedCompletionDate") Is DBNull.Value, Nothing, CDate(reader("ExpectedCompletionDate"))),
            .Status = reader("TicketStatus").ToString(),
            .ReportedByID = CInt(reader("ReportedByID")),
            .ReportedByFullName = reader("ReportedByFullName").ToString(),
            .CreatedByID = CInt(reader("CreatedByID")),
            .Category = reader("Category").ToString(),
            .CreatedByFullName = reader("CreatedByFullName").ToString(),
            .PointID = CInt(reader("PointID")),
            .PointTitle = reader("PointTitle").ToString(),
            .PointSummary = reader("PointSummary").ToString(),
            .PointDescription = reader("PointDescription").ToString(),
            .CustomerName = reader("CustomerName").ToString(),
            .ProductName = reader("ProductName").ToString(),
            .Priority = reader("Priority").ToString(),
            .PointStatus = reader("PointStatus").ToString(),
            .ExpectedDate = If(reader("ExpectedDate") Is DBNull.Value, Nothing, CDate(reader("ExpectedDate"))),
            .SortOrder = If(reader("SortOrder") Is DBNull.Value, Nothing, CInt(reader("SortOrder"))),
            .AudioFilePath = If(reader("AudioFilePath") Is DBNull.Value, Nothing, reader("AudioFilePath").ToString()),
            .AssignedToID = If(reader("AssignedToID") Is DBNull.Value, Nothing, CInt(reader("AssignedToID"))),
            .AssignedToFullName = If(reader("AssignedToFullName") Is DBNull.Value, Nothing, reader("AssignedToFullName").ToString()),
            .ExpectedMinutes = If(reader("ExpectedMinutes") Is DBNull.Value, Nothing, CInt(reader("ExpectedMinutes"))),
            .TotalTimeSpent = If(reader("TotalTimeSpent") Is DBNull.Value, Nothing, CInt(reader("TotalTimeSpent"))),
            .PauseTimeMinutes = If(reader("PauseTimeMinutes") Is DBNull.Value, Nothing, CInt(reader("PauseTimeMinutes"))),
            .LastActionTime = If(reader("LastActionTime") Is DBNull.Value, Nothing, CDate(reader("LastActionTime"))),
            .StartDate = If(reader("StartDate") Is DBNull.Value, Nothing, CDate(reader("StartDate"))),
            .DateCompleted = If(reader("DateCompleted") Is DBNull.Value, Nothing, CDate(reader("DateCompleted"))),
            .TotalElapsedMinutes = If(reader("TotalElapsedMinutes") Is DBNull.Value, Nothing, CInt(reader("TotalElapsedMinutes"))),
            .ToDoDate = If(reader("ToDoDate") Is DBNull.Value, Nothing, CDate(reader("ToDoDate")))
          })
                    End While
                End Using
            End Using
        End Using
        Return results
    End Function


    Public Shared Function UpdatePointStartTime(pointId As Integer) As Nullable(Of DateTime)
        Try
            Dim now As DateTime = DateTime.Now
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "UPDATE Points SET StartDate = @StartDate WHERE PointID = @PointID"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@StartDate", now)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    If cmd.ExecuteNonQuery() > 0 Then
                        Return now
                    Else
                        Return Nothing
                    End If
                End Using
            End Using
        Catch ex As Exception
            System.Diagnostics.Trace.WriteLine("UpdatePointStartTime ERROR: " & ex.Message)
            Return Nothing
        End Try
    End Function

    Public Shared Function UpdatePointCompleteTime(ByVal pointId As Integer) As Nullable(Of DateTime)
        Dim completeTime As DateTime = DateTime.Now
        Using conn As New SqlConnection(ConnectionString)
            ' --- THE FIX IS HERE: Add "AND DateCompleted IS NULL" ---
            Dim query As String = "UPDATE Points SET DateCompleted = @CompleteTime WHERE PointID = @PointID AND DateCompleted IS NULL"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                cmd.Parameters.AddWithValue("@CompleteTime", completeTime)
                conn.Open()
                Dim rowsAffected = cmd.ExecuteNonQuery()
                If rowsAffected > 0 Then
                    Return completeTime
                End If
                Return Nothing
            End Using
        End Using
    End Function

    ' Function to update only the Status of a point
    Public Shared Function UpdatePointStatus(ByVal pointId As Integer, ByVal newStatus As String) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "UPDATE Points SET Status = @NewStatus WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                cmd.Parameters.AddWithValue("@NewStatus", newStatus)
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    ' This function is specifically for the Developer Dashboard's sub-grid
    Public Shared Function GetPointsForDeveloperDashboard(ByVal ticketId As Integer) As List(Of PointData)
        Dim points As New List(Of PointData)()
        Using conn As New SqlConnection(ConnectionString)
            ' Query to get only the fields needed for the developer dashboard sub-grid
            Dim query As String = "SELECT p.PointID, p.Title, p.Priority, p.ExpectedDate, p.Status, ru.FullName AS ReportedByFullName " &
                                  "FROM Points p " &
                                  "LEFT JOIN Users ru ON p.ReportedByID = ru.UserID " &
                                 "WHERE p.TicketID = @TicketID ORDER BY p.SortOrder ASC, p.DateCreated ASC"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@TicketID", ticketId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        points.Add(New PointData With {
                            .PointID = CInt(reader("PointID")),
                            .Title = reader("Title").ToString(),
                            .Priority = If(reader("Priority") Is DBNull.Value, Nothing, reader("Priority").ToString()),
                            .ExpectedDate = If(reader("ExpectedDate") Is DBNull.Value, Nothing, CDate(reader("ExpectedDate"))),
                            .Status = reader("Status").ToString(),
                            .ReportedByFullName = If(reader("ReportedByFullName") Is DBNull.Value, "N/A", reader("ReportedByFullName").ToString())
                        })
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function

    ' In DataAccess.vb
    ' Replace the entire function with this new, simple, and error-free version.

    Public Shared Function GetPointsForTesterDashboard() As List(Of PointData)
        Dim points As New List(Of PointData)()
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT p.PointID, p.Title, p.Priority, p.Status, p.DateSentToQC, p.Description, " &
                              "c.CustomerID, c.CustomerName, " &
                              "ru.FullName AS ReportedByFullName, " &
                              "au.FullName AS AssignedToFullName, " &
                              "p.Summary, " &
                              "pa.FilePath AS AudioFilePath " &   ' ✅ space added before FROM
                              "FROM Points p " &
                              "JOIN Customers c ON p.CustomerID = c.CustomerID " &
                              "LEFT JOIN Users ru ON p.ReportedByID = ru.UserID " &
                              "LEFT JOIN Users au ON p.AssignedToID = au.UserID " &
                              "LEFT JOIN PointAttachments pa ON pa.PointID = p.PointID AND pa.FilePath LIKE '%.webm' " &   ' ✅ fixed join
                              "WHERE p.Status IN('PendingQC','In-Testing','Testing-Completed','Closed','ReOpened') " &
                              "ORDER BY p.DateSentToQC ASC"

            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim tempPoint As New PointData()

                        tempPoint.PointID = CInt(reader("PointID"))
                        tempPoint.Title = reader("Title").ToString()
                        tempPoint.Priority = If(reader("Priority") Is DBNull.Value, "", reader("Priority").ToString())
                        tempPoint.Status = reader("Status").ToString()
                        tempPoint.DateSentToQC = If(reader("DateSentToQC") Is DBNull.Value, Nothing, CDate(reader("DateSentToQC")))
                        tempPoint.ReportedByFullName = If(reader("ReportedByFullName") Is DBNull.Value, "N/A", reader("ReportedByFullName").ToString())
                        tempPoint.AssignedToFullName = If(reader("AssignedToFullName") Is DBNull.Value, "N/A", reader("AssignedToFullName").ToString())
                        tempPoint.CustomerID = CInt(reader("CustomerID"))
                        tempPoint.CustomerName = reader("CustomerName").ToString()
                        tempPoint.Description = If(reader("Description") Is DBNull.Value, Nothing, reader("Description").ToString())
                        tempPoint.Summary = If(reader("Summary") Is DBNull.Value, Nothing, reader("Summary").ToString())
                        tempPoint.AudioFilePath = If(reader("AudioFilePath") Is DBNull.Value, Nothing, reader("AudioFilePath").ToString())

                        points.Add(tempPoint)
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function



    Public Shared Function UpdatePointStatusAndDate(ByVal pointId As Integer, ByVal newStatus As String, Optional ByVal dateFieldName As String = "", Optional ByVal dateValue As Nullable(Of DateTime) = Nothing) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "UPDATE Points SET Status = @NewStatus"

            If Not String.IsNullOrEmpty(dateFieldName) AndAlso dateValue.HasValue Then

                Dim allowedFields As New List(Of String) From {"StartDate", "DateCompleted", "DateSentToQC", "TesterStartDate", "DateClosed", "TesterCompleteDate", "DateSupportVerified"}

                If allowedFields.Contains(dateFieldName) Then
                    ' This is a safe way to build the query
                    query &= ", " & dateFieldName & " = @DateValue"
                Else
                    ' If an invalid field name is passed, throw an error to prevent SQL injection.
                    Throw New ArgumentException("Invalid date field name specified.")
                End If
            End If

            query &= " WHERE PointID = @PointID"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                cmd.Parameters.AddWithValue("@NewStatus", newStatus)
                If Not String.IsNullOrEmpty(dateFieldName) AndAlso dateValue.HasValue Then
                    cmd.Parameters.AddWithValue("@DateValue", dateValue.Value)
                End If
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    ' Creates a new record in PointHistory when developer sends a point to QC
    Public Shared Sub CreatePointHistoryCycle(pointId As Integer, developerId As Integer, developerRemark As String)

        Using conn As New SqlConnection(ConnectionString)
            conn.Open()
            Dim tran As SqlTransaction = conn.BeginTransaction()
            Try

                ' Step 1: Create the history record and GET its newly created ID
                Dim newHistoryId As Integer

                ' Calculate and update total time BEFORE fetching point details
                Dim totalMinsNow As Integer = CalculateAndUpdateTotalTime(pointId)

                Dim pointDetails As PointData = GetPointDetailsById(pointId) ' Assuming this works without a transaction or create an overload that accepts one.

                ' Calculate THIS ROUND's time only (subtract previous rounds)
                Dim previousRoundsTotal As Integer = 0
                Dim prevQuery As String = "SELECT ISNULL(SUM(TimeSpentMinutes), 0) FROM PointHistory WHERE PointID = @PointID"
                Using prevCmd As New SqlCommand(prevQuery, conn, tran)
                    prevCmd.Parameters.AddWithValue("@PointID", pointId)
                    Dim result = prevCmd.ExecuteScalar()
                    If result IsNot Nothing AndAlso Not IsDBNull(result) Then
                        previousRoundsTotal = Convert.ToInt32(result)
                    End If
                End Using

                Dim currentRoundMins As Integer = totalMinsNow - previousRoundsTotal

                ' Calculate extra time if applicable
                Dim expectedMins As Integer = If(pointDetails.ExpectedMinutes.HasValue, pointDetails.ExpectedMinutes.Value, 0)
                Dim extraMins As Integer = If(totalMinsNow > expectedMins, totalMinsNow - expectedMins, 0)

                Dim insertQuery As String = "INSERT INTO PointHistory (PointID, DeveloperID, StartDate, CompleteDate, SentToQCDate, DeveloperRemark, CycleStatus, TimeSpentMinutes, ExpectedMinutes, ExtraTimeMinutes) " &
                                        "VALUES (@PointID, @DeveloperID, @StartDate, @CompleteDate, @SentToQCDate, @DeveloperRemark, 'SentToQC', @TimeSpentMinutes, @ExpectedMinutes, @ExtraTimeMinutes); SELECT SCOPE_IDENTITY();"

                Using insertCmd As New SqlCommand(insertQuery, conn, tran)

                    insertCmd.Parameters.AddWithValue("@PointID", pointId)

                    insertCmd.Parameters.AddWithValue("@DeveloperID", developerId)

                    insertCmd.Parameters.AddWithValue("@StartDate", If(pointDetails.StartDate.HasValue, CObj(pointDetails.StartDate.Value), DBNull.Value))

                    insertCmd.Parameters.AddWithValue("@CompleteDate", If(pointDetails.DateCompleted.HasValue, CObj(pointDetails.DateCompleted.Value), DBNull.Value))

                    insertCmd.Parameters.AddWithValue("@SentToQCDate", DateTime.Now)

                    insertCmd.Parameters.AddWithValue("@DeveloperRemark", If(String.IsNullOrEmpty(developerRemark), DBNull.Value, developerRemark))

                    insertCmd.Parameters.AddWithValue("@TimeSpentMinutes", If(currentRoundMins > 0, CObj(currentRoundMins), DBNull.Value))

                    insertCmd.Parameters.AddWithValue("@ExpectedMinutes", If(pointDetails.ExpectedMinutes.HasValue, CObj(pointDetails.ExpectedMinutes.Value), DBNull.Value))

                    insertCmd.Parameters.AddWithValue("@ExtraTimeMinutes", If(extraMins > 0, CObj(extraMins), DBNull.Value))

                    newHistoryId = Convert.ToInt32(insertCmd.ExecuteScalar())

                End Using

                ' === THE FIX IS HERE: Correct Stamping Logic ===

                ' Step 2: "Stamp" all un-stamped attachments from THIS DEVELOPER for THIS POINT onto the new history record.

                ' This correctly isolates the developer's attachments for this cycle.

                Dim stampQuery As String = "UPDATE PointAttachments SET HistoryID = @HistoryID WHERE PointID = @PointID AND UploadedByID = @DeveloperID AND HistoryID IS NULL"

                Using stampCmd As New SqlCommand(stampQuery, conn, tran)

                    stampCmd.Parameters.AddWithValue("@HistoryID", newHistoryId)

                    stampCmd.Parameters.AddWithValue("@PointID", pointId)

                    stampCmd.Parameters.AddWithValue("@DeveloperID", developerId)

                    stampCmd.ExecuteNonQuery()

                End Using

                ' ✅ FIX: Reset developer fields after creating history to avoid double counting
                ' This prepares the point for the next cycle (if it comes back from support)
                Dim resetQuery As String = "UPDATE Points SET StartDate = NULL, DateCompleted = NULL WHERE PointID = @PointID"
                Using resetCmd As New SqlCommand(resetQuery, conn, tran)
                    resetCmd.Parameters.AddWithValue("@PointID", pointId)
                    resetCmd.ExecuteNonQuery()
                End Using

                tran.Commit()

            Catch ex As Exception

                tran.Rollback()

                ' Re-throw the exception so the calling WebMethod knows something went wrong.

                Throw

            Finally

                If conn.State = ConnectionState.Open Then

                    conn.Close()

                End If

            End Try

        End Using

    End Sub

    ' Updates the history record when tester reopens or verifies
    Public Shared Sub UpdatePointHistoryCycle(pointId As Integer, testerId As Integer, testerRemark As String, finalStatus As String)
        Using conn As New SqlConnection(ConnectionString)
            conn.Open()
            Dim tran As SqlTransaction = conn.BeginTransaction()
            Try
                ' Step 1: Is point ka sabse LATEST history record dhoondhein.
                ' Hum CycleStatus par nirbhar nahi rahenge taaki yeh hamesha kaam kare.
                Dim latestHistoryId As Object
                Dim getIdQuery As String = "SELECT TOP 1 HistoryID FROM PointHistory WHERE PointID = @PointID ORDER BY HistoryID DESC"

                Using getIdCmd As New SqlCommand(getIdQuery, conn, tran)
                    getIdCmd.Parameters.AddWithValue("@PointID", pointId)
                    latestHistoryId = getIdCmd.ExecuteScalar()
                End Using

                ' Agar history record milta hai, tabhi aage badhein
                If latestHistoryId IsNot Nothing AndAlso CInt(latestHistoryId) > 0 Then
                    Dim historyIdValue As Integer = CInt(latestHistoryId)

                    ' Step 2: 'Points' table se current point details fetch karein (jismein Tester Start/Complete Date hai)
                    Dim pointDetails As PointData = GetPointDetailsById(pointId)

                    ' Step 3: History record ko tester ki saari information se update karein
                    Dim updateQuery As String = "UPDATE PointHistory SET " &
                                  "TesterID = @TesterID, " &
                                  "TesterRemark = @TesterRemark, " &
                                  "CycleStatus = @FinalStatus, " &
                                  "FinalStatusDate = GETDATE(), " &
                                  "TesterStartDate = @TesterStartDate, " &
                                  "TesterCompleteDate = @TesterCompleteDate " &
                                  "WHERE HistoryID = @HistoryID"

                    Using updateCmd As New SqlCommand(updateQuery, conn, tran)
                        updateCmd.Parameters.AddWithValue("@HistoryID", historyIdValue)
                        updateCmd.Parameters.AddWithValue("@TesterID", testerId)
                        updateCmd.Parameters.AddWithValue("@TesterRemark", If(String.IsNullOrEmpty(testerRemark), DBNull.Value, testerRemark))
                        updateCmd.Parameters.AddWithValue("@FinalStatus", finalStatus) ' 'Verified' ya 'ReOpened'

                        ' pointDetails se start aur complete date pass karein
                        updateCmd.Parameters.AddWithValue("@TesterStartDate", If(pointDetails.TesterStartDate.HasValue, CObj(pointDetails.TesterStartDate.Value), DBNull.Value))
                        updateCmd.Parameters.AddWithValue("@TesterCompleteDate", If(pointDetails.TesterCompleteDate.HasValue, CObj(pointDetails.TesterCompleteDate.Value), DBNull.Value))

                        updateCmd.ExecuteNonQuery()
                    End Using

                    ' Step 4: Tester ke naye attachments ko is history record se "stamp" (link) karein
                    Dim stampQuery As String = "UPDATE PointAttachments SET HistoryID = @HistoryID WHERE PointID = @PointID AND UploadedByID = @TesterID AND HistoryID IS NULL"
                    Using stampCmd As New SqlCommand(stampQuery, conn, tran)
                        stampCmd.Parameters.AddWithValue("@HistoryID", historyIdValue)
                        stampCmd.Parameters.AddWithValue("@PointID", pointId)
                        stampCmd.Parameters.AddWithValue("@TesterID", testerId)
                        stampCmd.ExecuteNonQuery()
                    End Using
                Else
                    ' Agar koi history record nahi milta hai, to ek error throw karein.
                    Throw New Exception("No history cycle found for this point. The point may not have been correctly sent to QC.")
                End If

                tran.Commit()
            Catch ex As Exception
                tran.Rollback()
                ' Error ko aage pass karein taaki UI par dikhe
                Throw
            Finally
                If conn.State = ConnectionState.Open Then
                    conn.Close()
                End If
            End Try
        End Using
    End Sub



    ' Resets the point's main timing fields when it is reopened
    Public Shared Sub ResetPointForReopening(pointId As Integer)
        Using conn As New SqlConnection(ConnectionString)
            ' Reset StartDate, DateCompleted and any other relevant fields. Also update status.
            Dim query As String = "UPDATE Points SET StartDate = NULL, DateCompleted = NULL, Status = 'ReOpened' WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub

    Public Shared Function GetPointHistory(pointId As Integer) As List(Of PointHistoryData)
        Dim historyList As New List(Of PointHistoryData)()
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT HistoryID, DeveloperID, TesterID, SupportID, StartDate, CompleteDate, TesterStartDate, TesterCompleteDate, SupportStartDate, SupportCompleteDate, DeveloperRemark, TesterRemark, SupportRemark, CycleStatus, TimeSpentMinutes, ExpectedMinutes, ExtraTimeMinutes, SupportTimeSpentMinutes FROM PointHistory WHERE PointID = @PointID ORDER BY HistoryID ASC"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        historyList.Add(New PointHistoryData With {
                        .HistoryID = CInt(reader("HistoryID")),
                        .DeveloperID = If(reader("DeveloperID") Is DBNull.Value, CType(Nothing, Integer?), CInt(reader("DeveloperID"))),
                        .TesterID = If(reader("TesterID") Is DBNull.Value, CType(Nothing, Integer?), CInt(reader("TesterID"))),
                        .SupportID = If(reader("SupportID") Is DBNull.Value, CType(Nothing, Integer?), CInt(reader("SupportID"))),
                        .StartDate = If(reader("StartDate") Is DBNull.Value, Nothing, CType(reader("StartDate"), DateTime?)),
                        .CompleteDate = If(reader("CompleteDate") Is DBNull.Value, Nothing, CType(reader("CompleteDate"), DateTime?)),
                        .TesterStartDate = If(reader("TesterStartDate") Is DBNull.Value, Nothing, CType(reader("TesterStartDate"), DateTime?)),
                        .TesterCompleteDate = If(reader("TesterCompleteDate") Is DBNull.Value, Nothing, CType(reader("TesterCompleteDate"), DateTime?)),
                        .SupportStartDate = If(reader("SupportStartDate") Is DBNull.Value, Nothing, CType(reader("SupportStartDate"), DateTime?)),
                        .SupportCompleteDate = If(reader("SupportCompleteDate") Is DBNull.Value, Nothing, CType(reader("SupportCompleteDate"), DateTime?)),
                        .DeveloperRemark = If(reader("DeveloperRemark") Is DBNull.Value, "", reader("DeveloperRemark").ToString()),
                        .TesterRemark = If(reader("TesterRemark") Is DBNull.Value, "", reader("TesterRemark").ToString()),
                        .SupportRemark = If(reader("SupportRemark") Is DBNull.Value, "", reader("SupportRemark").ToString()),
                        .CycleStatus = reader("CycleStatus").ToString(),
                        .TimeSpentMinutes = If(IsDBNull(reader("TimeSpentMinutes")), Nothing, CInt(reader("TimeSpentMinutes"))),
                        .ExpectedMinutes = If(IsDBNull(reader("ExpectedMinutes")), Nothing, CInt(reader("ExpectedMinutes"))),
                        .ExtraTimeMinutes = If(IsDBNull(reader("ExtraTimeMinutes")), Nothing, CInt(reader("ExtraTimeMinutes"))),
                        .SupportTimeSpentMinutes = If(IsDBNull(reader("SupportTimeSpentMinutes")), Nothing, CInt(reader("SupportTimeSpentMinutes")))
                    })
                    End While
                End Using
            End Using
        End Using
        ' Step 2: For each history cycle, fetch its attachments and SEPARATE them.

        Using conn As New SqlConnection(ConnectionString)

            conn.Open()

            For Each cycle In historyList

                cycle.DeveloperAttachments = New List(Of AttachmentData)()
                cycle.TesterAttachments = New List(Of AttachmentData)()
                cycle.SupportAttachments = New List(Of AttachmentData)()

                Dim query As String = "SELECT AttachmentID, FileName, FilePath, UploadedByID FROM PointAttachments WHERE HistoryID = @HistoryID"

                Using cmd As New SqlCommand(query, conn)

                    cmd.Parameters.AddWithValue("@HistoryID", cycle.HistoryID)
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            Dim attachment = New AttachmentData With {
                            .AttachmentID = CInt(reader("AttachmentID")),
                            .UploadedByID = CInt(reader("UploadedByID")),
                            .FileName = reader("FileName").ToString(),
                            .FilePath = reader("FilePath").ToString()
                        }
                            If cycle.DeveloperID.HasValue AndAlso attachment.UploadedByID = cycle.DeveloperID.Value Then

                                cycle.DeveloperAttachments.Add(attachment)

                            ElseIf cycle.SupportID.HasValue AndAlso attachment.UploadedByID = cycle.SupportID.Value Then

                                cycle.SupportAttachments.Add(attachment)

                            ElseIf cycle.TesterID.HasValue AndAlso attachment.UploadedByID = cycle.TesterID.Value Then

                                cycle.TesterAttachments.Add(attachment)

                            End If

                        End While

                    End Using

                End Using

            Next

        End Using
        Return historyList
    End Function

    ' In DataAccess.vb, add this new function

    Public Shared Function UpdateDeveloperRemark(pointId As Integer, remark As String) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "UPDATE Points SET DeveloperRemark = @Remark WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                cmd.Parameters.AddWithValue("@Remark", If(String.IsNullOrEmpty(remark), DBNull.Value, remark))
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function
    Public Shared Function UpdateTesterRemark(pointId As Integer, remark As String) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "UPDATE Points SET TesterRemark = @Remark WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                cmd.Parameters.AddWithValue("@Remark", If(String.IsNullOrEmpty(remark), DBNull.Value, remark))
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    ' In DataAccess.vb, add this NEW, SIMPLE function.

    Public Shared Function MarkTestingAsComplete(pointId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            ' This query is direct and has no complex logic.
            Dim query As String = "UPDATE Points SET Status = 'Testing-Completed', TesterCompleteDate = @Now WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@Now", DateTime.Now)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    Public Shared Sub ResetTesterFieldsForNewQCCycle(pointId As Integer)
        Using conn As New SqlConnection(ConnectionString)
            ' This query specifically nullifies the tester's time fields for a fresh start.
            Dim query As String = "UPDATE Points SET TesterStartDate = NULL, TesterCompleteDate = NULL WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub
    Public Shared Function GetPointStatus(pointId As Integer) As String
        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
            Dim query As String = "SELECT Status FROM Points WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                Dim result = cmd.ExecuteScalar()
                Return If(result IsNot Nothing, result.ToString(), "")
            End Using
        End Using
    End Function

    Public Shared Sub InsertAttachment(pointId As Integer, fileName As String, filePath As String, uploadedById As Integer)

        Using conn As New SqlConnection(ConnectionString)

            Dim query As String = "INSERT INTO PointAttachments (PointID, FileName, FilePath, UploadedByID) VALUES (@PointID, @FileName, @FilePath, @UploadedByID)"

            Using cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@PointID", pointId)
                cmd.Parameters.AddWithValue("@FileName", fileName)
                cmd.Parameters.AddWithValue("@FilePath", filePath)
                cmd.Parameters.AddWithValue("@UploadedByID", uploadedById)

                conn.Open()

                cmd.ExecuteNonQuery()

            End Using

        End Using

    End Sub

    ' Add this new function inside the "Public Class DataAccess" block.

    Public Shared Function GetAttachmentsForHistoryCycle(historyId As Integer) As List(Of AttachmentData)

        Dim attachments As New List(Of AttachmentData)()

        Using conn As New SqlConnection(ConnectionString)

            Dim query As String = "SELECT AttachmentID, FileName, FilePath, UploadedByID FROM PointAttachments WHERE HistoryID = @HistoryID"

            Using cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@HistoryID", historyId)

                conn.Open()

                Using reader As SqlDataReader = cmd.ExecuteReader()

                    While reader.Read()

                        attachments.Add(New AttachmentData With {
                        .AttachmentID = CInt(reader("AttachmentID")),
                        .UploadedByID = CInt(reader("UploadedByID")),
                        .FileName = reader("FileName").ToString(),
                        .FilePath = reader("FilePath").ToString()
                    })

                    End While

                End Using

            End Using

        End Using

        Return attachments

    End Function

    Public Shared Function DeleteAttachmentById(attachmentId As Integer) As Boolean

        Using conn As New SqlConnection(ConnectionString)

            ' First, get the file path to delete the physical file

            Dim filePath As String = ""
            Dim getPathQuery As String = "SELECT FilePath FROM PointAttachments WHERE AttachmentID = @AttachmentID"
            Using cmd As New SqlCommand(getPathQuery, conn)
                cmd.Parameters.AddWithValue("@AttachmentID", attachmentId)
                conn.Open()
                Dim result = cmd.ExecuteScalar()
                If result IsNot Nothing Then
                    filePath = result.ToString()

                End If

            End Using
            ' Now, delete the record from the database

            Dim deleteQuery As String = "DELETE FROM PointAttachments WHERE AttachmentID = @AttachmentID"

            Using cmd As New SqlCommand(deleteQuery, conn)

                cmd.Parameters.AddWithValue("@AttachmentID", attachmentId)

                If conn.State = ConnectionState.Closed Then conn.Open()

                Dim rowsAffected = cmd.ExecuteNonQuery()

                ' If database record was deleted, delete the physical file

                If rowsAffected > 0 AndAlso Not String.IsNullOrEmpty(filePath) Then

                    Try

                        Dim serverPath = HttpContext.Current.Server.MapPath("~" & filePath)
                        If File.Exists(serverPath) Then
                            File.Delete(serverPath)

                        End If

                    Catch ex As Exception

                        ' Log error but don't fail the operation

                        System.Diagnostics.Trace.WriteLine("Physical file delete error: " & ex.Message)

                    End Try

                End If

                Return rowsAffected > 0

            End Using

        End Using

    End Function

    Public Shared Function GetAllAttachmentsForPoint(pointId As Integer) As List(Of AttachmentData)

        Dim attachments As New List(Of AttachmentData)()

        Using conn As New SqlConnection(ConnectionString)

            ' === THE FIX IS HERE: This query ONLY fetches attachments that are NOT part of any history cycle yet. ===

            Dim query As String = "SELECT AttachmentID, FileName, FilePath, UploadedByID FROM PointAttachments WHERE PointID = @PointID AND HistoryID IS NULL ORDER BY UploadTimestamp DESC"

            Using cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@PointID", pointId)

                conn.Open()

                Using reader As SqlDataReader = cmd.ExecuteReader()

                    While reader.Read()

                        attachments.Add(New AttachmentData With {
                          .AttachmentID = CInt(reader("AttachmentID")),
                          .UploadedByID = CInt(reader("UploadedByID")),
                            .FileName = reader("FileName").ToString(),
                            .FilePath = reader("FilePath").ToString()
                        })

                    End While

                End Using

            End Using

        End Using

        Return attachments

    End Function

    ' Location: DataAccess.vb

    ' Add this NEW function inside the DataAccess class.

    Public Shared Sub UpdatePointOrder(orderedPointIds As List(Of Integer))
        Using conn As New SqlConnection(ConnectionString)
            conn.Open()
            Dim tran As SqlTransaction = conn.BeginTransaction()

            Try
                Dim i As Integer = 1
                For Each pointId As Integer In orderedPointIds
                    Dim query As String = "UPDATE Points SET SortOrder = @SortOrder WHERE PointID = @PointID"
                    Using cmd As New SqlCommand(query, conn, tran)
                        cmd.Parameters.AddWithValue("@SortOrder", i)
                        cmd.Parameters.AddWithValue("@PointID", pointId)
                        cmd.ExecuteNonQuery()
                    End Using
                    i += 1
                Next
                tran.Commit()
            Catch ex As Exception
                tran.Rollback()
                Throw
            End Try
        End Using
    End Sub



    Public Shared Function GetUserEmailByID(userId As Integer) As String
        Dim email As String = ""
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT Email FROM Users WHERE UserID = @UserID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                Dim reader = cmd.ExecuteReader()
                If reader.Read() Then
                    email = reader("Email").ToString()
                End If
            End Using
        End Using
        Return email
    End Function

    Public Shared Function UpdateTicketStatus(ticketId As Integer, newStatus As String) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "UPDATE Tickets SET Status = @Status WHERE TicketID = @TicketID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@Status", newStatus)
                cmd.Parameters.AddWithValue("@TicketID", ticketId)
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    Public Shared Function GetUsersByRole(role As String) As List(Of UserData)
        Dim users As New List(Of UserData)()
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT UserID, FullName, Email FROM Users WHERE Role = @Role"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@Role", role)
                conn.Open()
                Using reader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim u As New UserData With {
                        .UserID = reader("UserID"),
                        .FullName = reader("FullName").ToString(),
                        .Email = reader("Email").ToString()
                    }
                        users.Add(u)
                    End While
                End Using
            End Using
        End Using
        Return users
    End Function

    Public Shared Function GetCustomerById(customerId As Integer) As DataRow
        Dim query As String = "SELECT CustomerName, ContactEmail FROM Customers WHERE CustomerID = @CustomerID"
        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@CustomerID", customerId)
                Dim dt As New DataTable()
                Using da As New SqlDataAdapter(cmd)
                    da.Fill(dt)
                End Using
                If dt.Rows.Count > 0 Then
                    Return dt.Rows(0)
                Else
                    Return Nothing
                End If
            End Using
        End Using
    End Function

    ' This new function will fetch all module names from the database.
    Public Shared Function GetModules() As List(Of Object)
        Dim modules As New List(Of Object)()
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT ModuleName FROM Modules ORDER BY ModuleName"
            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        modules.Add(New With {
                        .ModuleName = reader("ModuleName").ToString()
                    })
                    End While
                End Using
            End Using
        End Using
        Return modules
    End Function

    'this fuction tells ticket is closed or not 
    Public Shared Function IsTicketClosed(pointId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT Status FROM Points WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                Dim status As Object = cmd.ExecuteScalar()
                If status IsNot Nothing AndAlso status.ToString().ToLower() = "closed" Then
                    Return True
                End If
                Return False
            End Using
        End Using
    End Function


    ' Save tester remark
    Public Shared Function SaveTesterRemark(pointId As Integer, testerRemark As String) As Boolean
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "UPDATE PointHistory 
                                   SET TesterRemark = @TesterRemark 
                                   WHERE PointID = @PointID"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    cmd.Parameters.AddWithValue("@TesterRemark", testerRemark)
                    conn.Open()
                    Dim rows = cmd.ExecuteNonQuery()
                    Return rows > 0
                End Using
            End Using
        Catch ex As Exception
            ' Error handling (logging karna ho to yaha karo)
            Return False
        End Try
    End Function

    Public Shared Function GetFilteredPointsForGrid(status As String, fromDate As Nullable(Of DateTime), toDate As Nullable(Of DateTime), developerId As Integer, customerId As Integer) As List(Of PointData)
        Dim points As New List(Of PointData)()

        Dim query As String = "
SELECT 
   p.PointID, p.Title, p.Description, p.DateCreated, p.Category, p.Status, p.ReportedByID,
   p.Priority, p.Complexity, p.ExpectedDate, c.CustomerName,
   prod.ProductName, p.Summary AS ModuleName, 
   au.FullName AS AssignedToFullName,
   pa.FilePath AS AudioFilePath,
   p.DateCompleted,
   ru.FullName AS ReportedByFullName,
   p.ExpectedMinutes,
   p.TotalTimeSpent
FROM Points p
LEFT JOIN Users ru ON p.ReportedByID = ru.UserID
LEFT JOIN Customers c ON p.CustomerID = c.CustomerID
LEFT JOIN Products prod ON p.ProductID = prod.ProductID
LEFT JOIN Users au ON p.AssignedToID = au.UserID
LEFT JOIN PointAttachments pa 
      ON pa.PointID = p.PointID 
     AND pa.FilePath LIKE '%.webm'
WHERE 1=1 
"

        If fromDate.HasValue AndAlso toDate.HasValue Then
            query &= " AND CONVERT(DATE, p.DateCreated) BETWEEN @FromDate AND @ToDate"
        End If
        If developerId > 0 Then query &= " AND p.AssignedToID = @DeveloperID"
        If customerId > 0 Then query &= " AND p.CustomerID = @CustomerID"

        ' ▼▼▼ THIS LOGIC BLOCK IS UPDATED ▼▼▼
        Select Case status
            Case "Total"
            ' No additional filter
            Case "OpenTasks"
                query &= " AND p.Status NOT IN ('PendingQC', 'In-Testing', 'Testing-Completed', 'Closed')"
            Case "Delayed"
                query &= " AND p.TotalTimeSpent > p.ExpectedMinutes AND p.ExpectedMinutes IS NOT NULL AND p.ExpectedMinutes > 0"
            Case "Pending"
                query &= " AND p.Status = 'Queue'"
            Case "Completed"
                query &= " AND p.Status IN ('Completed', 'Closed')"
            Case Else
                query &= " AND p.Status = @Status"
        End Select
        ' ▲▲▲ END OF UPDATED LOGIC BLOCK ▲▲▲

        query &= " ORDER BY p.DateCreated DESC"

        Using conn As New SqlConnection(ConnectionString)
            Using cmd As New SqlCommand(query, conn)
                If fromDate.HasValue AndAlso toDate.HasValue Then
                    cmd.Parameters.AddWithValue("@FromDate", fromDate.Value.Date)
                    cmd.Parameters.AddWithValue("@ToDate", toDate.Value.Date)
                End If
                If developerId > 0 Then cmd.Parameters.AddWithValue("@DeveloperID", developerId)
                If customerId > 0 Then cmd.Parameters.AddWithValue("@CustomerID", customerId)

                ' ▼▼▼ THIS PARAMETER BINDING IS UPDATED ▼▼▼
                If status <> "Total" AndAlso status <> "Pending" AndAlso status <> "Completed" AndAlso status <> "Delayed" AndAlso status <> "OpenTasks" Then
                    cmd.Parameters.AddWithValue("@Status", status)
                End If
                ' ▲▲▲ END OF UPDATED BINDING ▲▲▲

                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        points.Add(New PointData With {
                       .PointID = CInt(reader("PointID")),
                       .Title = reader("Title").ToString(),
                       .Description = If(reader("Description") Is DBNull.Value, "", reader("Description").ToString()),
                       .DateCreated = CDate(reader("DateCreated")),
                       .Category = If(reader("Category") Is DBNull.Value, Nothing, reader("Category").ToString()),
                       .Status = reader("Status").ToString(),
                       .ReportedByID = CInt(reader("ReportedByID")),
                       .ReportedByFullName = reader("ReportedByFullName").ToString(),
                       .Priority = If(reader("Priority") Is DBNull.Value, "", reader("Priority").ToString()),
                       .Complexity = If(reader("Complexity") Is DBNull.Value, "", reader("Complexity").ToString()),
                       .ExpectedDate = If(reader("ExpectedDate") Is DBNull.Value, Nothing, CType(reader("ExpectedDate"), DateTime?)),
                       .DateCompleted = If(reader("DateCompleted") Is DBNull.Value, Nothing, CType(reader("DateCompleted"), DateTime?)),
                       .CustomerName = If(reader("CustomerName") Is DBNull.Value, "N/A", reader("CustomerName").ToString()),
                       .ProductName = If(reader("ProductName") Is DBNull.Value, "N/A", reader("ProductName").ToString()),
                       .Summary = If(reader("ModuleName") Is DBNull.Value, "N/A", reader("ModuleName").ToString()),
                       .AssignedToFullName = If(reader("AssignedToFullName") Is DBNull.Value, "Unassigned", reader("AssignedToFullName").ToString()),
                       .AudioFilePath = If(reader("AudioFilePath") Is DBNull.Value, Nothing, reader("AudioFilePath").ToString()),
                       .ExpectedMinutes = If(reader("ExpectedMinutes") Is DBNull.Value, Nothing, CType(reader("ExpectedMinutes"), Integer?)),
                       .TotalTimeSpent = If(reader("TotalTimeSpent") Is DBNull.Value, Nothing, CType(reader("TotalTimeSpent"), Integer?)),
                       .DelayDuration = ""
                   })
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function
    Public Shared Function ReassignTicket(ticketId As Integer, newDeveloperId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            conn.Open()
            Dim tran As SqlTransaction = conn.BeginTransaction()
            Try
                Dim updateTicketQuery As String = "UPDATE Tickets SET AssignedToID = @NewDeveloperID WHERE TicketID = @TicketID"
                Using cmd1 As New SqlCommand(updateTicketQuery, conn, tran)
                    cmd1.Parameters.AddWithValue("@NewDeveloperID", newDeveloperId)
                    cmd1.Parameters.AddWithValue("@TicketID", ticketId)
                    cmd1.ExecuteNonQuery()
                End Using

                ' Step 2: Us Ticket ke andar ke saare 'Points' ko update karein
                Dim updatePointsQuery As String = "UPDATE Points SET AssignedToID = @NewDeveloperID WHERE TicketID = @TicketID"
                Using cmd2 As New SqlCommand(updatePointsQuery, conn, tran)
                    cmd2.Parameters.AddWithValue("@NewDeveloperID", newDeveloperId)
                    cmd2.Parameters.AddWithValue("@TicketID", ticketId)
                    cmd2.ExecuteNonQuery()
                End Using

                ' Agar sab theek raha, toh changes ko save kar dein
                tran.Commit()
                Return True

            Catch ex As Exception
                ' Agar koi bhi error aaya, toh saare changes ko wapas le lein (rollback)
                tran.Rollback()
                ' Aap yahan error log bhi kar sakte hain
                Return False
            End Try
        End Using
    End Function
    Public Shared Function ReassignSinglePoint(pointId As Integer, newDeveloperId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            ' हम सिर्फ एक पॉइंट को अपडेट कर रहे हैं, इसलिए transaction की जरूरत नहीं है
            Dim query As String = "UPDATE Points SET AssignedToID = @NewDeveloperID WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@NewDeveloperID", newDeveloperId)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()
                Return rowsAffected > 0 ' अगर कोई row अपडेट हुई है तो True लौटाएं
            End Using
        End Using
    End Function


    ' Point verify karna (IsVerified = 1 update)
    ' Puraane MarkPointVerified function ko isse REPLACE karein

    ' DataAccess.vb

    ' Puraane MarkPointVerified function ko isse REPLACE karein
    Public Shared Function MarkPointVerified(pointId As Integer) As String
        Using conn As New SqlConnection(ConnectionString)
            conn.Open()

            ' Step 1: Check if already verified
            Dim isVerified As Object
            Using checkCmd As New SqlCommand("SELECT IsVerified FROM Points WHERE PointID = @PointID", conn)
                checkCmd.Parameters.AddWithValue("@PointID", pointId)
                isVerified = checkCmd.ExecuteScalar()
            End Using

            If isVerified IsNot Nothing AndAlso Convert.ToBoolean(isVerified) = True Then
                Return "AlreadyVerified"
            End If

            ' Step 2: Update as verified, set VerificationStatus, and record the verification date
            ' YEH LINE BADLI GAYI HAI: DateTicketVerified = GETDATE() joda gaya hai
            Dim updateQuery As String = "UPDATE Points SET IsVerified = 1, VerificationStatus = 1, DateTicketVerified = GETDATE() WHERE PointID = @PointID"

            Using updateCmd As New SqlCommand(updateQuery, conn)
                updateCmd.Parameters.AddWithValue("@PointID", pointId)
                Dim rows As Integer = updateCmd.ExecuteNonQuery()
                If rows > 0 Then
                    Return "Updated"
                Else
                    Return "Failed"
                End If
            End Using
        End Using
    End Function



    ' ✅✅✅ PURAANE GetAllPointsForVerification FUNCTION KO IS NAYE, CORRECTED VERSION SE REPLACE KAREIN ✅✅✅

    Public Shared Function GetAllPointsForVerification() As List(Of Object)
        Dim points As New List(Of Object)()

        Using conn As New SqlConnection(ConnectionString)
            ' Step 1: Query se Convert(nvarchar...) hata dein taaki original DateTime object mile
            Dim query As String = "
        SELECT p.PointID, p.Title, p.Description, p.Summary, p.Category,
               p.Priority, p.Complexity, p.Status, p.DateCreated,
               p.ExpectedDate, p.ReportedByID, ru.FullName AS ReportedByFullName,c.CustomerName, pr.ProductName, p.IsVerified,
               p.VerificationStatus,
                  (
           SELECT TOP 1 FilePath 
           FROM PointAttachments pa 
           WHERE pa.PointID = p.PointID 
           AND pa.FileName LIKE '%.webm'
           ORDER BY pa.AttachmentID DESC
          ) AS AudioFilePath
        FROM Points p
        JOIN Customers c ON p.CustomerID = c.CustomerID
        JOIN Products pr ON p.ProductID = pr.ProductID
        LEFT JOIN Users ru ON ru.UserID = p.ReportedByID 
        WHERE p.IsVerified = 0 
        ORDER BY p.VerificationStatus DESC, p.DateCreated DESC"

            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        ' Step 2: Yahan par Timezone Conversion ka logic add karein
                        Dim finalDateCreated As Nullable(Of DateTime) = Nothing
                        Dim dateCreatedUtcAsObject = reader("DateCreated")

                        If Not IsDBNull(dateCreatedUtcAsObject) Then
                            Dim dateCreatedUtc As DateTime = CDate(dateCreatedUtcAsObject)
                            Dim indianZone As TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time")
                            finalDateCreated = TimeZoneInfo.ConvertTimeFromUtc(dateCreatedUtc, indianZone)
                        End If
                        ' --- CONVERSION LOGIC KHATAM HUA ---

                        ' Step 3: Naye 'finalDateCreated' variable ko use karein
                        points.Add(New With {
                        .PointID = reader("PointID"),
                        .Title = reader("Title"),
                        .Description = reader("Description"),
                        .Summary = reader("Summary"),
                        .Category = reader("Category"),
                        .Priority = reader("Priority"),
                        .Complexity = reader("Complexity"),
                        .Status = reader("Status"),
                        .ReportedByID = CInt(reader("ReportedByID")),
                        .ReportedByFullName = reader("ReportedByFullName").ToString(),
                        .DateCreated = finalDateCreated, ' ✅ Yahan change hua hai
                        .ExpectedDate = If(reader("ExpectedDate") Is DBNull.Value, Nothing, CDate(reader("ExpectedDate"))),
                        .CustomerName = reader("CustomerName"),
                        .ProductName = reader("ProductName"),
                        .IsVerified = reader("IsVerified"),
                        .AudioFilePath = If(reader("AudioFilePath") Is DBNull.Value, Nothing, reader("AudioFilePath").ToString()),
                        .VerificationStatus = CInt(reader("VerificationStatus"))
                    })
                    End While
                End Using
            End Using
        End Using

        Return points
    End Function
    Public Shared Function GetUserPermissions(userId As Integer) As List(Of String)

        Dim permissions As New List(Of String)()

        ' Using block ensures the connection is always closed, even if an error occurs

        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)

            Dim query As String = "SELECT PageName FROM UserPagePermissions WHERE UserID = @UserID"

            Using cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@UserID", userId)

                conn.Open()

                Using reader As SqlDataReader = cmd.ExecuteReader()

                    While reader.Read()

                        permissions.Add(reader("PageName").ToString())

                    End While

                End Using

            End Using

        End Using


        Return permissions

    End Function

    Public Shared Function GetAssignableUsers() As List(Of UserData)
        Dim users As New List(Of UserData)()
        Using conn As New SqlConnection(ConnectionString)
            ' Yeh query ab Developer aur Admin, dono roles ke users ko layegi
            Dim query As String = "SELECT UserID, FullName, Role FROM Users WHERE Role IN ('Developer', 'Admin') ORDER BY FullName"

            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        users.Add(New UserData With {
                            .UserID = CInt(reader("UserID")),
                            .FullName = reader("FullName").ToString(),
                            .Role = reader("Role").ToString()
                        })
                    End While
                End Using
            End Using
        End Using
        Return users
    End Function





    Public Shared Function DoesUserHaveAssignedTickets(userId As Integer) As Boolean
        ' Hum COUNT(*) ka use karenge, jo bahut fast hota hai
        Using conn As New SqlConnection(ConnectionString)
            ' Yeh query check karegi ki is user ko koi bhi "Open" ya "In Progress" etc. ticket assigned hai ya nahi
            Dim query As String = "
         SELECT COUNT(*) 
         FROM Tickets 
         WHERE AssignedToID = @UserID AND Status <> 'Closed'"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                ' ExecuteScalar ek single value (count) return karta hai
                Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())

                ' Agar count 0 se zyada hai, toh True return karein
                Return count > 0
            End Using
        End Using
    End Function

    Public Shared Function AssignAndVerifyPoint(pointId As Integer, developerId As Integer) As Boolean
        ' Hum ek hi query mein saare updates karenge taaki performance fast rahe
        ' Hum check karenge ki point abhi bhi 'Queue' mein hai ya nahi, taaki double assignment na ho
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "
        UPDATE Points 
        SET 
            AssignedToID = @DeveloperID, 
            Status = 'Assigned', 
            IsVerified = 1 
        WHERE 
            PointID = @PointID AND Status = 'Queue'"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@DeveloperID", developerId)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                ' ExecuteNonQuery() return karega ki kitni rows update hui.
                ' Agar 1 row update hui, iska matlab success.
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function



    ' Add this new function inside the "Public Class DataAccess" block.

    Public Shared Function CreateTicketAndAssignSinglePoint(pointId As Integer, developerId As Integer, adminId As Integer, expectedDate As DateTime) As Boolean
        ' Ek unique TicketNo banayein
        Dim ticketNo As String = Now.ToString("yyyyMMddHHmmss")
        Dim newTicketId As Integer = 0

        ' Transaction ka use karein taaki dono tables ek saath update ho
        Using conn As New SqlConnection(ConnectionString)
            conn.Open()
            Dim tran As SqlTransaction = conn.BeginTransaction()
            Try
                ' Step 1: 'Tickets' table mein ek naya Assignment record banayein
                Dim insertTicketQuery As String = "
                INSERT INTO Tickets (TicketNo, AssignedToID, CreatedByID, Department, DateCreated, Status) 
                OUTPUT INSERTED.TicketID 
                VALUES (@TicketNo, @AssignedToID, @CreatedByID, 'Development', GETDATE(), 'Open')"

                Using cmd1 As New SqlCommand(insertTicketQuery, conn, tran)
                    cmd1.Parameters.AddWithValue("@TicketNo", ticketNo)
                    cmd1.Parameters.AddWithValue("@AssignedToID", developerId)
                    cmd1.Parameters.AddWithValue("@CreatedByID", adminId)
                    newTicketId = Convert.ToInt32(cmd1.ExecuteScalar())
                End Using

                ' Agar Ticket nahi bana, toh error throw karein
                If newTicketId <= 0 Then Throw New Exception("Ticket (Assignment) creation failed.")

                ' Step 2: 'Points' table ko update karke use is naye Ticket se link karein
                Dim updatePointQuery As String = "
                UPDATE Points 
                SET 
                    TicketID = @TicketID, 
                    AssignedToID = @AssignedToID, 
                    Status = 'Assigned', 
                    ExpectedDate = @ExpectedDate,
                    IsVerified = 1 
                WHERE 
                    PointID = @PointID AND Status = 'Queue'"

                Using cmd2 As New SqlCommand(updatePointQuery, conn, tran)
                    cmd2.Parameters.AddWithValue("@TicketID", newTicketId)
                    cmd2.Parameters.AddWithValue("@AssignedToID", developerId)
                    cmd2.Parameters.AddWithValue("@ExpectedDate", expectedDate)
                    cmd2.Parameters.AddWithValue("@PointID", pointId)

                    ' Check karein ki update successful hua ya nahi
                    If cmd2.ExecuteNonQuery() = 0 Then
                        Throw New Exception("Point was already assigned or its status was changed by someone else.")
                    End If
                End Using

                ' Agar sab theek raha, toh changes ko save kar dein
                tran.Commit()
                Return True

            Catch ex As Exception
                ' Agar koi bhi error aaya, toh saare changes ko wapas le lein (rollback)
                tran.Rollback()
                ' Aap yahan error log bhi kar sakte hain (ex.Message)
                Return False
            End Try
        End Using
    End Function

#Region "Time Tracking Methods"

    ' Insert Time Log Entry
    Public Shared Function InsertTimeLog(pointId As Integer, action As String, performedById As Integer, Optional remarks As String = Nothing) As Boolean
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "INSERT INTO PointTimeLog (PointID, Action, ActionTime, PerformedByID, Remarks) " &
                                      "VALUES (@PointID, @Action, GETDATE(), @PerformedByID, @Remarks)"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    cmd.Parameters.AddWithValue("@Action", action)
                    cmd.Parameters.AddWithValue("@PerformedByID", performedById)
                    cmd.Parameters.AddWithValue("@Remarks", If(String.IsNullOrEmpty(remarks), DBNull.Value, remarks))

                    conn.Open()
                    Return cmd.ExecuteNonQuery() > 0
                End Using
            End Using
        Catch ex As Exception
            Return False
        End Try
    End Function

    ' Get Time Logs for a Point
    Public Shared Function GetTimeLogsForPoint(pointId As Integer) As List(Of PointTimeLogData)
        Dim logs As New List(Of PointTimeLogData)()
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "SELECT LogID, PointID, Action, ActionTime, PerformedByID, Remarks " &
                                      "FROM PointTimeLog WHERE PointID = @PointID ORDER BY ActionTime"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            logs.Add(New PointTimeLogData With {
                                .LogID = CInt(reader("LogID")),
                                .PointID = CInt(reader("PointID")),
                                .Action = reader("Action").ToString(),
                                .ActionTime = CDate(reader("ActionTime")),
                                .PerformedByID = If(IsDBNull(reader("PerformedByID")), Nothing, CInt(reader("PerformedByID"))),
                                .Remarks = If(IsDBNull(reader("Remarks")), Nothing, reader("Remarks").ToString())
                            })
                        End While
                    End Using
                End Using
            End Using
        Catch ex As Exception
        End Try
        Return logs
    End Function

    ' Start Point Timer
    Public Shared Function StartPointTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                Dim checkQuery As String = "SELECT Status, StartDate FROM Points WHERE PointID = @PointID"
                Using checkCmd As New SqlCommand(checkQuery, conn)
                    checkCmd.Parameters.AddWithValue("@PointID", pointId)
                    Using reader As SqlDataReader = checkCmd.ExecuteReader()
                        If reader.Read() Then
                            If Not IsDBNull(reader("StartDate")) Then
                                Return New With {.success = False, .message = "Timer already started"}
                            End If
                        End If
                    End Using
                End Using

                Dim updateQuery As String = "UPDATE Points SET StartDate = GETDATE(), Status = 'In Progress', LastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                InsertTimeLog(pointId, "Start", userId, "Timer started")

                Return New With {.success = True, .message = "Timer started successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Pause Point Timer
    ' Pause Point Timer (MODIFIED)
    Public Shared Function PausePointTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' MODIFIED: Status ko 'Paused' karne ke bajaye IsDeveloperPaused ko 1 (true) set karein
                Dim updateQuery As String = "UPDATE Points SET IsDeveloperPaused = 1, LastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                InsertTimeLog(pointId, "Pause", userId, "Timer paused")
                CalculateAndUpdateTotalTime(pointId) ' Time calculation waise hi chalti rahegi

                Return New With {.success = True, .message = "Timer paused successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function
    ' Resume Point Timer
    ' Resume Point Timer (MODIFIED)
    Public Shared Function ResumePointTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' MODIFIED: Status ko 'InProgress' karne ke bajaye IsDeveloperPaused ko 0 (false) set karein
                ' Status already 'InProgress' hi rahega.
                Dim updateQuery As String = "UPDATE Points SET IsDeveloperPaused = 0, LastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                InsertTimeLog(pointId, "Resume", userId, "Timer resumed")

                Return New With {.success = True, .message = "Timer resumed successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function
    ' Complete Point Timer
    Public Shared Function CompletePointTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                ' ✅ FIX: Check if currently paused, if yes then auto-resume first
                Dim isPausedQuery As String = "SELECT IsDeveloperPaused FROM Points WHERE PointID = @PointID"
                Dim isPaused As Boolean = False
                Using checkCmd As New SqlCommand(isPausedQuery, conn)
                    checkCmd.Parameters.AddWithValue("@PointID", pointId)
                    Dim pauseResult = checkCmd.ExecuteScalar()
                    If pauseResult IsNot Nothing AndAlso Not IsDBNull(pauseResult) Then
                        isPaused = Convert.ToBoolean(pauseResult)
                    End If
                End Using

                ' ✅ If paused, insert Resume log entry first
                If isPaused Then
                    InsertTimeLog(pointId, "Resume", userId, "Auto-resumed before completion")
                End If

                Dim expectedMinutes As Integer = 0
                Dim getExpectedQuery As String = "SELECT ExpectedMinutes FROM Points WHERE PointID = @PointID"
                Using getCmd As New SqlCommand(getExpectedQuery, conn)
                    getCmd.Parameters.AddWithValue("@PointID", pointId)
                    Dim result = getCmd.ExecuteScalar()
                    If result IsNot Nothing AndAlso Not IsDBNull(result) Then
                        expectedMinutes = Convert.ToInt32(result)
                    End If
                End Using

                ' ✅ FIX: Also reset IsDeveloperPaused flag to 0
                Dim updateQuery As String = "UPDATE Points SET DateCompleted = GETDATE(), Status = 'DevCompleted', IsDeveloperPaused = 0, LastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                InsertTimeLog(pointId, "Complete", userId, "Timer completed")

                Dim totalMinutes As Integer = CalculateAndUpdateTotalTime(pointId)

                Dim extraTime As Integer = 0
                If expectedMinutes > 0 AndAlso totalMinutes > expectedMinutes Then
                    extraTime = totalMinutes - expectedMinutes
                    InsertTimeLog(pointId, "ExtraTime", userId, String.Format("Extra time taken: {0} minutes", extraTime))
                End If

                Return New With {
                    .success = True,
                    .message = "Timer completed successfully",
                    .totalMinutes = totalMinutes,
                    .expectedMinutes = expectedMinutes,
                    .extraMinutes = extraTime
                }
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Calculate and Update Total Time
    Public Shared Function CalculateAndUpdateTotalTime(pointId As Integer) As Integer
        Dim totalMinutes As Integer = 0
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                Using cmd As New SqlCommand("sp_CalculatePointTotalTime", conn)
                    cmd.CommandType = CommandType.StoredProcedure
                    cmd.Parameters.AddWithValue("@PointID", pointId)

                    Dim result = cmd.ExecuteScalar()
                    If result IsNot Nothing AndAlso Not IsDBNull(result) Then
                        totalMinutes = Convert.ToInt32(result)
                    End If
                End Using
            End Using
        Catch ex As Exception
        End Try
        Return totalMinutes
    End Function

    ' Get Point Time Summary
    Public Shared Function GetPointTimeSummary(pointId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "SELECT ExpectedMinutes, TotalTimeSpent, PauseTimeMinutes, Status, StartDate, DateCompleted, LastActionTime " &
                                      "FROM Points WHERE PointID = @PointID"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        If reader.Read() Then
                            Dim expectedMins As Integer = If(IsDBNull(reader("ExpectedMinutes")), 0, CInt(reader("ExpectedMinutes")))
                            Dim totalMins As Integer = If(IsDBNull(reader("TotalTimeSpent")), 0, CInt(reader("TotalTimeSpent")))
                            Dim extraMins As Integer = If(totalMins > expectedMins, totalMins - expectedMins, 0)

                            Return New With {
                                .expectedMinutes = expectedMins,
                                .totalTimeSpent = totalMins,
                                .extraTime = extraMins,
                                .pauseTimeMinutes = If(IsDBNull(reader("PauseTimeMinutes")), 0, CInt(reader("PauseTimeMinutes"))),
                                .status = reader("Status").ToString(),
                                .startDate = If(IsDBNull(reader("StartDate")), Nothing, CDate(reader("StartDate"))),
                                .dateCompleted = If(IsDBNull(reader("DateCompleted")), Nothing, CDate(reader("DateCompleted"))),
                                .lastActionTime = If(IsDBNull(reader("LastActionTime")), Nothing, CDate(reader("LastActionTime")))
                            }
                        End If
                    End Using
                End Using
            End Using
        Catch ex As Exception
            Return Nothing
        End Try
        Return Nothing
    End Function

    ' Update Expected Minutes
    Public Shared Function UpdateExpectedMinutes(pointId As Integer, expectedMinutes As Integer) As Boolean
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "UPDATE Points SET ExpectedMinutes = @ExpectedMinutes WHERE PointID = @PointID"

                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@ExpectedMinutes", expectedMinutes)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    Return cmd.ExecuteNonQuery() > 0
                End Using
            End Using
        Catch ex As Exception
            Return False
        End Try
    End Function


    Public Shared Function GetPointsForSupportDashboard(ByVal reportedById As Integer) As List(Of PointData)
        Dim points As New List(Of PointData)()
        Using conn As New SqlConnection(ConnectionString)

            Dim query As String = "SELECT p.PointID, p.Title, p.Priority, p.Status, p.DateSentToQC, p.Description, " &
                          "c.CustomerID, c.CustomerName, " &
                          "ru.FullName AS ReportedByFullName, " &
                          "au.FullName AS AssignedToFullName, " &
                          "prod.ProductName, " &
                          "p.Summary, p.Category, p.Complexity, p.DateCreated, p.ExpectedDate, " &
                          "p.SupportStartDate, p.SupportCompleteDate, p.SupportRemark, " &
                          "p.ExpectedMinutes, p.SupportTimeSpent, p.SupportPauseTime, " &
                          "pa.FilePath AS AudioFilePath " &
                          "FROM Points p " &
                          "JOIN Customers c ON p.CustomerID = c.CustomerID " &
                          "JOIN Products prod ON p.ProductID = prod.ProductID " &
                          "LEFT JOIN Users ru ON p.ReportedByID = ru.UserID " &
                          "LEFT JOIN Users au ON p.AssignedToID = au.UserID " &
                          "LEFT JOIN PointAttachments pa ON pa.PointID = p.PointID AND pa.FilePath LIKE '%.webm' " &
                          "WHERE p.Status = 'PendingSupport' AND p.ReportedByID = @ReportedByID " &
                          "ORDER BY p.DateSentToQC ASC"

            Using cmd As New SqlCommand(query, conn)

                cmd.Parameters.AddWithValue("@ReportedByID", reportedById)

                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        Dim tempPoint As New PointData()
                        tempPoint.PointID = CInt(reader("PointID"))
                        tempPoint.Title = If(IsDBNull(reader("Title")), "", reader("Title").ToString())
                        tempPoint.Priority = If(IsDBNull(reader("Priority")), "Medium", reader("Priority").ToString())
                        tempPoint.Status = If(IsDBNull(reader("Status")), "PendingSupport", reader("Status").ToString())
                        tempPoint.DateSentToQC = If(IsDBNull(reader("DateSentToQC")), Nothing, CDate(reader("DateSentToQC")))
                        tempPoint.ReportedByFullName = If(IsDBNull(reader("ReportedByFullName")), "N/A", reader("ReportedByFullName").ToString())
                        tempPoint.AssignedToFullName = If(IsDBNull(reader("AssignedToFullName")), "N/A", reader("AssignedToFullName").ToString())
                        tempPoint.CustomerID = CInt(reader("CustomerID"))
                        tempPoint.CustomerName = If(IsDBNull(reader("CustomerName")), "", reader("CustomerName").ToString())
                        tempPoint.ProductName = If(IsDBNull(reader("ProductName")), "", reader("ProductName").ToString())
                        tempPoint.Summary = If(IsDBNull(reader("Summary")), "", reader("Summary").ToString())
                        tempPoint.Description = If(IsDBNull(reader("Description")), "", reader("Description").ToString())
                        tempPoint.Category = If(IsDBNull(reader("Category")), "", reader("Category").ToString())
                        tempPoint.Complexity = If(IsDBNull(reader("Complexity")), "", reader("Complexity").ToString())
                        tempPoint.DateCreated = If(IsDBNull(reader("DateCreated")), Nothing, CDate(reader("DateCreated")))
                        tempPoint.ExpectedDate = If(IsDBNull(reader("ExpectedDate")), Nothing, CDate(reader("ExpectedDate")))
                        tempPoint.ExpectedMinutes = If(IsDBNull(reader("ExpectedMinutes")), Nothing, CInt(reader("ExpectedMinutes")))
                        tempPoint.SupportTimeSpent = If(IsDBNull(reader("SupportTimeSpent")), Nothing, CInt(reader("SupportTimeSpent")))
                        tempPoint.SupportPauseTime = If(IsDBNull(reader("SupportPauseTime")), Nothing, CInt(reader("SupportPauseTime")))
                        tempPoint.AudioFilePath = If(IsDBNull(reader("AudioFilePath")), "", reader("AudioFilePath").ToString())
                        points.Add(tempPoint)
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function

    ' Start support timer
    Public Shared Function StartSupportTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                Dim checkQuery As String = "SELECT Status, SupportStartDate FROM Points WHERE PointID = @PointID"
                Using checkCmd As New SqlCommand(checkQuery, conn)
                    checkCmd.Parameters.AddWithValue("@PointID", pointId)
                    Using reader As SqlDataReader = checkCmd.ExecuteReader()
                        If reader.Read() Then
                            If Not IsDBNull(reader("SupportStartDate")) Then
                                Return New With {.success = False, .message = "Support timer already started"}
                            End If
                        End If
                    End Using
                End Using

                Dim updateQuery As String = "UPDATE Points SET SupportStartDate = GETDATE(), SupportLastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                InsertTimeLog(pointId, "Support-Start", userId, "Support timer started")

                Return New With {.success = True, .message = "Support timer started successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Complete support timer
    Public Shared Function CompleteSupportTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                Dim updateQuery As String = "UPDATE Points SET SupportCompleteDate = GETDATE(), SupportLastActionTime = GETDATE() WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                InsertTimeLog(pointId, "Support-Complete", userId, "Support work completed")
                CalculateAndUpdateSupportTime(pointId)

                Return New With {.success = True, .message = "Support work completed successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Pause support timer
    Public Shared Function PauseSupportTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                Dim updateQuery As String = "UPDATE Points SET SupportLastActionTime = GETDATE(), IsSupportPaused = 1 WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                InsertTimeLog(pointId, "Support-Pause", userId, "Support timer paused")
                CalculateAndUpdateSupportTime(pointId)

                Return New With {.success = True, .message = "Support timer paused successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Resume support timer
    Public Shared Function ResumeSupportTimer(pointId As Integer, userId As Integer) As Object
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                Dim updateQuery As String = "UPDATE Points SET SupportLastActionTime = GETDATE(), IsSupportPaused = 0 WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using

                InsertTimeLog(pointId, "Support-Resume", userId, "Support timer resumed")

                Return New With {.success = True, .message = "Support timer resumed successfully"}
            End Using
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Calculate and update support time
    Private Shared Sub CalculateAndUpdateSupportTime(pointId As Integer)
        Try
            Using conn As New SqlConnection(ConnectionString)
                conn.Open()

                Dim totalMinutes As Integer = 0
                Dim pauseMinutes As Integer = 0
                Dim startTime As DateTime? = Nothing
                Dim pauseStartTime As DateTime? = Nothing

                Dim query As String = "SELECT Action, ActionTime FROM PointTimeLog WHERE PointID = @PointID AND Action LIKE 'Support-%' ORDER BY ActionTime"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    Using reader As SqlDataReader = cmd.ExecuteReader()
                        While reader.Read()
                            Dim action As String = reader("Action").ToString()
                            Dim actionTime As DateTime = CDate(reader("ActionTime"))

                            If action = "Support-Start" OrElse action = "Support-Resume" Then
                                startTime = actionTime
                                If pauseStartTime.HasValue Then
                                    pauseMinutes += DateDiff(DateInterval.Minute, pauseStartTime.Value, actionTime)
                                    pauseStartTime = Nothing
                                End If
                            ElseIf action = "Support-Pause" AndAlso startTime.HasValue Then
                                totalMinutes += DateDiff(DateInterval.Minute, startTime.Value, actionTime)
                                pauseStartTime = actionTime
                                startTime = Nothing
                            ElseIf action = "Support-Complete" AndAlso startTime.HasValue Then
                                totalMinutes += DateDiff(DateInterval.Minute, startTime.Value, actionTime)
                                startTime = Nothing
                            End If
                        End While
                    End Using
                End Using

                Dim updateQuery As String = "UPDATE Points SET SupportTimeSpent = @TotalMinutes, SupportPauseTime = @PauseMinutes WHERE PointID = @PointID"
                Using updateCmd As New SqlCommand(updateQuery, conn)
                    updateCmd.Parameters.AddWithValue("@TotalMinutes", totalMinutes)
                    updateCmd.Parameters.AddWithValue("@PauseMinutes", pauseMinutes)
                    updateCmd.Parameters.AddWithValue("@PointID", pointId)
                    updateCmd.ExecuteNonQuery()
                End Using
            End Using
        Catch ex As Exception
            ' Log error but don't throw
        End Try
    End Sub

    ' Update support remark
    Public Shared Function UpdateSupportRemark(pointId As Integer, remark As String) As Boolean
        Try
            Using conn As New SqlConnection(ConnectionString)
                Dim query As String = "UPDATE Points SET SupportRemark = @Remark WHERE PointID = @PointID"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@Remark", If(String.IsNullOrEmpty(remark), DBNull.Value, remark))
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    Return cmd.ExecuteNonQuery() > 0
                End Using
            End Using
        Catch ex As Exception
            Return False
        End Try
    End Function



    Public Shared Sub UpdateSupportHistoryCycle(pointId As Integer, supportId As Integer, supportRemark As String, cycleStatus As String)
        Using conn As New SqlConnection(ConnectionString)
            conn.Open()
            Dim tran As SqlTransaction = conn.BeginTransaction()
            Try
                ' Step 1: Is point ka latest history record dhoondhein (jo developer ne banaya tha)
                Dim historyId As Integer = -1
                Using getCmd As New SqlCommand("SELECT TOP 1 HistoryID FROM PointHistory WHERE PointID = @PointID ORDER BY HistoryID DESC", conn, tran)
                    getCmd.Parameters.AddWithValue("@PointID", pointId)
                    Dim result = getCmd.ExecuteScalar()
                    If result IsNot Nothing AndAlso Not IsDBNull(result) Then
                        historyId = CInt(result)
                    End If
                End Using

                If historyId > 0 Then

                    ' ===> YEH HAI ASLI FIX: Hum Points table se data fetch kar rahe hain <===

                    ' Step 2: Points table se support ki saari current details fetch karein
                    ' GetPointDetailsById function Points table se hi data laata hai.
                    Dim pointDetails As PointData = GetPointDetailsById(pointId)

                    ' Step 3: History record ko support ki saari details se update karein
                    Dim updateQuery As String = "
                UPDATE PointHistory SET 
                    SupportID = @SupportID, 
                    SupportStartDate = @SupportStartDate, 
                    SupportCompleteDate = @SupportCompleteDate, 
                    SupportTimeSpentMinutes = @SupportTimeSpent, 
                    SupportPauseMinutes = @SupportPauseTime, 
                    SupportRemark = @SupportRemark, 
                    CycleStatus = @CycleStatus, 
                    SupportSentToQCDate = GETDATE()
                WHERE HistoryID = @HistoryID"

                    Using updateCmd As New SqlCommand(updateQuery, conn, tran)
                        updateCmd.Parameters.AddWithValue("@HistoryID", historyId)
                        updateCmd.Parameters.AddWithValue("@SupportID", supportId)

                        ' Yahan hum 'pointDetails' object se values le rahe hain, jo Points table se aayi hain
                        updateCmd.Parameters.AddWithValue("@SupportStartDate", If(pointDetails.SupportStartDate.HasValue, CObj(pointDetails.SupportStartDate.Value), DBNull.Value))
                        updateCmd.Parameters.AddWithValue("@SupportCompleteDate", If(pointDetails.SupportCompleteDate.HasValue, CObj(pointDetails.SupportCompleteDate.Value), DBNull.Value))
                        updateCmd.Parameters.AddWithValue("@SupportTimeSpent", If(pointDetails.SupportTimeSpent.HasValue, CObj(pointDetails.SupportTimeSpent.Value), DBNull.Value))
                        updateCmd.Parameters.AddWithValue("@SupportPauseTime", If(pointDetails.SupportPauseTime.HasValue, CObj(pointDetails.SupportPauseTime.Value), DBNull.Value))

                        updateCmd.Parameters.AddWithValue("@SupportRemark", If(String.IsNullOrEmpty(supportRemark), DBNull.Value, supportRemark))
                        updateCmd.Parameters.AddWithValue("@CycleStatus", cycleStatus) ' 'SentToQC' ya 'ReOpened'
                        updateCmd.ExecuteNonQuery()
                    End Using

                    ' Step 4: Support ke attachments ko stamp karein
                    Dim stampQuery As String = "UPDATE PointAttachments SET HistoryID = @HistoryID WHERE PointID = @PointID AND UploadedByID = @SupportID AND HistoryID IS NULL"
                    Using stampCmd As New SqlCommand(stampQuery, conn, tran)
                        stampCmd.Parameters.AddWithValue("@HistoryID", historyId)
                        stampCmd.Parameters.AddWithValue("@PointID", pointId)
                        stampCmd.Parameters.AddWithValue("@SupportID", supportId)
                        stampCmd.ExecuteNonQuery()
                    End Using
                End If

                tran.Commit()
            Catch ex As Exception
                tran.Rollback()
                Throw
            End Try
        End Using
    End Sub
    Public Shared Function GetPointsForManageByRole(userId As Integer, userRole As String) As List(Of PointData)
        Dim points As New List(Of PointData)()
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "
    SELECT p.PointID, p.Title, p.DateCreated,
           p.Status, p.Summary, p.Description, p.CustomerID, p.ProductID,
           p.ReportedByID, p.AssignedToID, p.TicketID, p.StartDate,
           p.DateCompleted, p.DateClosed, p.Priority, p.Category,
           p.Complexity, p.ExpectedDate,
           c.CustomerName, prod.ProductName,
           ru.FullName AS ReportedByFullName,
           au.FullName AS AssignedToFullName,
           (
               SELECT TOP 1 FilePath
               FROM PointAttachments pa
               WHERE pa.PointID = p.PointID
                 AND pa.FileName LIKE '%.webm'
               ORDER BY pa.AttachmentID DESC
           ) AS AudioFilePath
    FROM Points p
    JOIN Customers c ON p.CustomerID = c.CustomerID
    JOIN Products prod ON p.ProductID = prod.ProductID
    LEFT JOIN Users ru ON p.ReportedByID = ru.UserID
    LEFT JOIN Users au ON p.AssignedToID = au.UserID"

            If userRole.Equals("Support", StringComparison.OrdinalIgnoreCase) Then
                query &= " WHERE p.ReportedByID = @UserID"
            End If

            query &= " ORDER BY p.DateCreated DESC"

            Using cmd As New SqlCommand(query, conn)
                If userRole.Equals("Support", StringComparison.OrdinalIgnoreCase) Then
                    cmd.Parameters.AddWithValue("@UserID", userId)
                End If

                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        ' --- YEH HAI TIMEZONE CONVERSION KA LOGIC ---
                        Dim finalDateCreated As Nullable(Of DateTime) = Nothing
                        Dim dateCreatedUtcAsObject = reader("DateCreated")

                        ' Pehle check karein ki database se date NULL toh nahi aa rahi
                        If Not IsDBNull(dateCreatedUtcAsObject) Then
                            ' 1. Database se UTC date nikalein
                            Dim dateCreatedUtc As DateTime = CDate(dateCreatedUtcAsObject)

                            ' 2. Use Indian Standard Time (IST) mein convert karein
                            Dim indianZone As TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time")
                            finalDateCreated = TimeZoneInfo.ConvertTimeFromUtc(dateCreatedUtc, indianZone)
                        End If
                        ' --- CONVERSION LOGIC KHATAM HUA ---

                        Dim point As New PointData With {
                        .PointID = CInt(reader("PointID")),
                        .Title = reader("Title").ToString(),
                        .DateCreated = finalDateCreated,
                        .Status = reader("Status").ToString(),
                        .Summary = If(IsDBNull(reader("Summary")), "", reader("Summary").ToString()),
                        .Description = reader("Description").ToString(),
                        .CustomerID = CInt(reader("CustomerID")),
                        .ProductID = CInt(reader("ProductID")),
                        .ReportedByID = If(IsDBNull(reader("ReportedByID")), Nothing, CInt(reader("ReportedByID"))),
                        .AssignedToID = If(IsDBNull(reader("AssignedToID")), Nothing, CInt(reader("AssignedToID"))),
                        .TicketID = If(IsDBNull(reader("TicketID")), Nothing, CInt(reader("TicketID"))),
                        .StartDate = If(IsDBNull(reader("StartDate")), Nothing, CDate(reader("StartDate"))),
                        .DateCompleted = If(IsDBNull(reader("DateCompleted")), Nothing, CDate(reader("DateCompleted"))),
                        .DateClosed = If(IsDBNull(reader("DateClosed")), Nothing, CDate(reader("DateClosed"))),
                        .Priority = reader("Priority").ToString(),
                        .Category = reader("Category").ToString(),
                        .Complexity = If(IsDBNull(reader("Complexity")), "", reader("Complexity").ToString()),
                        .ExpectedDate = If(IsDBNull(reader("ExpectedDate")), Nothing, CDate(reader("ExpectedDate"))),
                        .CustomerName = reader("CustomerName").ToString(),
                        .ProductName = reader("ProductName").ToString(),
                        .ReportedByFullName = If(IsDBNull(reader("ReportedByFullName")), "", reader("ReportedByFullName").ToString()),
                        .AssignedToFullName = If(IsDBNull(reader("AssignedToFullName")), "", reader("AssignedToFullName").ToString()),
                        .AudioFilePath = If(IsDBNull(reader("AudioFilePath")), "", reader("AudioFilePath").ToString())
                    }
                        points.Add(point)
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function

#End Region

    Public Shared Function ReopenPointFromSupport(pointId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            ' Hum ek hi query mein saare fields ko reset karenge taaki performance acchi rahe.
            Dim query As String = "
        UPDATE Points 
        SET 
            Status = 'ReOpened', 
            
            -- Developer ke fields reset karo
            StartDate = NULL, 
            DateCompleted = NULL,
            TotalTimeSpent = 0,
            PauseTimeMinutes = 0,
            LastActionTime = NULL,
            
            -- Support ke fields bhi reset karo
            SupportStartDate = NULL,
            SupportCompleteDate = NULL,
            SupportTimeSpent = 0,
            SupportPauseTime = 0,
            SupportLastActionTime = NULL,
            IsSupportPaused = 0,
            SupportRemark = NULL

        WHERE PointID = @PointID"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                ' Agar ek row update hui, matlab success.
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    ' Replace the old reset function with this new, corrected one
    Public Shared Sub ResetSupportFieldsForNewCycle(pointId As Integer)
        Using conn As New SqlConnection(ConnectionString)
            ' ✅ CORRECT LOGIC:
            ' Hum sirf naye timer session ke liye zaroori fields ko reset kar rahe hain.
            ' Hum SupportTimeSpent aur SupportPauseTime ko NAHI chhuenge, taaki pichla record save rahe.
            Dim query As String = "
            UPDATE Points 
            SET 
                SupportStartDate = NULL, 
                SupportCompleteDate = NULL, 
                SupportRemark = NULL,
                SupportLastActionTime = NULL,
                IsSupportPaused = 0
            WHERE PointID = @PointID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub



    ' In DataAccess.vb
    ' 👇 REPLACE THIS ENTIRE FUNCTION IN YOUR DATAACCESS.VB FILE 👇
    ' In DataAccess.vb
    ' 👇 REPLACE THIS ENTIRE FUNCTION WITH THE CORRECTED VERSION BELOW 👇

    Public Shared Function GetTimeReportData() As List(Of TimeReportData)
        Dim reportData As New List(Of TimeReportData)()
        Using conn As New SqlConnection(ConnectionString)
            ' ✅ CORRECTED QUERY: Uses a CASE statement to show ForwardToTesterDate only when appropriate.
            Dim query As String = "
WITH PointTimeCalc AS (
    SELECT
        p.PointID,
        (
            ISNULL((
                SELECT SUM(DATEDIFF(MINUTE, StartDate, CompleteDate))
                FROM PointHistory
                WHERE PointID = p.PointID AND StartDate IS NOT NULL AND CompleteDate IS NOT NULL
            ), 0)
            +
            ISNULL((
                CASE
                    WHEN p.StartDate IS NOT NULL AND p.DateCompleted IS NOT NULL
                    THEN DATEDIFF(MINUTE, p.StartDate, p.DateCompleted)
                    ELSE 0
                END
            ), 0)
        ) AS TotalElapsedMinutes
    FROM Points p
)
SELECT
    p.PointID,
    p.Title,
    p.Status,
    c.CustomerName,
    pr.ProductName,
    p.Summary AS ModuleName,
    p.Description,
    reportedBy.FullName AS ReportedBy,
    assignedTo.FullName AS AssignedTo,
    assignedBy.FullName AS AssignedBy,
    p.DateCreated AS CreatedDate,
    p.ExpectedDate,
    p.DateTicketVerified,
    p.ExpectedMinutes,
    t.DateCreated AS AssignedDate,
    
    -- Developer Dates
    (SELECT MIN(d) FROM (SELECT StartDate AS d FROM Points WHERE PointID = p.PointID UNION ALL SELECT StartDate AS d FROM PointHistory WHERE PointID = p.PointID) AS AllStartDates) AS DeveloperStartDate,
    (SELECT MAX(d) FROM (SELECT DateCompleted AS d FROM Points WHERE PointID = p.PointID UNION ALL SELECT CompleteDate AS d FROM PointHistory WHERE PointID = p.PointID) AS AllCompleteDates) AS DeveloperCompleteDate,
    
    -- Developer Time
    calc.TotalElapsedMinutes AS DeveloperTotalTime,
    p.TotalTimeSpent AS DeveloperActualTime,
    p.PauseTimeMinutes AS DeveloperPauseTime,
    (CASE WHEN calc.TotalElapsedMinutes > p.ExpectedMinutes THEN calc.TotalElapsedMinutes - p.ExpectedMinutes ELSE 0 END) AS DeveloperDelayTime,

    -- Support Dates & Time
    (SELECT MIN(d) FROM (SELECT DateSentToQC AS d FROM Points WHERE PointID = p.PointID UNION ALL SELECT SentToQCDate AS d FROM PointHistory WHERE PointID = p.PointID) AS AllSentToSupportDates) AS SendToSupportDate,
    p.SupportTimeSpent AS SupportActualTime,
    p.SupportPauseTime AS SupportPauseTime,
    (ISNULL(p.SupportTimeSpent, 0) + ISNULL(p.SupportPauseTime, 0)) AS SupportTotalTime,
    
    -- Other Dates
    p.DateSupportVerified,
    p.DateSentToMerge,
    
    -- ****** THIS IS THE FIX ******
    -- Sirf tab date dikhayein jab point QC ke liye forward ho chuka ho.
    CASE 
        WHEN p.Status IN ('PendingQC', 'In-Testing', 'Testing-Completed', 'Closed', 'Reject') 
        THEN p.DateSentToQC 
        ELSE NULL 
    END AS ForwardToTesterDate,
    
    p.TesterStartDate,
    p.TesterCompleteDate,
    p.DateClosed
FROM
    Points AS p
LEFT JOIN Tickets AS t ON p.TicketID = t.TicketID
LEFT JOIN Customers AS c ON p.CustomerID = c.CustomerID
LEFT JOIN Products AS pr ON p.ProductID = pr.ProductID
LEFT JOIN Users AS reportedBy ON p.ReportedByID = reportedBy.UserID
LEFT JOIN Users AS assignedTo ON p.AssignedToID = assignedTo.UserID
LEFT JOIN Users AS assignedBy ON t.CreatedByID = assignedBy.UserID
JOIN PointTimeCalc calc ON p.PointID = calc.PointID
WHERE p.TicketID IS NOT NULL
ORDER BY
    p.PointID DESC;
"

            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        reportData.Add(New TimeReportData With {
                    .PointID = CInt(reader("PointID")),
                    .Title = reader("Title").ToString(),
                    .CustomerName = If(IsDBNull(reader("CustomerName")), "", reader("CustomerName").ToString()),
                    .Status = If(IsDBNull(reader("Status")), "", reader("Status").ToString()),
                    .ModuleName = If(IsDBNull(reader("ModuleName")), "", reader("ModuleName").ToString()),
                    .Description = If(IsDBNull(reader("Description")), "", reader("Description").ToString()),
                    .ProductName = If(IsDBNull(reader("ProductName")), "N/A", reader("ProductName").ToString()),
                    .ReportedBy = If(IsDBNull(reader("ReportedBy")), "", reader("ReportedBy").ToString()),
                    .AssignedTo = If(IsDBNull(reader("AssignedTo")), "", reader("AssignedTo").ToString()),
                    .AssignedBy = If(IsDBNull(reader("AssignedBy")), "", reader("AssignedBy").ToString()),
                    .CreatedDate = If(IsDBNull(reader("CreatedDate")), Nothing, FormatDateToUtcIsoString((reader("CreatedDate")))),
                    .ExpectedDate = If(IsDBNull(reader("ExpectedDate")), Nothing, CType(reader("ExpectedDate"), DateTime?)),
                    .DateTicketVerified = If(IsDBNull(reader("DateTicketVerified")), Nothing, CType(reader("DateTicketVerified"), DateTime?)),
                    .ExpectedMinutes = If(IsDBNull(reader("ExpectedMinutes")), Nothing, CType(reader("ExpectedMinutes"), Integer?)),
                    .AssignedDate = If(IsDBNull(reader("AssignedDate")), Nothing, CType(reader("AssignedDate"), DateTime?)),
                    .DeveloperStartDate = If(IsDBNull(reader("DeveloperStartDate")), Nothing, CType(reader("DeveloperStartDate"), DateTime?)),
                    .DeveloperCompleteDate = If(IsDBNull(reader("DeveloperCompleteDate")), Nothing, CType(reader("DeveloperCompleteDate"), DateTime?)),
                    .DeveloperTotalTime = If(IsDBNull(reader("DeveloperTotalTime")), Nothing, CType(reader("DeveloperTotalTime"), Integer?)),
                    .DeveloperActualTime = If(IsDBNull(reader("DeveloperActualTime")), Nothing, CType(reader("DeveloperActualTime"), Integer?)),
                    .DeveloperPauseTime = If(IsDBNull(reader("DeveloperPauseTime")), Nothing, CType(reader("DeveloperPauseTime"), Integer?)),
                    .DeveloperDelayTime = If(IsDBNull(reader("DeveloperDelayTime")), Nothing, CType(reader("DeveloperDelayTime"), Integer?)),
                    .SendToSupportDate = If(IsDBNull(reader("SendToSupportDate")), Nothing, CType(reader("SendToSupportDate"), DateTime?)),
                    .SupportTotalTime = If(IsDBNull(reader("SupportTotalTime")), Nothing, CType(reader("SupportTotalTime"), Integer?)),
                    .SupportActualTime = If(IsDBNull(reader("SupportActualTime")), Nothing, CType(reader("SupportActualTime"), Integer?)),
                    .SupportPauseTime = If(IsDBNull(reader("SupportPauseTime")), Nothing, CType(reader("SupportPauseTime"), Integer?)),
                    .DateSupportVerified = If(IsDBNull(reader("DateSupportVerified")), Nothing, CType(reader("DateSupportVerified"), DateTime?)),
                    .DateSentToMerge = If(IsDBNull(reader("DateSentToMerge")), Nothing, CType(reader("DateSentToMerge"), DateTime?)),
                    .ForwardToTesterDate = If(IsDBNull(reader("ForwardToTesterDate")), Nothing, CType(reader("ForwardToTesterDate"), DateTime?)),
                    .TesterStartDate = If(IsDBNull(reader("TesterStartDate")), Nothing, CType(reader("TesterStartDate"), DateTime?)),
                    .TesterCompleteDate = If(IsDBNull(reader("TesterCompleteDate")), Nothing, CType(reader("TesterCompleteDate"), DateTime?)),
                    .DateClosed = If(IsDBNull(reader("DateClosed")), Nothing, CType(reader("DateClosed"), DateTime?))
                })
                    End While
                End Using
            End Using
        End Using
        Return reportData
    End Function

    Public Shared Function SendPointsToReverify(pointIds As List(Of Integer)) As Boolean
        If pointIds Is Nothing OrElse pointIds.Count = 0 Then
            Return False
        End If

        Using conn As New SqlConnection(ConnectionString)
            ' Hum IsVerified ko 0 kar denge taaki yeh Assign page par na dikhe,
            ' aur VerificationStatus ko 2, taaki Verify page par highlight ho sake.
            Dim query As String = "
        UPDATE Points 
        SET 
            IsVerified = 0, 
            VerificationStatus = 2 
        WHERE 
            PointID IN (" & String.Join(",", pointIds) & ")"

            Using cmd As New SqlCommand(query, conn)
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function


    Public Shared Function SetToDoDateForPoints(pointIds As List(Of Integer), toDoDate As DateTime) As Boolean
        If pointIds Is Nothing OrElse pointIds.Count = 0 Then
            Return False
        End If

        Using conn As New SqlConnection(ConnectionString)
            ' Hum ek hi query se saare selected points ko update karenge
            Dim query As String = "
      UPDATE Points 
      SET 
          ToDoDate = @ToDoDate
      WHERE 
          PointID IN (" & String.Join(",", pointIds) & ")"

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@ToDoDate", toDoDate.Date) ' Sirf date part use karein
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    Public Shared Function GetWorkloadForDeveloper(developerId As Integer) As List(Of WorkloadPoint)
        Dim points As New List(Of WorkloadPoint)()
        Using conn As New SqlConnection(ConnectionString)
            ' Hum sirf zaroori columns hi fetch karenge performance ke liye
            Dim query As String = "
      SELECT 
          Status, 
          ISNULL(ExpectedMinutes, 0) AS ExpectedMinutes, 
          ToDoDate 
      FROM Points 
      WHERE AssignedToID = @DeveloperID AND Status NOT IN ('Closed', 'Reject')" ' Sirf active points ka workload

            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@DeveloperID", developerId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        points.Add(New WorkloadPoint With {
                        .Status = reader("Status").ToString(),
                        .ExpectedMinutes = CInt(reader("ExpectedMinutes")),
                        .ToDoDate = If(reader("ToDoDate") Is DBNull.Value, Nothing, CDate(reader("ToDoDate")))
                    })
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function

    ' ... DataAccess class ke andar ...

    ' FUNCTION 1: Merge request bhejne ke liye (Ismein MergeAssignedToID save hoga)
    Public Shared Function SendPointToMerge(pointId As Integer, mergeAssignedToId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            ' Hum Status, MergeAssignedToID, aur DateSentToMerge, teeno ko update karenge
            Dim query As String = "UPDATE Points SET Status = 'PendingMerge', MergeAssignedToID = @MergeUserID, DateSentToMerge = GETDATE() WHERE PointID = @PointID AND Status = 'SupportVerified'"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@MergeUserID", mergeAssignedToId)
                cmd.Parameters.AddWithValue("@PointID", pointId)
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    ' In DataAccess.vb
    ' Replace your old GetPointsForMerge function with this FINAL version.

    Public Shared Function GetPointsForMerge(userId As Integer) As List(Of PointData)
        Dim points As New List(Of PointData)()
        Using conn As New SqlConnection(ConnectionString)
            ' ▼▼▼ MODIFIED QUERY ▼▼▼
            ' REM The WHERE clause for Status has been removed.
            ' It now fetches ALL points ever assigned to this merge user.
            ' The ORDER BY clause is updated to show active tasks first.
            Dim query As String = "
        SELECT 
            p.PointID, p.Title, p.Status, p.Description, p.Summary, p.Category, p.Priority,
            c.CustomerName, 
            pr.ProductName,
            dev.FullName AS AssignedToFullName, 
            rep.FullName AS ReportedByFullName,
            p.DateSentToMerge
        FROM Points p
        LEFT JOIN Users dev ON p.AssignedToID = dev.UserID
        LEFT JOIN Users rep ON p.ReportedByID = rep.UserID 
        LEFT JOIN Customers c ON p.CustomerID = c.CustomerID
        LEFT JOIN Products pr ON p.ProductID = pr.ProductID
        WHERE 
            p.MergeAssignedToID = @UserID
        ORDER BY 
            CASE
                WHEN p.Status = 'PendingMerge' THEN 1
                WHEN p.Status = 'ReOpened' THEN 2
                WHEN p.Status = 'PendingQC' THEN 3
                ELSE 4
            END,
            p.DateCompleted DESC
    "
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        points.Add(New PointData With {
                    .PointID = CInt(reader("PointID")),
                    .Title = If(reader("Title") Is DBNull.Value, "", reader("Title").ToString()),
                    .Status = If(reader("Status") Is DBNull.Value, "", reader("Status").ToString()),
                    .Description = If(reader("Description") Is DBNull.Value, "", reader("Description").ToString()),
                    .CustomerName = If(reader("CustomerName") Is DBNull.Value, "", reader("CustomerName").ToString()),
                    .ProductName = If(reader("ProductName") Is DBNull.Value, "", reader("ProductName").ToString()),
                    .Summary = If(reader("Summary") Is DBNull.Value, "", reader("Summary").ToString()),
                    .Category = If(reader("Category") Is DBNull.Value, "", reader("Category").ToString()),
                    .Priority = If(reader("Priority") Is DBNull.Value, "", reader("Priority").ToString()),
                    .ReportedByFullName = If(reader("ReportedByFullName") Is DBNull.Value, "N/A", reader("ReportedByFullName").ToString()),
                    .AssignedToFullName = If(reader("AssignedToFullName") Is DBNull.Value, "N/A", reader("AssignedToFullName").ToString()),
                    .DateSentToMerge = If(reader("DateSentToMerge") Is DBNull.Value, CType(Nothing, DateTime?), CDate(reader("DateSentToMerge")))
                })
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function

    Public Shared Function DoesUserHaveMergeRequests(userId As Integer) As Boolean
        ' Hum COUNT(*) ka istemal karenge jo bahut fast hota hai.
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT COUNT(*) FROM Points WHERE Status = 'PendingMerge' AND MergeAssignedToID = @UserID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                ' ExecuteScalar ek single value (count) return karta hai
                Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                ' Agar count 0 se zyada hai, toh True return karein
                Return count > 0
            End Using
        End Using
    End Function


    ' DataAccess.vb mein is function ko replace karein

    Public Shared Function GetFilteredPointsForGridForDeveloper(status As String, fromDate As Nullable(Of DateTime), toDate As Nullable(Of DateTime), developerId As Integer, customerId As Integer) As List(Of PointData)
        Dim points As New List(Of PointData)()

        ' ▼▼▼ YEH QUERY UPDATE KI GAYI HAI ▼▼▼
        ' Ismein Tickets table ko join karke CreatedByID se user ka naam (AssignedByFullName) nikala gaya hai.
        Dim query As String = "
SELECT 
   p.PointID, p.Title, p.Description, p.DateCreated, p.Category, p.Status, p.ReportedByID,
   p.Priority, p.Complexity, p.ExpectedDate, c.CustomerName,
   prod.ProductName, p.Summary AS ModuleName, 
   au.FullName AS AssignedToFullName,
   assignedBy.FullName AS AssignedByFullName, -- Yeh naya field hai
   pa.FilePath AS AudioFilePath,
   p.DateCompleted,
   ru.FullName AS ReportedByFullName,
   p.ExpectedMinutes,
   p.TotalTimeSpent
FROM Points p
LEFT JOIN Users ru ON p.ReportedByID = ru.UserID
LEFT JOIN Customers c ON p.CustomerID = c.CustomerID
LEFT JOIN Products prod ON p.ProductID = prod.ProductID
LEFT JOIN Users au ON p.AssignedToID = au.UserID
LEFT JOIN Tickets t ON p.TicketID = t.TicketID -- Tickets table se join
LEFT JOIN Users assignedBy ON t.CreatedByID = assignedBy.UserID -- Users table se dobara join (Assigned By ke liye)
LEFT JOIN PointAttachments pa ON pa.PointID = p.PointID AND pa.FilePath LIKE '%.webm'
WHERE p.AssignedToID = @DeveloperID " ' <-- Main security filter

        If fromDate.HasValue AndAlso toDate.HasValue Then
            query &= " AND CONVERT(DATE, p.DateCreated) BETWEEN @FromDate AND @ToDate"
        End If
        If customerId > 0 Then query &= " AND p.CustomerID = @CustomerID"

        ' Status ke liye logic
        Select Case status
            Case "Total"
    ' Koi extra filter nahi
            Case "OpenTasks"
                query &= " AND p.Status IN ('Assigned', 'In Progress', 'ReOpened')"
            Case "Delayed"
                query &= " AND p.TotalTimeSpent > p.ExpectedMinutes AND p.ExpectedMinutes IS NOT NULL AND p.ExpectedMinutes > 0"
            Case "Completed"
                query &= " AND p.Status IN ('Completed', 'Closed')"
            Case Else
                query &= " AND p.Status = @Status"
        End Select

        query &= " ORDER BY p.DateCreated DESC"

        Using conn As New SqlConnection(ConnectionString)
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@DeveloperID", developerId)

                If fromDate.HasValue AndAlso toDate.HasValue Then
                    cmd.Parameters.AddWithValue("@FromDate", fromDate.Value.Date)
                    cmd.Parameters.AddWithValue("@ToDate", toDate.Value.Date)
                End If

                If customerId > 0 Then cmd.Parameters.AddWithValue("@CustomerID", customerId)

                If status <> "Total" AndAlso status <> "OpenTasks" AndAlso status <> "Delayed" AndAlso status <> "Completed" Then
                    cmd.Parameters.AddWithValue("@Status", status)
                End If

                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        points.Add(New PointData With {
                           .PointID = CInt(reader("PointID")),
                           .Title = reader("Title").ToString(),
                           .Description = If(reader("Description") Is DBNull.Value, "", reader("Description").ToString()),
                           .DateCreated = CDate(reader("DateCreated")),
                           .Category = If(reader("Category") Is DBNull.Value, Nothing, reader("Category").ToString()),
                           .Status = reader("Status").ToString(),
                           .ReportedByFullName = reader("ReportedByFullName").ToString(),
                           .Priority = If(reader("Priority") Is DBNull.Value, "", reader("Priority").ToString()),
                           .CustomerName = If(reader("CustomerName") Is DBNull.Value, "N/A", reader("CustomerName").ToString()),
                           .ProductName = If(reader("ProductName") Is DBNull.Value, "N/A", reader("ProductName").ToString()),
                           .Summary = If(reader("ModuleName") Is DBNull.Value, "N/A", reader("ModuleName").ToString()),
                           .AssignedToFullName = If(reader("AssignedToFullName") Is DBNull.Value, "Unassigned", reader("AssignedToFullName").ToString()),
                           .AudioFilePath = If(reader("AudioFilePath") Is DBNull.Value, Nothing, reader("AudioFilePath").ToString()),
                           .ExpectedDate = If(reader.IsDBNull(reader.GetOrdinal("ExpectedDate")), Nothing, CType(reader("ExpectedDate"), DateTime?)),
                           .ExpectedMinutes = If(reader("ExpectedMinutes") Is DBNull.Value, Nothing, CType(reader("ExpectedMinutes"), Integer?)),
                           .TotalTimeSpent = If(reader("TotalTimeSpent") Is DBNull.Value, Nothing, CType(reader("TotalTimeSpent"), Integer?)),
                           .AssignedByFullName = If(reader("AssignedByFullName") Is DBNull.Value, "N/A", reader("AssignedByFullName").ToString()) ' <-- NAYI LINE ADD KI GAYI HAI
                   })
                    End While
                End Using
            End Using
        End Using
        Return points
    End Function

    Public Shared Sub CreateNotification(userIdTo As Integer, message As String, Optional navigateUrl As String = "#")
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "INSERT INTO Notifications (UserID_To, MessageText, NavigateURL) VALUES (@UserID_To, @Message, @URL)"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID_To", userIdTo)
                cmd.Parameters.AddWithValue("@Message", message)
                cmd.Parameters.AddWithValue("@URL", navigateUrl)
                conn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub

    ' Function to get all (read and unread) notifications for a user
    Public Shared Function GetNotificationsForUser(userId As Integer) As List(Of NotificationData)
        Dim notifications As New List(Of NotificationData)()
        Using conn As New SqlConnection(ConnectionString)
            ' Hum sirf pichle 30 din ki notifications dikhayenge
            Dim query As String = "SELECT TOP 50 * FROM Notifications WHERE UserID_To = @UserID ORDER BY DateCreated DESC"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        notifications.Add(New NotificationData With {
                            .NotificationID = CInt(reader("NotificationID")),
                            .UserID_To = CInt(reader("UserID_To")),
                            .MessageText = reader("MessageText").ToString(),
                            .NavigateURL = reader("NavigateURL").ToString(),
                            .IsRead = CBool(reader("IsRead")),
                            .DateCreated = CDate(reader("DateCreated"))
                        })
                    End While
                End Using
            End Using
        End Using
        Return notifications
    End Function

    ' Function to get only the unread count
    Public Shared Function GetUnreadNotificationCount(userId As Integer) As Integer
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "SELECT COUNT(*) FROM Notifications WHERE UserID_To = @UserID AND IsRead = 0"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                Return CInt(cmd.ExecuteScalar())
            End Using
        End Using
    End Function

    ' Mark a single notification as read
    Public Shared Function MarkNotificationAsRead(notificationId As Integer, userId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            ' UserID check is for security
            Dim query As String = "UPDATE Notifications SET IsRead = 1 WHERE NotificationID = @NotificationID AND UserID_To = @UserID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@NotificationID", notificationId)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function

    ' Delete a single notification
    Public Shared Function DeleteNotification(notificationId As Integer, userId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            ' UserID check is for security
            Dim query As String = "DELETE FROM Notifications WHERE NotificationID = @NotificationID AND UserID_To = @UserID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@NotificationID", notificationId)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function


    Public Shared Function ClearAllNotifications(userId As Integer) As Boolean
        Using conn As New SqlConnection(ConnectionString)
            Dim query As String = "DELETE FROM Notifications WHERE UserID_To = @UserID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                Return cmd.ExecuteNonQuery() > 0
            End Using
        End Using
    End Function


    Private Shared Function ConvertToIst(utcDateAsObject As Object) As Nullable(Of DateTime)
        If IsDBNull(utcDateAsObject) Then
            Return Nothing
        End If
        Dim dateCreatedUtc As DateTime = CDate(utcDateAsObject)
        ' Agar saal 1 se kam hai (default min value), to null return karein
        If dateCreatedUtc.Year <= 1 Then
            Return Nothing
        End If
        Dim indianZone As TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById("India Standard Time")
        Return TimeZoneInfo.ConvertTimeFromUtc(dateCreatedUtc, indianZone)
    End Function


    Private Shared Function FormatDateToUtcIsoString(ByVal dateObj As Object) As String
        ' Pehle check karein ki database se value NULL to nahi hai
        If dateObj Is Nothing OrElse IsDBNull(dateObj) Then
            Return Nothing
        End If

        Dim utcDate As DateTime = CDate(dateObj)

        If utcDate.Year <= 1 Then
            Return Nothing
        End If

        ' Sirf UTC date ko standard ISO 8601 format mein "Z" ke saath return karein
        ' "Z" ka matlab hai ki yeh time UTC hai
        Return utcDate.ToString("yyyy-MM-ddTHH:mm:ssZ")
    End Function


End Class

