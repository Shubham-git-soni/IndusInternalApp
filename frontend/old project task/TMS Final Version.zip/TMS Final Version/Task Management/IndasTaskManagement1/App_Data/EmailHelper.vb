﻿Imports System.Net
Imports System.Net.Mail
Imports System.Configuration

Public Class EmailHelper
    Public Shared Function SendEmail(toEmail As String, subject As String, body As String) As Boolean
        Try
            Dim senderEmail As String = ConfigurationManager.AppSettings("SenderEmail")
            Dim senderPassword As String = ConfigurationManager.AppSettings("SenderPassword")

            If String.IsNullOrEmpty(senderEmail) OrElse String.IsNullOrEmpty(senderPassword) Then
                Throw New Exception("Sender email or password is missing in Web.config")
            End If

            Dim smtpClient As New SmtpClient("smtp.gmail.com", 587)
            smtpClient.Credentials = New NetworkCredential(senderEmail, senderPassword)
            smtpClient.EnableSsl = True

            Dim mailMessage As New MailMessage()
            mailMessage.From = New MailAddress(senderEmail, "Indas Task Manager")
            mailMessage.To.Add(toEmail)
            mailMessage.Subject = subject
            mailMessage.Body = body
            mailMessage.IsBodyHtml = True

            smtpClient.Send(mailMessage)
            Return True

        Catch ex As Exception
            Throw New Exception("Email sending failed: " & ex.Message)
        End Try
    End Function
End Class
