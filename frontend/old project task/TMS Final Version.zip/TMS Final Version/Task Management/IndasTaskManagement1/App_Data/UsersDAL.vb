﻿Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Data

Public Class UsersDAL
    Public Shared Function GetAllUsers() As DataTable
        Dim dt As New DataTable()
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            Dim cmd As New SqlCommand("SELECT UserID, FullName, Email, Role, IsActive, DateCreated FROM Users", conn)
            conn.Open()
            dt.Load(cmd.ExecuteReader())
        End Using

        Return dt
    End Function
    Public Shared Sub UpdateUser(userId As Integer, values As Dictionary(Of String, Object))
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            ' ✅ Base query
            Dim query As String = "UPDATE Users SET " &
                              "FullName = ISNULL(@FullName, FullName), " &
                              "Email = ISNULL(@Email, Email), " &
                              "Role = ISNULL(@Role, Role), " &
                              "IsActive = ISNULL(@IsActive, IsActive)"

            ' ✅ Check if password provided
            Dim password As Object = Nothing
            If values.TryGetValue("Password", password) AndAlso Not String.IsNullOrWhiteSpace(Convert.ToString(password)) Then
                query &= ", PasswordHash = @PasswordHash"
            End If

            query &= " WHERE UserID = @UserID"

            Using cmd As New SqlCommand(query, conn)
                Dim fullName As Object = Nothing
                Dim email As Object = Nothing
                Dim role As Object = Nothing
                Dim isActive As Object = Nothing

                values.TryGetValue("FullName", fullName)
                values.TryGetValue("Email", email)
                values.TryGetValue("Role", role)
                values.TryGetValue("IsActive", isActive)

                cmd.Parameters.AddWithValue("@FullName", If(fullName, DBNull.Value))
                cmd.Parameters.AddWithValue("@Email", If(email, DBNull.Value))
                cmd.Parameters.AddWithValue("@Role", If(role, DBNull.Value))
                cmd.Parameters.AddWithValue("@IsActive", If(isActive, DBNull.Value))
                cmd.Parameters.AddWithValue("@UserID", userId)

                ' ✅ Only update password if provided
                If password IsNot Nothing AndAlso Not String.IsNullOrWhiteSpace(password.ToString()) Then
                    cmd.Parameters.AddWithValue("@PasswordHash", password.ToString())
                End If

                conn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub




    Public Shared Sub DeleteUser(userId As Integer)
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            Dim cmd As New SqlCommand("DELETE FROM Users WHERE UserID = @UserID", conn)
            cmd.Parameters.AddWithValue("@UserID", userId)
            conn.Open()
            cmd.ExecuteNonQuery()
        End Using
    End Sub

    Public Shared Function GetTesterEmailByPointId(pointId As Integer) As String
        Try
            Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
                Dim query As String = "
                SELECT U.Email 
                FROM Users U
                INNER JOIN Points P ON U.UserID = P.TesterID
                WHERE P.PointID = @PointID"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@PointID", pointId)
                    conn.Open()
                    Dim result = cmd.ExecuteScalar()
                    If result IsNot Nothing Then
                        Return result.ToString()
                    End If
                End Using
            End Using
        Catch ex As Exception
            Throw New Exception("Error fetching tester email: " & ex.Message)
        End Try

        Return ""
    End Function

    Public Shared Sub InsertUser(fullName As String, email As String, role As String, isActive As Boolean, password As String)
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            Dim sql As String = "
            INSERT INTO Users (FullName, Email, Role, IsActive, PasswordHash, DateCreated, EmailVerified)
            VALUES (@FullName, @Email, @Role, @IsActive, @Password, GETDATE(), 0)
        "
            Using cmd As New SqlCommand(sql, conn)
                cmd.Parameters.AddWithValue("@FullName", fullName)
                cmd.Parameters.AddWithValue("@Email", email)
                cmd.Parameters.AddWithValue("@Role", role)
                cmd.Parameters.AddWithValue("@IsActive", isActive)
                cmd.Parameters.AddWithValue("@Password", password) ' ⚠️ plain text in PasswordHash column
                conn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub
    Public Shared Function CheckEmailExists(email As String) As Boolean
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString
        Using conn As New SqlConnection(connStr)
            conn.Open()
            Dim query As String = "SELECT COUNT(*) FROM Users WHERE Email = @Email"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@Email", email)
                Dim count As Integer = Convert.ToInt32(cmd.ExecuteScalar())
                Return count > 0
            End Using
        End Using
    End Function




End Class
