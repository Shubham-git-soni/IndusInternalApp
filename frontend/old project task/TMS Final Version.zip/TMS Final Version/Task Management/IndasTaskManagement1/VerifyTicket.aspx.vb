﻿Imports System.Web.Services

Public Class VerifyTicket
    Inherits BasePage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

    End Sub


    <WebMethod()>
    Public Shared Function GetQueuePoints() As Object
        Return DataAccess.GetAllPointsForVerification()
    End Function


    <WebMethod()>
    Public Shared Function MarkVerified(pointId As Integer) As Object
        Try
            Dim result = DataAccess.MarkPointVerified(pointId)
            If result = "AlreadyVerified" Then
                Return New With {.success = False, .message = "Point is already verified."}
            ElseIf result = "Updated" Then
                Return New With {.success = True, .message = "Point verified successfully."}
            Else
                Return New With {.success = False, .message = "Failed to update"}
            End If
        Catch ex As Exception
            Return New With {.success = False, .message = ex.Message}
        End Try
    End Function

    <WebMethod()>
    Public Shared Function MarkMultipleVerified(pointIds As List(Of Integer)) As String
        If pointIds Is Nothing OrElse pointIds.Count = 0 Then
            Return "No tickets selected."
        End If

        Dim successCount As Integer = 0
        Dim failCount As Integer = 0

        ' Har selected ID ke liye, aapke purane, perfect logic ko call karein
        For Each pointId As Integer In pointIds
            Try
                Dim result = DataAccess.MarkPointVerified(pointId)
                If result = "Updated" Then
                    successCount += 1
                Else
                    failCount += 1
                End If
            Catch ex As Exception
                failCount += 1
            End Try
        Next

        ' User ko ek summary message return karein
        Return $"Verified: {successCount}, Failed/Already Verified: {failCount}"
    End Function

End Class

