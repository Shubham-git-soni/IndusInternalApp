﻿Imports System.Data.SqlClient
Imports System.Configuration

Public Class UserPermissions
    Inherits System.Web.UI.Page

    ' Apne project ke saare pages ki list yahan define karein
    Private Shared ReadOnly AllPages As New Dictionary(Of String, String) From {
    {"DashboardAdmin.aspx", "Admin Dashboard"},
    {"ManageUsers.aspx", "Manage Users"},
    {"ManageCustomers.aspx", "Manage Customers"},
    {"AddPoint.aspx", "Add Ticket"},
    {"ManagePoint.aspx", "Manage Tickets"},
     {"VerifyTicket.aspx", "Verify Tickets"},
    {"CreateTicket.aspx", "Assign Tickets"},
    {"ManageTickets.aspx", "Manage Assignments"},
    {"DashboardDeveloper.aspx", "Developer Dashboard"},
    {"DashboardDeveloperKPI.aspx", "Developer KPI Dashboard"},
    {"DashboardTester.aspx", "Tester Dashboard"},
    {"TimeReport.aspx", "Time Report"},
    {"UserPermissions.aspx", "User Permissions"},
    {"SupportActionCenter.aspx", "Support Action Center"}
}
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        If Not IsPostBack Then
            LoadUsers()
            PopulatePagesCheckboxList()
        End If
    End Sub

    Private Sub LoadUsers()
        ddlUsers.DataSource = DataAccess.GetUsers() ' Assuming this gets all users
        ddlUsers.DataTextField = "FullName"
        ddlUsers.DataValueField = "UserID"
        ddlUsers.DataBind()
        ddlUsers.Items.Insert(0, New ListItem("-- Select a User --", "0"))
    End Sub


    Private Sub PopulatePagesCheckboxList()
        cblPages.DataSource = AllPages
        cblPages.DataTextField = "Value"
        cblPages.DataValueField = "Key"
        cblPages.DataBind()
    End Sub

    Protected Sub ddlUsers_SelectedIndexChanged(sender As Object, e As EventArgs)

        ' Pehle saare checkboxes ko uncheck karein
        For Each item As ListItem In cblPages.Items
            item.Selected = False
        Next

        Dim userId As Integer = Convert.ToInt32(ddlUsers.SelectedValue)
        If userId > 0 Then
            ' Database se is user ki saved permissions laayein
            Dim userPermissions As List(Of String) = GetUserPermissions(userId)

            ' Checkboxes ko user ki permissions ke anusaar check karein
            For Each item As ListItem In cblPages.Items
                If userPermissions.Contains(item.Value) Then
                    item.Selected = True
                End If
            Next
        End If
    End Sub

    Protected Sub btnSavePermissions_Click(sender As Object, e As EventArgs)
        Dim userId As Integer = Convert.ToInt32(ddlUsers.SelectedValue)
        If userId <= 0 Then
            ScriptManager.RegisterStartupScript(Me, Me.GetType(), "NoUserSelected", "alert('Please select a user first.');", True)
            Return
        End If

        ' ==== AAPKA PURANA LOGIC BILKUL WAISE HI HAI (DELETE-THEN-INSERT) ====
        ' Step 1: Is user ki saari purani permissions DELETE kar dein
        DeleteUserPermissions(userId)

        ' Step 2: Har selected checkbox ke liye ek nayi permission INSERT karein
        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
            conn.Open()
            For Each item As ListItem In cblPages.Items
                If item.Selected Then
                    Dim query As String = "INSERT INTO UserPagePermissions (UserID, PageName) VALUES (@UserID, @PageName)"
                    Using cmd As New SqlCommand(query, conn)
                        cmd.Parameters.AddWithValue("@UserID", userId)
                        cmd.Parameters.AddWithValue("@PageName", item.Value)
                        cmd.ExecuteNonQuery()
                    End Using
                End If
            Next
        End Using
        ' =================================================================

        ' ==== YEH HAI FINAL FIX: Success Message aur Page Refresh ====
        ' Step 3: Client-side par JavaScript chalaayein
        Dim script As String = "
        alert('Permissions saved successfully!');
        setTimeout(function() {
            window.location.href = window.location.href;
        }, 500); // 0.5 second ka delay
    "
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "SaveSuccess", script, True)
    End Sub

    ' Helper functions (aap inhein DataAccess.vb mein bhi daal sakte hain)
    Private Function GetUserPermissions(userId As Integer) As List(Of String)
        Dim permissions As New List(Of String)()
        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
            Dim query As String = "SELECT PageName FROM UserPagePermissions WHERE UserID = @UserID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    While reader.Read()
                        permissions.Add(reader("PageName").ToString())
                    End While
                End Using
            End Using
        End Using
        Return permissions
    End Function

    Private Sub DeleteUserPermissions(userId As Integer)
        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
            Dim query As String = "DELETE FROM UserPagePermissions WHERE UserID = @UserID"
            Using cmd As New SqlCommand(query, conn)
                cmd.Parameters.AddWithValue("@UserID", userId)
                conn.Open()
                cmd.ExecuteNonQuery()
            End Using
        End Using
    End Sub
End Class