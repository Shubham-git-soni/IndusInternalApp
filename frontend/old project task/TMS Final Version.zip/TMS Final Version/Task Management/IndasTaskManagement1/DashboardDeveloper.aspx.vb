﻿Imports System.Web.Services
Imports System.Data.SqlClient
Imports System.Web.Script.Services
Imports IndasTaskManagement1.DataAccess

Partial Class DashboardDeveloper
    Inherits BasePage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Prevent caching so browser can't go back after logout
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
        Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches)

        ' Session validation
        If Session("UserID") Is Nothing Then
            Response.Redirect("Landing.aspx")
        End If
    End Sub

    ' 🔥 Logout method to clear session
    <WebMethod()>
    Public Shared Sub Logout()
        HttpContext.Current.Session.Clear()
        HttpContext.Current.Session.Abandon()
    End Sub
    <WebMethod()>
    Public Shared Function GetMyAssignedTicketsFlattened() As List(Of TicketData)
        Dim devId As Integer = HttpContext.Current.Session("UserID")
        Return DataAccess.GetTicketsWithPointsByDeveloper(devId)
    End Function


    <WebMethod()>
    Public Shared Function GetPointsForTicket(ticketId As Integer) As List(Of PointData)
        Return DataAccess.GetPointsForDeveloperDashboard(ticketId)
    End Function

    <WebMethod()>
    Public Shared Function GetPointForActionCenter(pointId As Integer) As PointData
        Return DataAccess.GetPointDetailsById(pointId) ' You must have this method already
    End Function

    <WebMethod()>
    Public Shared Function StartPointTimer(pointId As Integer) As Boolean
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return False
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            Dim result = DataAccess.StartPointTimer(pointId, userId)
            Return result.success
        Catch ex As Exception
            Return False
        End Try
    End Function

    <WebMethod()>
    Public Shared Function CompletePointTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "Ticket is closed"}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            Return DataAccess.CompletePointTimer(pointId, userId)

        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function
    <WebMethod()>
    <ScriptMethod(ResponseFormat:=ResponseFormat.Json)>
    Public Shared Function SendPointToQC(pointId As Integer, developerRemark As String) As Object
        If DataAccess.IsTicketClosed(pointId) Then
            Return New With {.success = False, .message = "This ticket is already closed."}
        End If

        Try
            Dim developerId As Integer = CInt(HttpContext.Current.Session("UserID"))
            Dim status As String = DataAccess.GetPointStatus(pointId)
            If status = "Closed" OrElse status = "PendingSupport" Then
                Return New With {.success = False, .message = "Point is already closed or sent to Support."}
            End If

            Dim updated = DataAccess.UpdatePointStatusAndDate(pointId, "PendingSupport", "DateSentToQC", DateTime.Now)

            If updated Then
                DataAccess.CreatePointHistoryCycle(pointId, developerId, developerRemark)
                DataAccess.ResetTesterFieldsForNewQCCycle(pointId)

                ' --- NOTIFICATION LOGIC START ---
                ' Ab hum sirf original reporter (jo support user hai) ko notification bhejenge.
                Dim pointDetails = DataAccess.GetPointDetailsById(pointId)
                If pointDetails IsNot Nothing AndAlso pointDetails.ReportedByID.HasValue Then
                    Dim devName As String = HttpContext.Current.Session("FullName").ToString()
                    Dim message As String = $"Point #{pointId} is ready for your verification, submitted by {devName}."
                    Dim url As String = $"~/SupportActionCenter.aspx?pointId={pointId}"
                    DataAccess.CreateNotification(pointDetails.ReportedByID.Value, message, url)
                End If
                ' --- NOTIFICATION LOGIC END ---

                ' Email logic ko yahan se hata sakte hain agar notification system use kar rahe hain.
                ' Dim supportUsers As List(Of UserData) = ...

                Return New With {.success = True}
            Else
                Return New With {.success = False, .message = "Failed to update status."}
            End If
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function
    <WebMethod()>
    Public Shared Function SaveDeveloperRemark(pointId As Integer, remark As String) As Boolean

        Return DataAccess.UpdateDeveloperRemark(pointId, remark)

    End Function

    <WebMethod()>
    Public Shared Function GetPointHistoryForGrid(ByVal pointId As Integer) As List(Of PointHistoryData)

        Return DataAccess.GetPointHistory(pointId)

    End Function

    ' Location: DashboardDeveloper.aspx.vb

    <WebMethod()>
    Public Shared Function GetAttachments(pointId As Integer) As List(Of AttachmentData)

        ' ✅ Yeh function 'GetAllAttachmentsForPoint' ko call karna chahiye

        Return DataAccess.GetAllAttachmentsForPoint(pointId)

    End Function

    <WebMethod()>
    Public Shared Function DeleteExistingAttachment(attachmentId As Integer) As Boolean

        Return DataAccess.DeleteAttachmentById(attachmentId)

    End Function

    ' 2. WebMethod to add a NEW attachment to an EXISTING point

    <WebMethod()>
    Public Shared Function AddAttachmentToPoint(pointId As Integer, attachment As AttachmentInfo) As Object

        Try

            Dim uploadedById As Integer = HttpContext.Current.Session("UserID")

            DataAccess.InsertAttachment(pointId, attachment.fileName, attachment.filePath, uploadedById)

            Return New With {.success = True, .message = "Attachment added."}

        Catch ex As Exception

            Return New With {.success = False, .message = "Failed to add attachment."}

        End Try

    End Function

    <WebMethod()>
    Public Shared Function UpdatePointStatus(pointId As Integer, newStatus As String) As Boolean
        Try
            ' Yahan se hum DataAccess layer ke function ko call kar rahe hain
            Return DataAccess.UpdatePointStatus(pointId, newStatus)
        Catch ex As Exception
            ' Agar koi error aaye toh false return karein
            Return False
        End Try
    End Function

    ' ================================================================
    ' NEW TIME TRACKING WEB METHODS
    ' ================================================================

    <WebMethod()>
    Public Shared Function PausePointTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "Ticket is closed"}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            ' Yeh DataAccess ke naye modified function ko call karega
            Return DataAccess.PausePointTimer(pointId, userId)

        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function
    <WebMethod()>
    Public Shared Function ResumePointTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "Ticket is closed"}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            ' Yeh DataAccess ke naye modified function ko call karega
            Return DataAccess.ResumePointTimer(pointId, userId)

        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function
    <WebMethod()>
    Public Shared Function GetTimeLogsForPoint(pointId As Integer) As List(Of PointTimeLogData)
        Try
            Return DataAccess.GetTimeLogsForPoint(pointId)
        Catch ex As Exception
            Return New List(Of PointTimeLogData)()
        End Try
    End Function

    <WebMethod()>
    Public Shared Function GetPointTimeSummary(pointId As Integer) As Object
        Try
            Return DataAccess.GetPointTimeSummary(pointId)
        Catch ex As Exception
            Return Nothing
        End Try
    End Function



    ' ... DashboardDeveloper class ke andar ...

    ' WebMethod 1: Yeh dropdown ke liye Admin users ki list dega
    <WebMethod()>
    Public Shared Function GetMergeReviewers() As List(Of UserData)
        ' Yeh function Admin role waale users ko fetch karta hai
        Return DataAccess.GetUsersByRole("Admin")
    End Function

    ' WebMethod 2: Yeh merge request ko process karega
    <WebMethod()>
    Public Shared Function SendForMerge(pointId As Integer, mergeAssignedToId As Integer) As Object
        Try
            Dim currentStatus As String = DataAccess.GetPointStatus(pointId)
            If currentStatus <> "SupportVerified" Then
                Return New With {.success = False, .message = "This point is not yet verified by support."}
            End If

            Dim success As Boolean = DataAccess.SendPointToMerge(pointId, mergeAssignedToId)

            If success Then
                ' --- NOTIFICATION LOGIC START ---
                Dim devName As String = HttpContext.Current.Session("FullName").ToString()
                Dim message As String = $"Merge Request: Point #{pointId} has been submitted by {devName} for approval."
                Dim url As String = $"~/MergeCode.aspx?pointId={pointId}" ' MergeCode page ka URL
                DataAccess.CreateNotification(mergeAssignedToId, message, url)
                ' --- NOTIFICATION LOGIC END ---

                Return New With {.success = True}
            Else
                Return New With {.success = False, .message = "Failed to send merge request."}
            End If

        Catch ex As Exception
            Return New With {.success = False, .message = "An error occurred: " & ex.Message}
        End Try
    End Function

End Class
