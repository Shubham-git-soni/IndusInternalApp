﻿Imports System.Data.SqlClient
Imports System.IO

Public Class BasePage
    Inherits System.Web.UI.Page

    ' REPLACE your old OnLoad event in BasePage.vb with this new one

    ' REPLACE your old OnLoad event in BasePage.vb with this new one

    Protected Overrides Sub OnLoad(e As EventArgs)
        If Session("UserID") Is Nothing Then
            Response.Redirect("~/Login.aspx")
            Return
        End If

        Dim userRole As String = If(Session("Role") IsNot Nothing, Session("Role").ToString(), "")

        ' Agar user Admin hai, toh use kuch bhi check karne ki zaroorat nahi hai.
        If userRole.Equals("Admin", StringComparison.OrdinalIgnoreCase) Then
            MyBase.OnLoad(e)
            Return
        End If

        ' Agar user Admin nahi hai, toh permissions check karein
        Dim userId As Integer = Convert.ToInt32(Session("UserID"))
        Dim currentPage As String = Path.GetFileName(Me.Request.FilePath)

        ' Public pages ko check se bahar rakhein
        Dim publicPages As New List(Of String) From {"Login.aspx", "Logout.aspx", "AccessDenied.aspx"}
        If Not publicPages.Contains(currentPage, StringComparer.OrdinalIgnoreCase) Then

            ' Step A: Database se check karein ki user ko is page ka access hai ya nahi
            Dim hasAccess As Boolean = False
            Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
                Dim query As String = "SELECT COUNT(*) FROM UserPagePermissions WHERE UserID = @UserID AND PageName = @PageName"
                Using cmd As New SqlCommand(query, conn)
                    cmd.Parameters.AddWithValue("@UserID", userId)
                    cmd.Parameters.AddWithValue("@PageName", currentPage)
                    conn.Open()
                    If Convert.ToInt32(cmd.ExecuteScalar()) > 0 Then hasAccess = True
                End Using
            End Using

            ' Step B: Agar database mein permission nahi mili, toh check karein ki yeh default page toh nahi hai
            If Not hasAccess Then
                Dim isDefaultPage As Boolean = False
                Select Case userRole
                    Case "developer"
                        If currentPage.Equals("DashboardDeveloper.aspx", StringComparison.OrdinalIgnoreCase) OrElse
                       currentPage.Equals("DashboardDeveloperKPI.aspx", StringComparison.OrdinalIgnoreCase) Then
                            isDefaultPage = True
                        End If
                    Case "tester"
                        If currentPage.Equals("DashboardTester.aspx", StringComparison.OrdinalIgnoreCase) Then
                            isDefaultPage = True
                        End If
                    Case "support"
                        If currentPage.Equals("AddPoint.aspx", StringComparison.OrdinalIgnoreCase) Then
                            isDefaultPage = True

                        End If

                        If currentPage.Equals("ManagePoint.aspx", StringComparison.OrdinalIgnoreCase) Then
                            isDefaultPage = True

                        End If

                        If currentPage.Equals("SupportActionCenter.aspx", StringComparison.OrdinalIgnoreCase) Then
                            isDefaultPage = True

                        End If
                End Select

                ' Agar yeh default page hai, toh access de do
                If isDefaultPage Then
                    hasAccess = True
                End If
            End If

            ' Step C: Aakhri check - agar abhi bhi access nahi hai, toh redirect karo
            If Not hasAccess Then
                Response.Redirect("~/AccessDenied.aspx")
            End If
        End If

        MyBase.OnLoad(e)
    End Sub

End Class