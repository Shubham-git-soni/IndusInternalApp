﻿Imports System
Imports System.Web
Imports System.IO
Imports System.Web.Script.Serialization

Public Class FileUpload
    Implements IHttpHandler

    Public Sub ProcessRequest(ByVal context As HttpContext) Implements IHttpHandler.ProcessRequest
        context.Response.ContentType = "application/json"
        Dim serializer As New JavaScriptSerializer()
        Dim responseObject As Object

        Try
            If context.Request.Files.Count > 0 Then
                Dim file As HttpPostedFile = context.Request.Files(0)

                ' --- IMPORTANT: "Uploads" folder aapke project ke root mein hona chahiye ---
                Dim uploadFolder = context.Server.MapPath("~/Uploads/")
                If Not Directory.Exists(uploadFolder) Then
                    Directory.CreateDirectory(uploadFolder)
                End If

                ' Unique file name banayein
                Dim uniqueFileName = Guid.NewGuid().ToString() & "_" & Path.GetFileName(file.FileName)
                Dim serverFilePath = Path.Combine(uploadFolder, uniqueFileName)
                file.SaveAs(serverFilePath)

                ' Success response create karein
                responseObject = New With {
                    .success = True,
                    .message = "File uploaded successfully!",
                    .fileName = uniqueFileName, ' Yeh DB mein save hoga
                    .filePath = "/Uploads/" & uniqueFileName ' Yeh link banane ke liye
                }
                context.Response.Write(serializer.Serialize(responseObject))

            Else
                Throw New Exception("No file was received by the server.")
            End If
        Catch ex As Exception
            ' Error response create karein
            System.Diagnostics.Trace.WriteLine("File Upload Error (FileUpload.ashx): " & ex.Message)
            context.Response.StatusCode = 500 ' Internal Server Error
            responseObject = New With {
                .success = False,
                .message = "File could not be uploaded. " & ex.Message
            }
            context.Response.Write(serializer.Serialize(responseObject))
        End Try
    End Sub

    Public ReadOnly Property IsReusable() As Boolean Implements IHttpHandler.IsReusable
        Get
            Return False
        End Get
    End Property

End Class