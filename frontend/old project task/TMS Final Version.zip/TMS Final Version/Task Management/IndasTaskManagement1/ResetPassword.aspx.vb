﻿Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Security.Cryptography
Imports System.Text

Partial Class ResetPassword
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim token As String = Request.QueryString("token")

            If String.IsNullOrEmpty(token) Then
                lblMessage.Text = "❌ Invalid or missing reset token."
                btnReset.Enabled = False
                Return
            End If

            ' Optional: check if token is expired
            Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString
            Using conn As New SqlConnection(connStr)
                Dim cmd As New SqlCommand("SELECT COUNT(*) FROM Users WHERE ResetToken = @Token AND TokenExpiry > GETDATE()", conn)
                cmd.Parameters.AddWithValue("@Token", token)
                conn.Open()

                If Convert.ToInt32(cmd.ExecuteScalar()) = 0 Then
                    lblMessage.Text = "❌ Invalid or expired reset token."
                    btnReset.Enabled = False
                End If
            End Using
        End If
    End Sub

    Protected Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click
        Dim token As String = Request.QueryString("token")
        Dim newPassword As String = txtNewPassword.Text.Trim()
        Dim confirmPassword As String = txtConfirmPassword.Text.Trim()

        If newPassword = "" OrElse confirmPassword = "" Then
            lblMessage.Text = "❌ Please fill all fields."
            Return
        End If

        If newPassword <> confirmPassword Then
            lblMessage.Text = "❌ Passwords do not match."
            Return
        End If

        If Not IsStrongPassword(newPassword) Then
            lblMessage.Text = "❌ Password must be at least 8 characters and include uppercase, lowercase, digit, and special character."
            Return
        End If

        Dim hashedPassword As String = newPassword
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            conn.Open()

            Dim cmd As New SqlCommand("UPDATE Users SET PasswordHash = @PasswordHash, ResetToken = NULL, TokenExpiry = NULL WHERE ResetToken = @Token AND TokenExpiry > GETDATE()", conn)
            cmd.Parameters.AddWithValue("@PasswordHash", hashedPassword)
            cmd.Parameters.AddWithValue("@Token", token)

            Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

            If rowsAffected > 0 Then
                lblMessage.CssClass = "text-success"
                lblMessage.Text = "✅ Password reset successfully! Redirecting to login page..."

                btnReset.Enabled = False

                ' ✅ Redirect to Login.aspx after 3 seconds
                ClientScript.RegisterStartupScript(Me.GetType(), "Redirect", "setTimeout(function(){ window.location.href='Login.aspx'; }, 3000);", True)
            Else
                lblMessage.CssClass = "text-danger"
                lblMessage.Text = "❌ Invalid or expired reset token."
            End If
        End Using
    End Sub


    'Private Function GetHashedPassword(password As String) As String
    '    Using sha256 As SHA256 = SHA256.Create()
    '        Dim bytes As Byte() = Encoding.UTF8.GetBytes(password)
    '        Dim hashBytes As Byte() = sha256.ComputeHash(bytes)
    '        Return Convert.ToBase64String(hashBytes)
    '    End Using
    'End Function

    Private Function IsStrongPassword(password As String) As Boolean
        Dim pattern As String = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$"
        Return System.Text.RegularExpressions.Regex.IsMatch(password, pattern)
    End Function
End Class
