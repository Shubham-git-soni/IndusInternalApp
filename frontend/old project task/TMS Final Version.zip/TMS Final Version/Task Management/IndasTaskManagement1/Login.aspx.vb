﻿Imports System.Data.SqlClient
Imports System.Configuration

Partial Class Login
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        ' 🔐 Disable caching to block back button after logout
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))

        If Not IsPostBack Then

            ' ✅ Load email from cookie if available

            If Request.Cookies("UserEmail") IsNot Nothing Then
                txtEmail.Text = Request.Cookies("UserEmail").Value
                chkRememberMe.Checked = True
            End If

            ' ✅ Check timeout query string
            If Request.QueryString("timeout") = "1" Then
                lblError.ForeColor = Drawing.Color.Red
                lblError.Text = "Your session has expired. Please log in again."
                lblError.Visible = True
            End If

            If Request.QueryString("registered") = "1" Then
                lblError.ForeColor = Drawing.Color.Green
                lblError.Text = "Registration successful! Please login below."
            End If
        End If
    End Sub

    Protected Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        lblError.Text = "" ' Clear any previous message

        Dim email As String = txtEmail.Text.Trim()
        Dim password As String = txtPassword.Text.Trim()

        If email = "" Then
            lblError.Text = "Please enter your email."
            Return
        End If

        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            Dim cmd As New SqlCommand("
            SELECT PasswordHash, UserID, FullName, Role 
            FROM Users 
            WHERE Email = @Email AND IsActive = 1", conn)

            cmd.Parameters.AddWithValue("@Email", email)

            conn.Open()
            Dim reader As SqlDataReader = cmd.ExecuteReader()

            If reader.Read() Then
                Dim storedPassword As String = If(IsDBNull(reader("PasswordHash")), "", reader("PasswordHash").ToString())
                Dim enteredPassword As String = password

                Dim isLoginSuccess As Boolean = False

                ' ✅ Case 1: If DB password is NULL or empty → allow login only with email
                If storedPassword = "" Then
                    isLoginSuccess = True

                    ' ✅ Case 2: If DB password exists → compare with entered password 

                ElseIf storedPassword = enteredPassword Then
                    isLoginSuccess = True
                End If

                If isLoginSuccess Then


                    Dim userId As Integer = Convert.ToInt32(reader("UserID"))
                    Dim role As String = reader("Role").ToString().ToLower()
                    ' ✅ Login success
                    Session("UserID") = reader("UserID")
                    Session("FullName") = reader("FullName")
                    Session("Role") = role
                    ' ✅ Set session timeout (in minutes)
                    Session.Timeout = 60

                    reader.Close()

                    ' ✅ Remember Me logic
                    If chkRememberMe.Checked Then
                        Response.Cookies("UserEmail").Value = email
                        Response.Cookies("UserEmail").Expires = DateTime.Now.AddDays(30) ' 30 days
                    Else
                        Response.Cookies("UserEmail").Expires = DateTime.Now.AddDays(-1) ' remove cookie
                    End If


                    If role = "admin" Then

                        Response.Redirect("~/DashboardAdmin.aspx")

                    Else

                        ' For all other users, first check for specific permissions

                        Dim allowedPages As List(Of String) = DataAccess.GetUserPermissions(userId)



                        If allowedPages IsNot Nothing AndAlso allowedPages.Count > 0 Then

                            ' --- CASE 1: User HAS specific permissions set by the admin ---

                            Dim firstPage As String = allowedPages.OrderBy(Function(p) If(p.ToLower().Contains("dashboard"), 0, 1)).FirstOrDefault()



                            If Not String.IsNullOrEmpty(firstPage) Then

                                Response.Redirect("~/" & firstPage)

                            Else

                                lblError.Text = "No valid landing page found in your permissions."

                                lblError.Visible = True

                            End If

                        Else

                            ' --- CASE 2: User has NO specific permissions, FALLBACK TO ROLE ---

                            Select Case role

                                Case "developer"

                                    Response.Redirect("~/DashboardDeveloper.aspx")

                                Case "tester"

                                    Response.Redirect("~/DashboardTester.aspx")

                                Case "support"

                                    Response.Redirect("~/AddPoint.aspx")

                                    Response.Redirect("~/ManagePoint.aspx")

                                Case Else

                                    lblError.Text = "Your role has no default page and no permissions are set."

                                    lblError.Visible = True

                            End Select

                        End If

                    End If

                Else
                    ' ❌ Wrong password
                    lblError.Text = "Incorrect password. Please try again."
                    lblError.Visible = True
                    reader.Close()
                End If
            Else
                ' ❌ Email not found or user is inactive
                lblError.Text = "Account not found or inactive."
                lblError.Visible = True
                reader.Close()
            End If
        End Using
    End Sub

    ' 🔒 Future ke liye (jab  passwords dal denge):
    ' Simply uncomment Case 2 aur comment Case 1
    ' Iska matlab login sirf email + password match pe hoga
End Class
