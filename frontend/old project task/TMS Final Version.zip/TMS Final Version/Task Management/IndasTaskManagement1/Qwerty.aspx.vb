﻿Imports System.Data.SqlClient
Imports System.Configuration
Imports System.Security.Cryptography
Imports System.Text
Imports System.Net.Mail
Imports System.Net


Partial Class Register
    Inherits System.Web.UI.Page

    Protected Sub btnRegister_Click(sender As Object, e As EventArgs) Handles btnRegister.Click
        Dim fullName As String = txtFullName.Text.Trim()
        Dim email As String = txtEmail.Text.Trim()
        Dim password As String = txtPassword.Text
        Dim role As String = ddlRole.SelectedValue

        lblMessage.EnableViewState = True
        lblMessage.Visible = True

        If fullName = "" OrElse email = "" OrElse password = "" OrElse role = "" Then
            lblMessage.Text = "All fields are required."
            lblMessage.ForeColor = Drawing.Color.Red
            Return
        End If

        If Not IsStrongPassword(password) Then
            lblMessage.Text = "Password must be at least 8 characters long and include uppercase, lowercase, digit, and special character."
            lblMessage.ForeColor = Drawing.Color.Red
            Return
        End If

        Dim hashedPassword As String = password
        Dim token As String = Guid.NewGuid().ToString()
        Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

        Using conn As New SqlConnection(connStr)
            conn.Open()

            Dim checkCmd As New SqlCommand("SELECT COUNT(*) FROM Users WHERE Email = @Email", conn)
            checkCmd.Parameters.AddWithValue("@Email", email)
            Dim count As Integer = Convert.ToInt32(checkCmd.ExecuteScalar())

            If count > 0 Then
                lblMessage.Text = "User already registered with this email."
                lblMessage.ForeColor = Drawing.Color.Red
                Return
            End If
            'IMP : Email verfield change 0 to 1.
            Dim cmd As New SqlCommand("INSERT INTO Users (FullName, Email, PasswordHash, Role, IsActive, EmailVerified, EmailToken) 
                                   VALUES (@FullName, @Email, @PasswordHash, @Role, 1, 1, @Token)", conn)
            cmd.Parameters.AddWithValue("@FullName", fullName)
            cmd.Parameters.AddWithValue("@Email", email)
            cmd.Parameters.AddWithValue("@PasswordHash", hashedPassword)
            cmd.Parameters.AddWithValue("@Role", role)
            cmd.Parameters.AddWithValue("@Token", token)
            cmd.ExecuteNonQuery()

            ' ✅ Send verification email
            SendVerificationEmail(email, token)

            ' Set success message
            lblMessage.ForeColor = Drawing.Color.Green
            lblMessage.Text = "✅ Registration successful! Please check your email to verify your account."


            ' Clear after setting message
            txtFullName.Text = ""
            txtEmail.Text = ""
            txtPassword.Text = ""
            ddlRole.SelectedIndex = 0

        End Using
    End Sub



    Private Sub SendVerificationEmail(email As String, token As String)
        Try
            Dim verifyUrl As String = "https://localhost:44365/VerifyEmail.aspx?token=" & token
            Dim body As String = "Hello,<br/><br/>Please verify your email by clicking the link below:<br/>" &
                         "<a href='" & verifyUrl & "'>Click here to verify</a><br/><br/>Thank you!"

            Dim smtp As New SmtpClient("smtp.gmail.com", 587)
            smtp.EnableSsl = True

            Dim senderEmail As String = ConfigurationManager.AppSettings("SenderEmail")
            Dim senderPassword As String = ConfigurationManager.AppSettings("SenderPassword")

            smtp.Credentials = New NetworkCredential(senderEmail, senderPassword)

            Dim message As New MailMessage()
            message.From = New MailAddress(senderEmail, "Indas Task Management")
            message.To.Add(email)
            message.Subject = "Email Verification - Indas Task"
            message.Body = body
            message.IsBodyHtml = True

            smtp.Send(message)
        Catch ex As Exception
            lblMessage.Text = "❌ Failed to send verification email: " & ex.Message
        End Try
    End Sub

    'Private Function GetHashedPassword(password As String) As String
    '    Using sha256 As SHA256 = SHA256.Create()
    '        Dim bytes As Byte() = Encoding.UTF8.GetBytes(password)
    '        Dim hashBytes As Byte() = sha256.ComputeHash(bytes)
    '        Return Convert.ToBase64String(hashBytes)
    '    End Using
    'End Function
    Private Function IsStrongPassword(password As String) As Boolean
        ' Minimum 8 characters, at least one uppercase, one lowercase, one digit, one special character
        Dim pattern As String = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[\W_]).{8,}$"
        Return System.Text.RegularExpressions.Regex.IsMatch(password, pattern)
    End Function

End Class
