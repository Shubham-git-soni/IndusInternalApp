﻿Imports System.Web.Services

Public Class TimeReport
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Step 1: Check if session exists
        If Session("UserID") Is Nothing Then
            Response.Redirect("Landing.aspx")
            Return
        End If

        ' Step 2: Safely check role
        Dim role As String = If(Session("Role"), "").ToString().ToLower()
        Dim userId As Integer = Convert.ToInt32(Session("UserID"))

        ' Step 3: Admin gets full access
        If role = "admin" Then
            Return
        End If

        ' Step 4: Non-admin users permission check
        Dim allowedPages As List(Of String) = DataAccess.GetUserPermissions(userId)
        If allowedPages Is Nothing OrElse Not allowedPages.Contains("TimeReport.aspx", StringComparer.OrdinalIgnoreCase) Then
            Response.Redirect("Landing.aspx")
            Return
        End If
    End Sub




    <WebMethod()>
    Public Shared Function GetReportData() As List(Of TimeReportData)
        Try
            Return DataAccess.GetTimeReportData()
        Catch ex As Exception
            ' In case of an error, return an empty list
            ' You can also log the error here
            Return New List(Of TimeReportData)()
        End Try
    End Function

End Class