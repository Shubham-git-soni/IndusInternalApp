﻿Imports System.Configuration
Imports System.Data.SqlClient
Imports System.Web.Services
Imports System.Web.UI.WebControls ' For ListItem

Public Class DashboardAdmin
    Inherits BasePage


    Protected litScript As Literal
    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
        Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches)

        If Session("UserID") Is Nothing Then
            Response.Redirect("Landing.aspx")
        End If

        Dim userCanEdit As Boolean = False
        If Session("Role") IsNot Nothing AndAlso Session("Role").ToString() = "admin" Then
            userCanEdit = True
        End If

        Dim script As String = $"<script type='text/javascript'>var canUserEditQueue = {userCanEdit.ToString().ToLower()};</script>"
        litScript.Text = script

        If Not IsPostBack Then
            txtFromDate.Text = DateTime.Today.ToString("yyyy-MM-dd")

            txtToDate.Text = DateTime.Today.ToString("yyyy-MM-dd")

            LoadDevelopers()
            LoadCustomers()
            Filter_Changed(Nothing, Nothing) ' Page load par filters ke hisaab se data load karein
        End If
    End Sub

    <WebMethod()>
    Public Shared Sub Logout()
        HttpContext.Current.Session.Clear()
        HttpContext.Current.Session.Abandon()
    End Sub

    Private Sub LoadDashboardStats(Optional fromDate As Nullable(Of DateTime) = Nothing,
                   Optional toDate As Nullable(Of DateTime) = Nothing,
                   Optional developerId As Integer = 0,
                   Optional customerId As Integer = 0)

        Dim queryBuilder As New System.Text.StringBuilder()
        queryBuilder.Append("
SELECT
    COUNT(*) AS TotalPoints,
    SUM(CASE WHEN Status NOT IN ('PendingQC', 'In-Testing', 'Testing-Completed', 'Closed') THEN 1 ELSE 0 END) AS OpenTasks,
    SUM(CASE WHEN Status = 'Queue' THEN 1 ELSE 0 END) AS Pending,
    SUM(CASE WHEN Status = 'Assigned' THEN 1 ELSE 0 END) AS Assigned,
    SUM(CASE WHEN Status = 'In Progress' THEN 1 ELSE 0 END) AS InProgress,
    SUM(CASE WHEN Status = 'DevCompleted' THEN 1 ELSE 0 END) AS DevCompleted,
    SUM(CASE WHEN Status = 'In-Testing' THEN 1 ELSE 0 END) AS InTesting,
    SUM(CASE WHEN Status = 'PendingQC' THEN 1 ELSE 0 END) AS PendingQC,
    SUM(CASE WHEN Status = 'PendingSupport' THEN 1 ELSE 0 END) AS PendingSupport,
    SUM(CASE WHEN Status = 'SupportVerified' THEN 1 ELSE 0 END) AS SupportVerified,
    SUM(CASE WHEN Status = 'PendingMerge' THEN 1 ELSE 0 END) AS PendingMerge,
    SUM(CASE WHEN Status = 'Reopened' THEN 1 ELSE 0 END) AS Reopened,
    SUM(CASE WHEN Status = 'Testing-Completed' THEN 1 ELSE 0 END) AS TestingCompleted,
    SUM(CASE WHEN Status = 'Hold' THEN 1 ELSE 0 END) AS Hold,
    SUM(CASE WHEN Status = 'Reject' THEN 1 ELSE 0 END) AS Reject,
    SUM(CASE WHEN Status IN ('Completed', 'Closed') THEN 1 ELSE 0 END) AS Completed,
    SUM(CASE 
        WHEN TotalTimeSpent > ExpectedMinutes AND ExpectedMinutes IS NOT NULL AND ExpectedMinutes > 0
        THEN 1 
        ELSE 0 
    END) AS DelayedTasks
FROM Points
WHERE 1=1 ")

        If fromDate.HasValue AndAlso toDate.HasValue Then
            queryBuilder.Append(" AND (CONVERT(DATE, DateCreated) BETWEEN @FromDate AND @ToDate)")
        End If
        If developerId > 0 Then queryBuilder.Append(" AND AssignedToID = @DeveloperID")
        If customerId > 0 Then queryBuilder.Append(" AND CustomerID = @CustomerID")

        Using conn As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
            Using cmd As New SqlCommand(queryBuilder.ToString(), conn)
                cmd.CommandTimeout = 120
                If fromDate.HasValue AndAlso toDate.HasValue Then
                    cmd.Parameters.AddWithValue("@FromDate", fromDate.Value.Date)
                    cmd.Parameters.AddWithValue("@ToDate", toDate.Value.Date)
                End If
                If developerId > 0 Then cmd.Parameters.AddWithValue("@DeveloperID", developerId)
                If customerId > 0 Then cmd.Parameters.AddWithValue("@CustomerID", customerId)

                conn.Open()
                Using reader As SqlDataReader = cmd.ExecuteReader()
                    If reader.Read() Then
                        litTotalPoints.Text = If(reader.IsDBNull(reader.GetOrdinal("TotalPoints")), "0", reader("TotalPoints").ToString())
                        litOpenTasks.Text = If(reader.IsDBNull(reader.GetOrdinal("OpenTasks")), "0", reader("OpenTasks").ToString())
                        litPending.Text = If(reader.IsDBNull(reader.GetOrdinal("Pending")), "0", reader("Pending").ToString())
                        litAssigned.Text = If(reader.IsDBNull(reader.GetOrdinal("Assigned")), "0", reader("Assigned").ToString())
                        litInProcess.Text = If(reader.IsDBNull(reader.GetOrdinal("InProgress")), "0", reader("InProgress").ToString())
                        litDevCompleted.Text = If(reader.IsDBNull(reader.GetOrdinal("DevCompleted")), "0", reader("DevCompleted").ToString())
                        litInTesting.Text = If(reader.IsDBNull(reader.GetOrdinal("InTesting")), "0", reader("InTesting").ToString())
                        litPendingQC.Text = If(reader.IsDBNull(reader.GetOrdinal("PendingQC")), "0", reader("PendingQC").ToString())
                        litPendingSupport.Text = If(reader.IsDBNull(reader.GetOrdinal("PendingSupport")), "0", reader("PendingSupport").ToString())
                        litSupportVerified.Text = If(reader.IsDBNull(reader.GetOrdinal("SupportVerified")), "0", reader("SupportVerified").ToString())
                        litPendingMerge.Text = If(reader.IsDBNull(reader.GetOrdinal("PendingMerge")), "0", reader("PendingMerge").ToString())
                        litCompleted.Text = If(reader.IsDBNull(reader.GetOrdinal("Completed")), "0", reader("Completed").ToString())
                        litReopened.Text = If(reader.IsDBNull(reader.GetOrdinal("Reopened")), "0", reader("Reopened").ToString())
                        litTestingCompleted.Text = If(reader.IsDBNull(reader.GetOrdinal("TestingCompleted")), "0", reader("TestingCompleted").ToString())
                        LitHold.Text = If(reader.IsDBNull(reader.GetOrdinal("Hold")), "0", reader("Hold").ToString())
                        LitReject.Text = If(reader.IsDBNull(reader.GetOrdinal("Reject")), "0", reader("Reject").ToString())
                        litDelayed.Text = If(reader.IsDBNull(reader.GetOrdinal("DelayedTasks")), "0", reader("DelayedTasks").ToString())
                    End If
                End Using
            End Using
        End Using
    End Sub
    Private Sub LoadDevelopers()
        Dim developers As List(Of UserData) = DataAccess.GetUsers("Developer")
        ddlDevelopers.DataSource = developers
        ddlDevelopers.DataTextField = "FullName"
        ddlDevelopers.DataValueField = "UserID"
        ddlDevelopers.DataBind()
        ddlDevelopers.Items.Insert(0, New ListItem("-- All Developers --", "0"))
    End Sub

    Private Sub LoadCustomers()
        Dim customers As List(Of Object) = DataAccess.GetCustomers()
        ddlCustomers.DataSource = customers
        ddlCustomers.DataTextField = "CustomerName"
        ddlCustomers.DataValueField = "CustomerID"
        ddlCustomers.DataBind()
        ddlCustomers.Items.Insert(0, New ListItem("-- All Customers --", "0"))
    End Sub

    Protected Sub Filter_Changed(sender As Object, e As EventArgs)
        Dim fromDate As Nullable(Of DateTime) = Nothing
        Dim toDate As Nullable(Of DateTime) = Nothing

        Dim tempFromDate As DateTime
        If DateTime.TryParse(txtFromDate.Text, tempFromDate) Then
            fromDate = tempFromDate
        End If

        Dim tempToDate As DateTime
        If DateTime.TryParse(txtToDate.Text, tempToDate) Then
            toDate = tempToDate
        End If

        Dim selectedDeveloperId As Integer = Convert.ToInt32(ddlDevelopers.SelectedValue)
        Dim selectedCustomerId As Integer = Convert.ToInt32(ddlCustomers.SelectedValue)

        LoadDashboardStats(fromDate, toDate, selectedDeveloperId, selectedCustomerId)

        Dim script As String = "
        if (window.innerWidth <= 992) { 
            var filterContainer = jQuery('.filter-container');
            if (!filterContainer.is(':visible')) {
                filterContainer.show();
                var button = jQuery('#mobileFilterToggle');
                var icon = button.find('i');
                icon.removeClass('fa-filter').addClass('fa-times');
                button.contents().filter(function () { return this.nodeType === 3; }).first().replaceWith(' Hide Filters');
            }
        }
    "
        ScriptManager.RegisterStartupScript(Me, Me.GetType(), "KeepFiltersOpenAfterPostback", script, True)
    End Sub

    <WebMethod()>
    Public Shared Function GetKpiGridData(status As String, fromDateString As String, toDateString As String, developerId As Integer, customerId As Integer) As List(Of PointData)
        Try
            Dim fromDate As Nullable(Of DateTime) = Nothing
            If Not String.IsNullOrEmpty(fromDateString) Then
                Dim tempDate As DateTime
                If DateTime.TryParse(fromDateString, tempDate) Then fromDate = tempDate
            End If

            Dim toDate As Nullable(Of DateTime) = Nothing
            If Not String.IsNullOrEmpty(toDateString) Then
                Dim tempDate As DateTime
                If DateTime.TryParse(toDateString, tempDate) Then toDate = tempDate
            End If

            Return DataAccess.GetFilteredPointsForGrid(status, fromDate, toDate, developerId, customerId)

        Catch ex As Exception
            Dim errorList As New List(Of PointData)()
            errorList.Add(New PointData With {
                .PointID = -1,
                .Title = "SERVER ERROR: " & ex.Message,
                .CustomerName = "Error",
                .Status = "Failed"
            })
            Return errorList
        End Try
    End Function

    Protected Sub btnShowAll_Click(sender As Object, e As EventArgs)
        txtFromDate.Text = ""
        txtToDate.Text = ""
        ddlDevelopers.SelectedIndex = 0
        ddlCustomers.SelectedIndex = 0
        Filter_Changed(sender, e)
    End Sub

    <WebMethod()>
    Public Shared Function GetDevelopersForDropdown() As List(Of UserData)
        Return DataAccess.GetAssignableUsers()
    End Function


    <WebMethod()>
    Public Shared Function AssignPointFromQueue(pointId As Integer, developerId As Integer, expectedDate As DateTime) As Boolean
        Try
            Dim adminId As Integer = Convert.ToInt32(HttpContext.Current.Session("UserID"))
            Return DataAccess.CreateTicketAndAssignSinglePoint(pointId, developerId, adminId, expectedDate)
        Catch ex As Exception

            Return False
        End Try
    End Function

    <WebMethod()>
    Public Shared Function AssignPointFromQueueBulk(tickets As List(Of Object)) As Boolean
        Try
            Using con As New SqlConnection(ConfigurationManager.ConnectionStrings("MyConn").ConnectionString)
                con.Open()
                For Each t In tickets
                    Dim pointId As Integer = t("PointID")
                    Dim devId As Integer = t("AssignedToID")
                    Dim expectedDate As DateTime = t("ExpectedDate")

                    Dim cmd As New SqlCommand("
                    UPDATE Points 
                    SET AssignedToID=@DevId, ExpectedDate=@ExpDate, Status='Assigned'
                    WHERE PointID=@PID", con)

                    cmd.Parameters.AddWithValue("@PID", pointId)
                    cmd.Parameters.AddWithValue("@DevId", devId)
                    cmd.Parameters.AddWithValue("@ExpDate", expectedDate)

                    cmd.ExecuteNonQuery()
                Next
            End Using
            Return True
        Catch ex As Exception
            Return False
        End Try
    End Function

End Class