﻿document.addEventListener("DOMContentLoaded", function () {
    const toggleBtn = document.getElementById("toggleSidebar");
    const sidebar = document.getElementById("sidebar");
    const mainContent = document.getElementById("mainContent");
    const body = document.body;

    // Function to apply layout based on current window width
    function applyLayoutBasedOnWidth() {
        if (window.innerWidth <= 768) {
            // Mobile View
            // Ensure desktop-specific classes are removed
            sidebar.classList.remove("closed");
            mainContent.classList.remove("full");

            // Set main content margin to 0 for mobile (always full width)
            mainContent.style.marginLeft = "0px";

            // If sidebar is currently open on mobile, prevent body scroll
            if (sidebar.classList.contains("active")) {
                body.classList.add("sidebar-open");
            } else {
                body.classList.remove("sidebar-open");
            }

            // The sidebar is hidden by default via CSS on mobile, shown by .active
        } else {
            // Desktop View
            // Ensure mobile-specific active class is removed
            sidebar.classList.remove("active");
            body.classList.remove("sidebar-open"); // Ensure body scroll is normal

            // Determine desktop layout based on 'closed' and 'full' classes
            if (sidebar.classList.contains("closed")) {
                mainContent.style.marginLeft = "0px"; // Sidebar closed, main content full
            } else {
                mainContent.style.marginLeft = "220px"; // Sidebar open, main content offset
            }
        }
    }

    // Apply layout on initial page load
    applyLayoutBasedOnWidth();

    // Event listener for the toggle button
    toggleBtn.addEventListener("click", function () {
        if (window.innerWidth <= 768) {
            // Mobile: Toggle the 'active' class to show/hide the sidebar
            sidebar.classList.toggle("active");
            if (sidebar.classList.contains("active")) {
                body.classList.add("sidebar-open"); // Prevent main content scroll
            } else {
                body.classList.remove("sidebar-open");
            }
        } else {
            // Desktop: Toggle 'closed' for sidebar and 'full' for main content
            sidebar.classList.toggle("closed");
            mainContent.classList.toggle("full"); // This will make main content take full width

            // Manually set margin-left based on 'full' class for smooth transition consistency
            if (mainContent.classList.contains("full")) {
                mainContent.style.marginLeft = "0px";
            } else {
                mainContent.style.marginLeft = "220px";
            }
        }
    });

    // Event listener for window resize (e.g., rotating tablet, resizing browser window)
    window.addEventListener("resize", function () {
        applyLayoutBasedOnWidth();
    });

    // Handle clicks outside the sidebar to close it on mobile
    document.addEventListener("click", function (event) {
        // Check if it's a mobile view, sidebar is active, and click is outside sidebar AND toggle button
        if (window.innerWidth <= 768 && sidebar.classList.contains("active") &&
            !sidebar.contains(event.target) && !toggleBtn.contains(event.target)) {
            sidebar.classList.remove("active");
            body.classList.remove("sidebar-open"); // Re-enable body scroll
        }
    });
});
