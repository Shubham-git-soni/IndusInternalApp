﻿document.addEventListener("DOMContentLoaded", function () {
    var msg = document.getElementById("lblMessage");

    if (msg && msg.textContent.trim() !== "") {
        msg.style.display = "block";
        msg.style.opacity = "1";
        msg.style.transition = "opacity 0.5s ease-in-out";

        setTimeout(function () {
            msg.style.opacity = "0";
        }, 4000);
    }
});
