﻿(function () {
    for (let i = 0; i < 10; i++) {
        history.pushState(null, "", location.href);
    }

    window.onload = function () {
        history.pushState(null, "", location.href);
    };

    window.onpopstate = function () {
        alert("🔒 Back navigation is disabled.");
        history.pushState(null, "", location.href);
    };
})();
