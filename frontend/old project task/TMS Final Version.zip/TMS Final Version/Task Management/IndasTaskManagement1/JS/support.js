﻿document.querySelectorAll('.notification-item').forEach(item => {
    item.addEventListener('click', () => {
        if (item.classList.contains('unread')) {
            item.classList.remove('unread');
            item.classList.add('read');
        }
    });
});