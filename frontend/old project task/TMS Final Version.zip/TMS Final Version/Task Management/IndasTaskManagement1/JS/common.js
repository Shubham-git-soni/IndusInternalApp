﻿function getStatusTemplate(container, options) {
    var value = options.value || "Unknown";
    var className = {
        "Queue": "status-queue",
        "Open": "status-open",
        "In Progress": "status-inprogress",
        "Completed": "status-completed",
        "DevCompleted":"status-devcompleted",
        "PendingQC": "status-pendingqc",
        "Closed": "status-closed",
        "ReOpened": "status-reopened",
        "PendingSupport": "status-pendingsupport",
        "SupportVerified": "status-supportverified",
        "In-Testing": "status-intesting",
        "Assigned": "status-assigned",
        "Testing-Completed": "status-testingcompleted" ,
        "Hold": "status-hold",
        "Reject": "status-reject",
        "Delayed": "status-delayed",
        "PendingMerge":"status-pendingmerge",
    }[value] || "status-badge";

    $("<span>")
        .addClass("status-badge " + className)
        .text(value)
        .appendTo(container);
}

function getPriorityTemplate(container, options) {
    var value = options.value || "Medium";
    var className = {
        "High": "priority-high",
        "Medium": "priority-medium",
        "Low": "priority-low"
    }[value] || "priority-badge";

    $("<span>")
        .addClass("priority-badge " + className)
        .text(value)
        .appendTo(container);
}

function getComplexityTemplate(container, options) {
    var value = options.value || "Moderate";
    var className = {
        "Simple": "complexity-simple",
        "Moderate": "complexity-moderate",
        "Complex": "complexity-complex"
    }[value] || "complexity-badge";

    $("<span>")
        .addClass("complexity-badge " + className)
        .text(value)
        .appendTo(container);
}

function getCycleStatusTemplate(container, options) {
    var value = options.value || "Unknown";
    var className = {
        "Closed": "cyclestatus-closed",
        "ReOpened": "cyclestatus-reopened",
        "Verified": "cyclestatus-verified",
        "Failed": "cyclestatus-failed",
        "SentToSupport":"cyclestus-SentToSupport",
        "SentToQC":"cyclestatus-senttoqc"
    }[value] || "cyclestatus-default";

    $("<span>")
        .addClass("cyclestatus-badge " + className)
        .text(value)
        .appendTo(container);
}



