﻿Imports System.Data.SqlClient
Imports System.Configuration

Partial Class VerifyEmail
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(sender As Object, e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim token As String = Request.QueryString("token")

            If String.IsNullOrEmpty(token) Then
                lblMessage.Text = "❌ Invalid verification link."
                Return
            End If

            Dim connStr As String = ConfigurationManager.ConnectionStrings("MyConn").ConnectionString

            Using conn As New SqlConnection(connStr)
                conn.Open()

                Dim cmd As New SqlCommand("UPDATE Users SET EmailVerified = 1, EmailToken = NULL WHERE EmailToken = @Token", conn)
                cmd.Parameters.AddWithValue("@Token", token)

                Dim rowsAffected As Integer = cmd.ExecuteNonQuery()

                If rowsAffected > 0 Then
                    lblMessage.ForeColor = Drawing.Color.Green
                    lblMessage.Text = "✅ Email verified successfully! Redirecting to login..."
                    ClientScript.RegisterStartupScript(Me.GetType(), "Redirect", "setTimeout(function(){ window.location.href = 'Login.aspx'; }, 3000);", True)
                Else
                    lblMessage.ForeColor = Drawing.Color.Red
                    lblMessage.Text = "❌ Verification failed or already used."
                End If
            End Using
        End If
    End Sub
End Class
