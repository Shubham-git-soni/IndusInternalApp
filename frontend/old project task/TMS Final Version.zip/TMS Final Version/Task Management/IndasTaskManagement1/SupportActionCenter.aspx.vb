﻿Imports System.Web.Services
Imports IndasTaskManagement1.DataAccess

Partial Public Class SupportActionCenter
    Inherits BasePage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ' Prevent caching
        Response.Cache.SetCacheability(HttpCacheability.NoCache)
        Response.Cache.SetNoStore()
        Response.Cache.SetExpires(DateTime.UtcNow.AddMinutes(-1))
        Response.Cache.SetRevalidation(HttpCacheRevalidation.AllCaches)

        ' Session validation
        If Session("UserID") Is Nothing Then
            Response.Redirect("Landing.aspx")
        End If
    End Sub

    ' Get points pending for support (PendingSupport status only)
    ' SupportActionCenter.aspx.vb

    <WebMethod()>
    Public Shared Function GetSupportQueue() As List(Of PointData)
        Dim currentUserId As Integer = CInt(HttpContext.Current.Session("UserID"))
        Return DataAccess.GetPointsForSupportDashboard(currentUserId)
    End Function

    ' Get point details for action center
    <WebMethod()>
    Public Shared Function GetPointForActionCenter(pointId As Integer) As PointData
        Return DataAccess.GetPointDetailsById(pointId)
    End Function

    ' Start support timer
    <WebMethod()>
    Public Shared Function StartSupportTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "This ticket is already closed."}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            Dim result = DataAccess.StartSupportTimer(pointId, userId)
            Return result
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Complete support timer
    <WebMethod()>
    Public Shared Function CompleteSupportTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "Ticket is closed"}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            Return DataAccess.CompleteSupportTimer(pointId, userId)
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Pause support timer
    <WebMethod()>
    Public Shared Function PauseSupportTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "Ticket is closed"}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            Return DataAccess.PauseSupportTimer(pointId, userId)
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Resume support timer
    <WebMethod()>
    Public Shared Function ResumeSupportTimer(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "Ticket is closed"}
            End If

            Dim userId As Integer = HttpContext.Current.Session("UserID")
            Return DataAccess.ResumeSupportTimer(pointId, userId)
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Send to QC (Tester)
    <WebMethod()>
    Public Shared Function SendToQC(pointId As Integer, supportRemark As String) As Object
        Try
            Dim currentStatus As String = DataAccess.GetPointStatus(pointId)

            If currentStatus = "Closed" Then
                Return New With {.success = False, .message = "This point is already closed."}
            End If

            Dim supportId As Integer = HttpContext.Current.Session("UserID")

            ' Update point status to PendingQC
            Dim updated = DataAccess.UpdatePointStatusAndDate(pointId, "PendingQC", "DateSentToQC", DateTime.Now)

            If updated Then
                ' Save support remark and update history
                DataAccess.UpdateSupportHistoryCycle(pointId, supportId, supportRemark, "SentToQC")
                DataAccess.ResetTesterFieldsForNewQCCycle(pointId)
                DataAccess.ResetSupportFieldsForNewCycle(pointId)

                ' Send email to testers
                Dim testers As List(Of UserData) = DataAccess.GetUsersByRole("tester")
                For Each tester In testers
                    Dim htmlBody As String = $"<html>
        <body style='font-family: Arial, sans-serif;'>
            <p>Dear Tester,</p>
            <p>A new Point has been <strong>sent for QC from Support</strong>.</p>
            <p><strong>Point ID:</strong> {pointId}</p>
            <p>Please login to the system and proceed with testing.</p>
            <br/>
            <p>Regards,<br/>Indas Task Management System</p>
        </body>
       </html>"
                    'EmailHelper.SendEmail(tester.Email, "New Point Assigned for QC", htmlBody)
                Next

                Return New With {.success = True, .message = "Point sent to QC successfully."}
            Else
                Return New With {.success = False, .message = "Failed to update status."}
            End If
        Catch ex As Exception
            Return New With {.success = False, .message = "Error: " & ex.Message}
        End Try
    End Function

    ' Reopen for developer
    <WebMethod()>
    Public Shared Function ReopenForDeveloper(pointId As Integer, supportRemark As String) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "This ticket is already closed."}
            End If
            Dim currentStatus As String = DataAccess.GetPointStatus(pointId)
            If currentStatus = "ReOpened" Then
                Return New With {.success = False, .message = "This ticket has already been reopened."}
            End If

            Dim supportId As Integer = CInt(HttpContext.Current.Session("UserID"))
            DataAccess.UpdateSupportHistoryCycle(pointId, supportId, supportRemark, "ReOpened")

            ' --- NOTIFICATION LOGIC START ---
            Dim pointDetails = DataAccess.GetPointDetailsById(pointId)
            If pointDetails IsNot Nothing AndAlso pointDetails.AssignedToID.HasValue Then
                Dim supportName As String = HttpContext.Current.Session("FullName").ToString()
                Dim message As String = $"Point #{pointId} has been REOPENED by support ({supportName}). Please review."
                Dim url As String = $"~/DashboardDeveloper.aspx?pointId={pointId}"
                DataAccess.CreateNotification(pointDetails.AssignedToID.Value, message, url)
            End If
            ' --- NOTIFICATION LOGIC END ---

            Dim success As Boolean = DataAccess.ReopenPointFromSupport(pointId)
            If success Then
                Return New With {.success = True, .message = "Ticket successfully reopened for developer."}
            Else
                Return New With {.success = False, .message = "Failed to update point status in the database."}
            End If
        Catch ex As Exception
            Return New With {.success = False, .message = "An error occurred: " & ex.Message}
        End Try
    End Function

    ' Save support remark 
    <WebMethod()>
    Public Shared Function SaveSupportRemark(pointId As Integer, remark As String) As Boolean
        Return DataAccess.UpdateSupportRemark(pointId, remark)
    End Function

    ' Get point history
    <WebMethod()>
    Public Shared Function GetPointHistoryForGrid(pointId As Integer) As List(Of PointHistoryData)
        Return DataAccess.GetPointHistory(pointId)
    End Function

    ' Get attachments
    <WebMethod()>
    Public Shared Function GetAttachments(pointId As Integer) As List(Of AttachmentData)
        Return DataAccess.GetAllAttachmentsForPoint(pointId)
    End Function


    ' Yeh method FileUpload.ashx se upload hui file ko PointID se link karega.
    <WebMethod>
    Public Shared Function AddAttachmentToPoint(pointId As Integer, attachment As AttachmentInfo) As Object
        Try
            Dim uploadedById As Integer = HttpContext.Current.Session("UserID")
            ' Hum DataAccess ke existing function ko use karke record insert karenge.
            DataAccess.InsertAttachment(pointId, attachment.fileName, attachment.filePath, uploadedById)
            Return New With {.success = True, .message = "Attachment successfully link ho gaya."}
        Catch ex As Exception
            Return New With {.success = False, .message = "Attachment link nahi ho paya: " & ex.Message}
        End Try
    End Function

    ' Yeh method attachment ko delete karega.
    <WebMethod>
    Public Shared Function DeleteExistingAttachment(attachmentId As Integer) As Boolean
        Try
            Return DataAccess.DeleteAttachmentById(attachmentId)
        Catch ex As Exception
            ' Aap yahan error log kar sakte hain
            Return False
        End Try
    End Function



    <WebMethod()>
    Public Shared Function MarkAsSupportVerified(pointId As Integer) As Object
        Try
            If DataAccess.IsTicketClosed(pointId) Then
                Return New With {.success = False, .message = "This ticket is already closed and cannot be modified."}
            End If

            ' --- FIX START ---

            ' Step 1: Current user ID aur remark haasil karein
            Dim supportId As Integer = CInt(HttpContext.Current.Session("UserID"))
            Dim pointDetailsForRemark = DataAccess.GetPointDetailsById(pointId)
            Dim supportRemark As String = If(pointDetailsForRemark IsNot Nothing, pointDetailsForRemark.SupportRemark, "")

            ' Step 2: History table mein support ka saara data save karein (YAHI MISSING THA)
            ' CycleStatus ko "SupportVerified" set karein
            DataAccess.UpdateSupportHistoryCycle(pointId, supportId, supportRemark, "SupportVerified")

            ' Step 3: Points table se timer fields ko reset karein taaki agle cycle ke liye taiyaar rahe
            DataAccess.ResetSupportFieldsForNewCycle(pointId)

            ' Step 4: Ab point ka status update karein aur verification date set karein
            Dim success As Boolean = DataAccess.UpdatePointStatusAndDate(pointId, "SupportVerified", "DateSupportVerified", DateTime.Now)

            ' --- FIX END ---

            If success Then
                ' --- NOTIFICATION LOGIC START ---
                Dim pointDetails = DataAccess.GetPointDetailsById(pointId)
                If pointDetails IsNot Nothing AndAlso pointDetails.AssignedToID.HasValue Then
                    Dim supportName As String = HttpContext.Current.Session("FullName").ToString()
                    Dim message As String = $"Your work on Point #{pointId} has been verified by {supportName}. It's ready for merge request."
                    Dim url As String = $"~/DashboardDeveloper.aspx?pointId={pointId}"
                    DataAccess.CreateNotification(pointDetails.AssignedToID.Value, message, url)
                End If
                ' --- NOTIFICATION LOGIC END ---

                Return New With {.success = True, .message = "Status updated successfully."}
            Else
                Return New With {.success = False, .message = "Failed to update the status in the database."}
            End If
        Catch ex As Exception
            Return New With {.success = False, .message = "An error occurred: " & ex.Message}
        End Try
    End Function

End Class
