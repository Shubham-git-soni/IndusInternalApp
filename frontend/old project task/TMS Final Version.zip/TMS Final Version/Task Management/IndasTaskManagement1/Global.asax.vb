﻿Imports System.Timers
Imports System.Configuration

Public Class Global_asax
    Inherits System.Web.HttpApplication

    ' 🔹 Config values ko public shared variables bana rahe hain (so AutoWhatsAppReport module use kar )
    Public Shared WhatsFlySecret As String
    Public Shared WhatsFlyAccount As String
    Public Shared WhatsFlyApiUrl As String
    Public Shared ReportMobile As String

    Private Shared morningTimer As Timer
    Private Shared eveningTimer As Timer
    Private Shared deadlineTimer As Timer

    Protected Sub Application_Start(ByVal sender As Object, ByVal e As EventArgs)
        ' 🔹 Load values from Web.config
        WhatsFlySecret = ConfigurationManager.AppSettings("WhatsFlySecret")
        WhatsFlyAccount = ConfigurationManager.AppSettings("WhatsFlyAccount")
        WhatsFlyApiUrl = ConfigurationManager.AppSettings("WhatsFlyApiUrl")
        ReportMobile = ConfigurationManager.AppSettings("ReportMobile")


        ' 🔹 Setup Morning Timer (9 AM)
        morningTimer = New Timer(GetIntervalTime(9, 5))
        AddHandler morningTimer.Elapsed, AddressOf SendMorningReport
        morningTimer.AutoReset = False
        morningTimer.Start()

        '🔹 Setup Evening Timer (9 PM)
        eveningTimer = New Timer(GetIntervalTime(20, 0))
        AddHandler eveningTimer.Elapsed, AddressOf SendEveningReport
        eveningTimer.AutoReset = False
        eveningTimer.Start()

        ' 🔹 Setup Deadline Timer (runs every 1 min)
        deadlineTimer = New Timer(60000) ' 60,000 ms = 1 minute
        AddHandler deadlineTimer.Elapsed, AddressOf CheckDeadlines
        deadlineTimer.AutoReset = True
        deadlineTimer.Start()

    End Sub

    Private Function GetIntervalTime(targetHour As Integer, targetMinute As Integer) As Double
        Dim now = DateTime.Now
        Dim target = New DateTime(now.Year, now.Month, now.Day, targetHour, targetMinute, 0)


        If now > target Then
            target = target.AddDays(1)
        End If

        Return (target - now).TotalMilliseconds
    End Function

    Private Sub ResetTimer(t As Timer, hour As Integer, minute As Integer)
        t.Interval = GetIntervalTime(hour, minute)
        t.Start()
    End Sub

    Private Sub SendMorningReport(sender As Object, e As ElapsedEventArgs)
        Try
            AutoWhatsAppReport.RunDailyReport()
        Catch ex As Exception
            ' optional: log error
        End Try
        ResetTimer(morningTimer, 10, 58)
    End Sub

    Private Sub SendEveningReport(sender As Object, e As ElapsedEventArgs)
        Try
            AutoWhatsAppReport.RunDailyReport()
        Catch ex As Exception
            ' optional: log error
        End Try
        ResetTimer(eveningTimer, 21, 0)
    End Sub

    Private Sub CheckDeadlines(sender As Object, e As ElapsedEventArgs)
        Try
            WhatsAppNotifier.RunDeadlineCheck()
        Catch ex As Exception
            ' optional: error log kar sakte ho
        End Try
    End Sub

End Class