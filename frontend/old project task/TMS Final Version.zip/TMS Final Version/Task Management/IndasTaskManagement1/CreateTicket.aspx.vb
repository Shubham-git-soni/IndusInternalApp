﻿Imports System.Web.Services
Imports System.Web.Script.Serialization

Partial Public Class CreateTicket
    Inherits BasePage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            Dim users = DataAccess.GetAssignableUsers()
            Dim serializer As New JavaScriptSerializer()
            hdnUsersData.Value = serializer.Serialize(users)
        End If
    End Sub

    <WebMethod()>
    Public Shared Function GetQueuePoints() As List(Of PointData)
        Return DataAccess.GetQueuePointsForGrid()
    End Function


    <WebMethod()>
    Public Shared Function AssignPoints(ByVal request As AssignRequest) As Object
        Try
            If request.PointID Is Nothing OrElse request.PointID.Count = 0 Then
                Return New With {.success = False, .message = "No points selected."}
            End If
            If request.assignedToUserID <= 0 Then
                Return New With {.success = False, .message = "Invalid team member selected."}
            End If
            If String.IsNullOrEmpty(request.newStatus) Then
                Return New With {.success = False, .message = "New status cannot be empty."}
            End If

            Dim createdByUserID As Integer = Convert.ToInt32(HttpContext.Current.Session("UserID"))
            Dim ticketDepartment As String = "Software Development"

            Dim result = DataAccess.CreateTicketAndAssignPoints(
        request.PointID, request.assignedToUserID, createdByUserID, ticketDepartment, request.newStatus)

            ' --- NOTIFICATION LOGIC START ---
            If result.success Then
                Dim adminName As String = HttpContext.Current.Session("FullName").ToString()
                For Each point In request.PointID
                    Dim message As String = $"Point #{point.PointID} has been assigned to you by {adminName}."
                    Dim url As String = $"~/DashboardDeveloper.aspx?pointId={point.PointID}"
                    DataAccess.CreateNotification(request.assignedToUserID, message, url)
                Next
            End If
            ' --- NOTIFICATION LOGIC END ---

            Return New With {.success = result.success, .message = result.message, .ticketNo = result.ticketNo}

        Catch ex As Exception
            Return New With {.success = False, .message = "AssignPoints Error: " & ex.Message}
        End Try
    End Function


    '<WebMethod()>
    'Public Shared Function UpdateExpectedDate(pointId As Integer, expectedDate As DateTime) As Object
    '    Try
    '        Dim success As Boolean = DataAccess.UpdatePointExpectedDate(pointId, expectedDate)
    '        If success Then
    '            Return New With {.success = True}
    '        Else
    '            Return New With {.success = False, .message = "Failed to update date in database."}
    '        End If
    '    Catch ex As Exception
    '        Return New With {.success = False, .message = "An error occurred: " & ex.Message}
    '    End Try
    'End Function 

    ' CreateTicket.aspx.vb file ke andar, class ke end se pehle yeh naya WebMethod add karein

    <WebMethod()>
    Public Shared Function ReverifySelectedPoints(pointIds As List(Of Integer)) As Object
        Try
            If pointIds Is Nothing OrElse pointIds.Count = 0 Then
                Return New With {.success = False, .message = "No points selected."}
            End If

            Dim success As Boolean = DataAccess.SendPointsToReverify(pointIds)

            If success Then
                Return New With {.success = True, .message = $"{pointIds.Count} point(s) sent back for re-verification."}
            Else
                Return New With {.success = False, .message = "Failed to send points for re-verification."}
            End If
        Catch ex As Exception
            Return New With {.success = False, .message = "An error occurred: " & ex.Message}
        End Try
    End Function


End Class

Public Class AssignRequest
    Public Property PointID As List(Of PointWithDate)
    Public Property assignedToUserID As Integer
    Public Property newStatus As String
End Class