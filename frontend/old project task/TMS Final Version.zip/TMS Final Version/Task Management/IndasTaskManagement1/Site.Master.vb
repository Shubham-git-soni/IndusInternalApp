﻿
Imports System.Data.SqlClient

Imports System.Web.Services



Public Class Site

    Inherits System.Web.UI.MasterPage



    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Session("UserID") IsNot Nothing Then

            lblUsername.Text = Session("FullName").ToString()

            ApplyPermissions()

        Else



            For Each ctrl As Control In sidebar.Controls

                If TypeOf ctrl Is HyperLink Then

                    DirectCast(ctrl, HyperLink).Visible = False

                End If

            Next

        End If

    End Sub



    ' REPLACE your old ApplyPermissions function with this new one



    Private Sub ApplyPermissions()
        Dim userId As Integer = Convert.ToInt32(Session("UserID"))
        Dim userRole As String = Session("Role").ToString()

        ' Step 1: Check if the user is an Admin
        If userRole.Equals("Admin", StringComparison.OrdinalIgnoreCase) Then
            ' User is an Admin, show all links
            lnkDashboardAdmin.Visible = True
            lnkManageUsers.Visible = True
            lnkManageCustomers.Visible = True
            lnkAddPoint.Visible = True
            lnkManagePoint.Visible = True
            lnkCreateTicket.Visible = True
            lnkManageTickets.Visible = True
            lnkVerifyTicket.Visible = True
            lnkTimeReport.Visible = True
            lnkSupportAction.Visible = True
            lnkDeveloperDashboard.Visible = DataAccess.DoesUserHaveAssignedTickets(userId)
            lnkTesterDashboard.Visible = False
            lnkUserPermissions.Visible = True
            lnkDeveloperKPIDashboard.Visible = False
            lnkMergeCode.Visible = True
            lnkTimeReport.Visible = True


            ' 👇 ****** YEH "Else" ZAROORI HAI ****** 👇
        Else
            ' Step 2: Agar user Admin nahin hai, to database se permissions check karein
            Dim allowedPages As List(Of String) = DataAccess.GetUserPermissions(userId)

            ' Agar koi permission set nahi hai, toh default set karein
            If allowedPages.Count = 0 Then
                Select Case userRole
                    Case "support"
                        allowedPages.Add("AddPoint.aspx")
                        allowedPages.Add("ManagePoint.aspx")
                        allowedPages.Add("SupportActionCenter.aspx")
                    Case "developer"
                        allowedPages.Add("DashboardDeveloperKPI.aspx")
                        allowedPages.Add("DashboardDeveloper.aspx")
                    Case "tester"
                        allowedPages.Add("DashboardTester.aspx")
                End Select
            End If

            ' Har link ko uski permission ke anusaar show/hide karein
            lnkDashboardAdmin.Visible = allowedPages.Contains("DashboardAdmin.aspx", StringComparer.OrdinalIgnoreCase)
            lnkManageUsers.Visible = allowedPages.Contains("ManageUsers.aspx", StringComparer.OrdinalIgnoreCase)
            lnkManageCustomers.Visible = allowedPages.Contains("ManageCustomers.aspx", StringComparer.OrdinalIgnoreCase)
            lnkAddPoint.Visible = allowedPages.Contains("AddPoint.aspx", StringComparer.OrdinalIgnoreCase)
            lnkManagePoint.Visible = allowedPages.Contains("ManagePoint.aspx", StringComparer.OrdinalIgnoreCase)
            lnkVerifyTicket.Visible = allowedPages.Contains("VerifyTicket.aspx", StringComparer.OrdinalIgnoreCase)
            lnkCreateTicket.Visible = allowedPages.Contains("CreateTicket.aspx", StringComparer.OrdinalIgnoreCase)
            lnkManageTickets.Visible = allowedPages.Contains("ManageTickets.aspx", StringComparer.OrdinalIgnoreCase)
            lnkDeveloperKPIDashboard.Visible = allowedPages.Contains("DashboardDeveloperKPI.aspx", StringComparer.OrdinalIgnoreCase)
            lnkDeveloperDashboard.Visible = allowedPages.Contains("DashboardDeveloper.aspx", StringComparer.OrdinalIgnoreCase)
            lnkTesterDashboard.Visible = allowedPages.Contains("DashboardTester.aspx", StringComparer.OrdinalIgnoreCase)
            lnkUserPermissions.Visible = allowedPages.Contains("UserPermissions.aspx", StringComparer.OrdinalIgnoreCase)
            lnkTimeReport.Visible = allowedPages.Contains("TimeReport.aspx", StringComparer.OrdinalIgnoreCase)
            lnkMergeCode.Visible = allowedPages.Contains("MergeCode.aspx", StringComparer.OrdinalIgnoreCase)
            lnkSupportAction.Visible = allowedPages.Contains("SupportActionCenter.aspx", StringComparer.OrdinalIgnoreCase)
        End If

        ' Step 3: Aakhri check jo har kisi ke liye chalega
        ' Yeh If/Else block ke bahar hai, isliye yeh Admin aur non-Admin dono ke liye kaam karega.
        Dim hasMergeTasks As Boolean = DataAccess.DoesUserHaveMergeRequests(userId)
        lnkMergeCode.Visible = hasMergeTasks
    End Sub

End Class