﻿Imports System.IO
Imports System.Web.Script.Serialization
Imports System.Web.Services

Partial Public Class AddPoint
    Inherits BasePage

    Protected hdnLoggedInUserID As HiddenField

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        ' --- File Upload Handling Logic ---
        If Request.Files.Count > 0 AndAlso Request.HttpMethod = "POST" Then
            Response.Clear()
            Dim serializer As New JavaScriptSerializer()
            Dim responseObject As Object

            Try
                Dim file = Request.Files(0)
                Dim uploadFolder = Server.MapPath("~/Uploads/")
                If Not Directory.Exists(uploadFolder) Then
                    Directory.CreateDirectory(uploadFolder)
                End If

                Dim uniqueFileName = Guid.NewGuid().ToString() & "_" & Path.GetFileName(file.FileName)
                Dim serverFilePath = Path.Combine(uploadFolder, uniqueFileName)
                file.SaveAs(serverFilePath)

                responseObject = New With {
                    .success = True,
                    .message = "File uploaded successfully!",
                    .fileName = uniqueFileName,
                    .filePath = "/Uploads/" & uniqueFileName
                }

                Response.ContentType = "application/json"
                Response.Write(serializer.Serialize(responseObject))

            Catch ex As Exception
                System.Diagnostics.Trace.WriteLine("File Upload Error: " & ex.Message)
                responseObject = New With {
                    .success = False,
                    .message = "File could not be uploaded. " & ex.Message
                }
                Response.StatusCode = 500
                Response.ContentType = "application/json"
                Response.Write(serializer.Serialize(responseObject))

            Finally
                Response.Flush()
                Response.SuppressContent = True
                HttpContext.Current.ApplicationInstance.CompleteRequest()
            End Try

            Return ' Exit early
        End If

        ' --- Normal Page Load Logic (for GET requests) ---
        If Not IsPostBack Then
            PopulateDataForClient()
            If Session("UserID") IsNot Nothing Then
                hdnLoggedInUserID.Value = Session("UserID").ToString()
            End If
        End If
    End Sub

    Private Sub PopulateDataForClient()
        Dim serializer As New JavaScriptSerializer()

        ' ✅ Get Customers & Products
        hdnCustomersData.Value = serializer.Serialize(DataAccess.GetCustomers())
        hdnProductsData.Value = serializer.Serialize(DataAccess.GetProducts())

        Dim modules = DataAccess.GetModules()
        hdnModulesData.Value = serializer.Serialize(modules)

        ' ✅ Show only Admins in "Reported By"
        Dim allUsers = DataAccess.GetUsers()
        hdnReportedByUsersData.Value = serializer.Serialize(allUsers)

        ' ✅ Remove Assigned To (not used in this form)
        hdnAssignedToUsersData.Value = "[]" ' empty or remove if not used
    End Sub

    <WebMethod()>
    Public Shared Function SavePoint(data As PointData, attachments As List(Of AttachmentInfo)) As Object
        Try
            If String.IsNullOrEmpty(data.Title) OrElse String.IsNullOrEmpty(data.Description) OrElse
               data.CustomerID Is Nothing OrElse data.ProductID Is Nothing OrElse data.ReportedByID Is Nothing OrElse
               String.IsNullOrEmpty(data.Priority) OrElse String.IsNullOrEmpty(data.Category) Then
                Return New With {.success = False, .message = "All required fields must be filled."}
            End If

            Dim newPointId As Integer = DataAccess.InsertPoint(data)
            If newPointId > 0 Then
                If attachments IsNot Nothing AndAlso attachments.Count > 0 Then
                    Dim uploadedById As Integer = HttpContext.Current.Session("UserID")
                    For Each attachment In attachments
                        DataAccess.InsertAttachment(newPointId, attachment.fileName, attachment.filePath, uploadedById)
                    Next
                End If


                Return New With {.success = True, .message = "Ticket added successfully!", .pointId = newPointId}
            Else
                Return New With {.success = False, .message = "Failed to add Ticket to database."}
            End If

        Catch ex As Exception
            System.Diagnostics.Trace.WriteLine("Error in SavePoint WebMethod: " & ex.Message)
            Return New With {.success = False, .message = "An unexpected error occurred: " & ex.Message}
        End Try
    End Function

    '  NEW WEB METHOD: Manual email sending ke liye ye naya function add kiya gaya hai

    '<WebMethod()>
    'Public Shared Function SendEmailToSelectedCustomer(customerId As Integer, pointId As Integer) As Object

    '    Try

    '        If customerId <= 0 Then

    '            Return New With {.success = False, .message = "Invalid Customer ID."}

    '        End If
    '        If pointId <= 0 Then

    '            Return New With {.success = False, .message = "Invalid Point ID provided for email."}

    '        End If



    '        ' ✅ Customer ki details fetch ki ja rahi hain database se

    '        Dim customerInfo = DataAccess.GetCustomerById(customerId)

    '        If customerInfo IsNot Nothing AndAlso Not String.IsNullOrEmpty(customerInfo("ContactEmail")) Then

    '            Dim customerEmail As String = customerInfo("ContactEmail").ToString()

    '            Dim customerName As String = customerInfo("CustomerName").ToString()



    '            '  Email message ka subject aur body define kiya gaya hai

    '            Dim subject As String = "Important Update Regarding Your Request"

    '            Dim body As String = $"<p>Dear {customerName},</p>" &
    '                                 "<p>Your problem has been registered successfully.<br>" &
    '                                 $"Your Ticket ID is: <strong>{pointId}</strong>.<br>" &
    '                                 "Our team will get back to you soon.</p>" &
    '                                 "<p>Thank you,<br>Support Team</p>"



    '            '

    '            EmailHelper.SendEmail(customerEmail, subject, body)



    '            Return New With {.success = True, .message = $"Email sent successfully to {customerName} ({customerEmail}) for Ticket ID {pointId}."}

    '        Else

    '            Return New With {.success = False, .message = "Customer not found or email address is missing for the selected customer."}

    '        End If



    '    Catch ex As Exception

    '        System.Diagnostics.Trace.WriteLine("Error in SendEmailToSelectedCustomer WebMethod: " & ex.Message)

    '        Return New With {.success = False, .message = "An unexpected error occurred while sending email: " & ex.Message}

    '    End Try

    'End Function
    'Protected Sub Page_PreInit(ByVal sender As Object, ByVal e As EventArgs) Handles Me.PreInit
    '    If Session("Role") IsNot Nothing AndAlso Session("Role").ToString().Equals("Support", StringComparison.OrdinalIgnoreCase) Then
    '        Me.MasterPageFile = "~/Support.Master"
    '    Else
    '        Me.MasterPageFile = "~/Site.Master"
    '    End If
    'End Sub

    <WebMethod()>
    Public Shared Function DeleteUploadedFile(uniqueFileName As String) As Object
        Try
            Dim fileNameOnly = Path.GetFileName(uniqueFileName)
            Dim uploadFolder = HttpContext.Current.Server.MapPath("~/Uploads/")
            Dim fullPath = Path.Combine(uploadFolder, fileNameOnly)

            If File.Exists(fullPath) Then
                File.Delete(fullPath)
                Return New With {.success = True, .message = "File deleted successfully."}
            Else
                Return New With {.success = True, .message = "File not found on server, but removed from list."}
            End If

        Catch ex As Exception
            System.Diagnostics.Trace.WriteLine("File Delete Error: " & ex.Message)
            Return New With {.success = False, .message = "Error deleting file."}
        End Try
    End Function
End Class
