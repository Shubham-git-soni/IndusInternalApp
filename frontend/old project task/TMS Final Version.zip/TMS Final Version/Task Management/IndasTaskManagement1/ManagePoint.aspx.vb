﻿' ManagePoint.aspx.vb

Imports System.Web.Script.Serialization
Imports System.Web.Services
Imports System.IO
Imports IndasTaskManagement1.DataAccess

Partial Public Class ManagePoint
    Inherits BasePage

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        If Not IsPostBack Then
            PopulateDataForClient()
        End If
    End Sub

    Private Sub PopulateDataForClient()
        Dim serializer As New JavaScriptSerializer()

        ' Get Customers
        Dim customers = DataAccess.GetCustomers()
        hdnCustomersData.Value = serializer.Serialize(customers)

        ' Get Products
        Dim products = DataAccess.GetProducts()
        hdnProductsData.Value = serializer.Serialize(products)

        Dim modules = DataAccess.GetModules()
        hdnModulesData.Value = serializer.Serialize(modules)

        ' Get Users (Reported By - all users who can report)
        Dim allUsers = DataAccess.GetUsers()
        hdnReportedByUsersData.Value = serializer.Serialize(allUsers)
        hdnAssignedToUsersData.Value = serializer.Serialize(allUsers)
    End Sub

    <WebMethod()>
    Public Shared Function GetPointsForGrid() As List(Of PointData)
        ' Get user role and ID from session
        Dim userId As Integer = If(HttpContext.Current.Session("UserID") IsNot Nothing, CInt(HttpContext.Current.Session("UserID")), 0)
        Dim userRole As String = If(HttpContext.Current.Session("Role") IsNot Nothing, HttpContext.Current.Session("Role").ToString(), "")

        ' If user is Support, filter to show only their own reported points
        ' If Admin or other roles, show all points
        Return DataAccess.GetPointsForManageByRole(userId, userRole)
    End Function

    <WebMethod()>
    Public Shared Function GetPointDetails(ByVal pointId As Integer) As PointData
        Return DataAccess.GetPointDetailsById(pointId)
    End Function

    <WebMethod()>
    Public Shared Function UpdatePoint(data As PointData) As Object
        Try
            If data Is Nothing OrElse Not data.PointID.HasValue Then
                Return New With {.success = False, .message = "Invalid data received."}
            End If

            Dim isSuccess As Boolean = DataAccess.UpdatePoint(data)

            If isSuccess Then
                Return New With {.success = True, .message = "Point updated successfully!"}
            Else
                Return New With {.success = False, .message = "Failed to update the point in the database."}
            End If

        Catch ex As Exception
            System.Diagnostics.Trace.WriteLine("ERROR in UpdatePoint WebMethod: " & ex.ToString())
            Return New With {.success = False, .message = "An unexpected server error occurred during the update."}
        End Try
    End Function

    <WebMethod()>
    Public Shared Function DeletePoint(ByVal pointId As Integer) As Boolean
        Try
            If pointId <= 0 Then
                HttpContext.Current.Response.StatusCode = 400
                HttpContext.Current.Response.StatusDescription = "Invalid Point ID for deletion."
                Return False
            End If
            Return DataAccess.DeletePoint(pointId)
        Catch ex As Exception
            System.Diagnostics.Trace.WriteLine("Error in DeletePoint WebMethod: " & ex.Message)
            HttpContext.Current.Response.StatusCode = 500
            HttpContext.Current.Response.StatusDescription = "An unexpected error occurred during deletion: " & ex.Message
            Return False
        End Try
    End Function

    'Protected Sub Page_PreInit(ByVal sender As Object, ByVal e As EventArgs) Handles Me.PreInit
    '    If Session("Role") IsNot Nothing AndAlso Session("Role").ToString().Equals("Support", StringComparison.OrdinalIgnoreCase) Then
    '        Me.MasterPageFile = "~/Support.Master"
    '    Else
    '        Me.MasterPageFile = "~/Site.Master"
    '    End If
    'End Sub

    <WebMethod()>
    Public Shared Function DeleteExistingAttachment(attachmentId As Integer) As Boolean
        Return DataAccess.DeleteAttachmentById(attachmentId)
    End Function

    <WebMethod()>
    Public Shared Function AddAttachmentToPoint(pointId As Integer, attachment As AttachmentInfo) As Object
        Try
            Dim uploadedById As Integer = HttpContext.Current.Session("UserID")
            DataAccess.InsertAttachment(pointId, attachment.fileName, attachment.filePath, uploadedById)
            Return New With {.success = True, .message = "Attachment added."}
        Catch ex As Exception
            Return New With {.success = False, .message = "Failed to add attachment."}
        End Try
    End Function

    <WebMethod()>
    Public Shared Function GetAttachments(pointId As Integer) As List(Of AttachmentData)
        Return DataAccess.GetAllAttachmentsForPoint(pointId)
    End Function

    ' ✅ NEW METHOD: Delete uploaded file from physical folder
    <WebMethod()>
    Public Shared Function DeleteUploadedFile(uniqueFileName As String) As Object
        Try
            If String.IsNullOrWhiteSpace(uniqueFileName) Then
                Return New With {.success = False, .message = "Invalid file name provided."}
            End If

            Dim fileNameOnly = Path.GetFileName(uniqueFileName)
            Dim uploadFolder = HttpContext.Current.Server.MapPath("~/Uploads/")
            Dim fullPath = Path.Combine(uploadFolder, fileNameOnly)

            System.Diagnostics.Trace.WriteLine("Trying to delete file at: " & fullPath)

            If File.Exists(fullPath) Then
                File.Delete(fullPath)
                Return New With {.success = True, .message = "File deleted successfully."}
            Else
                Return New With {.success = False, .message = "File not found: " & fullPath}
            End If

        Catch ex As Exception
            System.Diagnostics.Trace.WriteLine("Error in DeleteUploadedFile: " & ex.Message)
            Return New With {.success = False, .message = "Error deleting file: " & ex.Message}
        End Try
    End Function

End Class
